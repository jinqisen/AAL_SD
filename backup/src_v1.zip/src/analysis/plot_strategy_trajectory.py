import os
import json
import argparse
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from typing import List, Dict, Any

def load_trace(trace_path: str) -> pd.DataFrame:
    """Load trace.jsonl and extract per-round strategy metrics.

    Supports both legacy logs (metrics in selection.context) and current logs
    where controller decisions are logged as type=controller_step.
    """
    if not os.path.exists(trace_path):
        print(f"Warning: Trace file not found at {trace_path}")
        return pd.DataFrame()

    per_round: Dict[int, Dict[str, Any]] = {}

    def _row(r: Any) -> Dict[str, Any]:
        try:
            rr = int(r)
        except Exception:
            rr = -1
        if rr not in per_round:
            per_round[rr] = {"round": rr}
        return per_round[rr]

    with open(trace_path, "r") as f:
        for line in f:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            etype = entry.get("type")
            if etype == "selection":
                r = entry.get("round")
                row = _row(r)
                context = entry.get("context", {}) if isinstance(entry.get("context", {}), dict) else {}
                row.update(
                    {
                        "selected_count": entry.get("selected"),
                        "sampler_type": entry.get("sampler_type") or context.get("sampler") or "unknown",
                        "decision_reason": context.get("decision_reason"),
                        "lambda_t": context.get("lambda_t"),
                        "avg_uncertainty": context.get("avg_uncertainty"),
                        "avg_knowledge_gain": context.get("avg_knowledge_gain"),
                    }
                )

            elif etype == "controller_step":
                r = entry.get("round")
                row = _row(r)
                action = entry.get("action") if isinstance(entry.get("action"), dict) else {}
                state = entry.get("state") if isinstance(entry.get("state"), dict) else {}
                row.update(
                    {
                        "lambda_t": action.get("lambda"),
                        "epochs": action.get("epochs"),
                        "query_size": action.get("query_size"),
                        "rollback_flag": state.get("rollback_flag"),
                        "miou_delta": state.get("miou_delta"),
                        "last_miou": state.get("last_miou"),
                    }
                )

    df = pd.DataFrame(list(per_round.values()))
    if df.empty:
        return df
    df = df.sort_values("round").reset_index(drop=True)
    return df

def plot_lambda_trajectory(df: pd.DataFrame, output_dir: str):
    """
    Plot Lambda (Gradient Mixing Weight) over rounds.
    """
    if "lambda_t" not in df.columns or df["lambda_t"].isnull().all():
        print("Skipping Lambda Plot: No lambda_t data found.")
        return

    plt.figure(figsize=(10, 6))
    sns.lineplot(data=df, x="round", y="lambda_t", marker="o", linewidth=2.5)
    plt.title("Dynamic Gradient Strategy: Lambda Trajectory", fontsize=14)
    plt.xlabel("Round", fontsize=12)
    plt.ylabel("Lambda (Diversity Weight)", fontsize=12)
    plt.grid(True, linestyle="--", alpha=0.7)
    plt.ylim(-0.05, 1.05)
    
    # Annotate phases if evident
    # This is heuristic, but helpful
    plt.savefig(os.path.join(output_dir, "strategy_lambda_trajectory.png"), dpi=300)
    plt.close()

def plot_gradient_decomposition(df: pd.DataFrame, output_dir: str):
    """
    Plot the decomposition of the gradient (Uncertainty vs Diversity).
    """
    if "avg_uncertainty" not in df.columns or "avg_knowledge_gain" not in df.columns:
        print("Skipping Decomposition Plot: Missing score components.")
        return

    # Normalize for visualization if needed, but raw scores are better for physics interpretation
    # Assuming scores are somewhat normalized [0,1] by the sampler
    
    plt.figure(figsize=(12, 6))
    
    # Stacked Area or Bar
    # Let's use a dual-line plot for clarity of trends
    
    plt.plot(df["round"], df["avg_uncertainty"], label="Uncertainty (Exploitation)", marker="s", linestyle="-", color="#1f77b4")
    plt.plot(df["round"], df["avg_knowledge_gain"], label="Diversity (Exploration)", marker="^", linestyle="-", color="#ff7f0e")
    
    plt.title("Gradient Component Evolution", fontsize=14)
    plt.xlabel("Round", fontsize=12)
    plt.ylabel("Average Component Score (Selected Samples)", fontsize=12)
    plt.legend()
    plt.grid(True, linestyle="--", alpha=0.7)
    
    plt.savefig(os.path.join(output_dir, "strategy_gradient_components.png"), dpi=300)
    plt.close()

def plot_phase_space(df: pd.DataFrame, output_dir: str):
    """
    Plot the strategy in Phase Space (Uncertainty vs Diversity).
    """
    if "avg_uncertainty" not in df.columns or "avg_knowledge_gain" not in df.columns:
        print("Skipping Phase Space Plot: Missing score components.")
        return

    plt.figure(figsize=(8, 8))
    
    sc = plt.scatter(df["avg_uncertainty"], df["avg_knowledge_gain"], 
                     c=df["round"], cmap="viridis", s=100, edgecolors="k", zorder=2)
    
    # Draw trajectory path
    plt.plot(df["avg_uncertainty"], df["avg_knowledge_gain"], color="gray", alpha=0.5, zorder=1)
    
    cbar = plt.colorbar(sc)
    cbar.set_label("Round")
    
    plt.title("Strategy Phase Space Trajectory", fontsize=14)
    plt.xlabel("Uncertainty (Information Gain)", fontsize=12)
    plt.ylabel("Diversity (Knowledge Gain)", fontsize=12)
    plt.grid(True, linestyle="--", alpha=0.7)
    
    # Add arrows to show direction
    for i in range(len(df) - 1):
        x1, y1 = df.iloc[i]["avg_uncertainty"], df.iloc[i]["avg_knowledge_gain"]
        x2, y2 = df.iloc[i+1]["avg_uncertainty"], df.iloc[i+1]["avg_knowledge_gain"]
        plt.annotate("", xy=(x2, y2), xytext=(x1, y1),
                     arrowprops=dict(arrowstyle="->", color="gray", alpha=0.5))

    plt.savefig(os.path.join(output_dir, "strategy_phase_space.png"), dpi=300)
    plt.close()

def main():
    parser = argparse.ArgumentParser(description="Analyze Agent Strategy from Trace Logs")
    parser.add_argument("experiment_dir", type=str, help="Path to experiment directory (containing trace.jsonl)")
    parser.add_argument("--output", type=str, default=None, help="Output directory for plots")
    
    args = parser.parse_args()
    
    trace_path = os.path.join(args.experiment_dir, "trace.jsonl")
    if not os.path.exists(trace_path):
        # Try looking in subfolders if the user gave the root runs dir
        # But for now assume direct path
        print(f"Error: {trace_path} does not exist.")
        return

    df = load_trace(trace_path)
    
    if df.empty:
        print("No selection data found in trace.")
        return
        
    print(f"Loaded {len(df)} selection rounds.")
    print(df[["round", "lambda_t", "avg_uncertainty", "avg_knowledge_gain"]].head())
    
    output_dir = args.output if args.output else args.experiment_dir
    os.makedirs(output_dir, exist_ok=True)
    
    plot_lambda_trajectory(df, output_dir)
    plot_gradient_decomposition(df, output_dir)
    plot_phase_space(df, output_dir)
    
    print(f"Plots saved to {output_dir}")

if __name__ == "__main__":
    main()
