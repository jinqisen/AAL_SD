import unittest
from unittest.mock import MagicMock
import json
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from agent.agent_manager import AgentManager
from agent.toolbox import Toolbox
from main import ActiveLearningPipeline

class MockLLMClient:
    def chat(self, messages):
        action = {
            "tool_name": "Final Answer",
            "parameters": {"selected_sample_ids": ["1"], "reasoning": "Highest score."}
        }
        return f"Thought: Select best.\nAction: {json.dumps(action)}"

class MockLLMClientMissingActionThenRecover:
    def __init__(self):
        self.calls = 0

    def chat(self, messages):
        self.calls += 1
        if self.calls == 1:
            return "Thought: I will decide after seeing candidates."
        action = {
            "tool_name": "finalize_selection",
            "parameters": {"sample_ids": ["1"], "reason": "Recover with strict action."}
        }
        return f"Thought: Done.\nAction：{json.dumps(action)}  \n\n"

class MockLLMClientTimeout:
    def chat(self, messages):
        return "Error calling API: HTTPSConnectionPool(host='api.siliconflow.cn', port=443): Read timed out. (read timeout=60)"

class MockLLMClientRepeatedStatusThenFinalize:
    def __init__(self):
        self.calls = 0

    def chat(self, messages):
        self.calls += 1
        last_user = ""
        try:
            for msg in reversed(messages or []):
                if msg.get("role") == "user":
                    last_user = str(msg.get("content") or "")
                    break
        except Exception:
            last_user = ""

        if "InvalidAction" in last_user:
            action = {
                "tool_name": "finalize_selection",
                "parameters": {"sample_ids": ["1"], "reason": "Stop repeating observation; finalize."}
            }
            return f"Thought: Finalize now.\nAction: {json.dumps(action)}"

        if self.calls <= 3:
            action = {"tool_name": "get_system_status", "parameters": {}}
            return f"Thought: Check status again.\nAction: {json.dumps(action)}"

        action = {
            "tool_name": "finalize_selection",
            "parameters": {"sample_ids": ["1"], "reason": "Proceed after status."}
        }
        return f"Thought: Finalize.\nAction: {json.dumps(action)}"


class MockLLMClientNeverFinalizes:
    def chat(self, messages):
        action = {"tool_name": "get_system_status", "parameters": {}}
        return f"Thought: Keep observing.\nAction: {json.dumps(action)}"

class TestLLMAgent(unittest.TestCase):
    def setUp(self):
        self.tools = MagicMock()
        self.tools.training_state = {}
        self.tools.controller = None
        self.tools.get_system_status.return_value = json.dumps({
            "current_labeled_count": 1,
            "total_budget": 10,
            "lambda_t": 0.5
        })
        self.tools.finalize_selection.return_value = json.dumps({
            "status": "success",
            "selected_count": 1,
            "reason_recorded": "Highest score candidate."
        })

    def test_mock_llm_cycle(self):
        mock_client = MockLLMClient()
        agent = AgentManager(tools=self.tools, client=mock_client, verbose=False)
        result = agent.run_cycle()
        
        self.tools.precalculate_scores.assert_called_once()
        self.tools.get_system_status.assert_called()
        self.tools.finalize_selection.assert_called()
        
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['selected_count'], 1)

    def test_missing_action_then_recover(self):
        mock_client = MockLLMClientMissingActionThenRecover()
        agent = AgentManager(tools=self.tools, client=mock_client, verbose=False)
        result = agent.run_cycle()

        self.tools.finalize_selection.assert_called()
        self.assertEqual(result['status'], 'success')

    def test_llm_timeout_fast_fail(self):
        mock_client = MockLLMClientTimeout()
        agent = AgentManager(tools=self.tools, client=mock_client, verbose=False, llm_max_retries=0, llm_retry_base_seconds=0.0)
        result = agent.run_cycle()

        self.tools.precalculate_scores.assert_called_once()
        self.tools.get_system_status.assert_called()
        self.tools.finalize_selection.assert_not_called()
        self.assertEqual(result["status"], "error")
        self.assertEqual(result["error_type"], "LLMAPIError")

    def test_repeated_observation_is_limited_and_recovers(self):
        mock_client = MockLLMClientRepeatedStatusThenFinalize()
        agent = AgentManager(tools=self.tools, client=mock_client, verbose=False)
        result = agent.run_cycle()

        self.tools.finalize_selection.assert_called()
        self.assertEqual(result["status"], "success")

    def test_agent_max_steps_error_when_never_finalizes(self):
        mock_client = MockLLMClientNeverFinalizes()
        agent = AgentManager(tools=self.tools, client=mock_client, verbose=False)
        result = agent.run_cycle()

        self.assertEqual(result["status"], "error")
        self.assertEqual(result["error_type"], "AgentMaxSteps")

if __name__ == '__main__':
    unittest.main()


class DummyController:
    def __init__(self):
        self.dataset = object()
        self.unlabeled_indices = [3, 1, 2]
        self.labeled_indices = []
        self.run_id = "r"
        self.experiment_name = "e"
        self.current_round = 1
        self._last_score_precalc_error = None
        self._last_ranking_degraded = None


class DummyStrategyRaises:
    def calculate_scores(self, model, dataset, unlabeled_indices, labeled_indices=None):
        raise RuntimeError("boom")


class TestToolboxDegrade(unittest.TestCase):
    def test_precalculate_scores_failure_sets_error(self):
        controller = DummyController()
        tools = Toolbox(controller, DummyStrategyRaises(), model=None)
        tools.precalculate_scores()
        self.assertEqual(tools.current_scores, {})
        self.assertIsInstance(controller._last_score_precalc_error, dict)
        self.assertEqual(controller._last_score_precalc_error.get("phase"), "score_precalc")

    def test_precalculate_scores_raises_under_strict_innovation(self):
        class _StrictCfg:
            STRICT_INNOVATION = True
            FAIL_ON_RANKING_DEGRADED = True

        class _StrictController(DummyController):
            def __init__(self):
                super().__init__()
                self.config = _StrictCfg()

            def _append_trace(self, event):
                return None

        controller = _StrictController()
        tools = Toolbox(controller, DummyStrategyRaises(), model=None)
        with self.assertRaises(RuntimeError):
            tools.precalculate_scores()

    def test_get_top_k_samples_degraded_without_scores(self):
        controller = DummyController()
        tools = Toolbox(controller, DummyStrategyRaises(), model=None)
        payload = json.loads(tools.get_top_k_samples(k=2, lambda_param=0.5))
        self.assertEqual(payload.get("status"), "success")
        self.assertTrue(payload.get("meta", {}).get("degraded"))
        result = payload.get("result")
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)
        self.assertIn("id", result[0])

    def test_get_top_k_samples_raises_under_strict_innovation(self):
        class _StrictCfg:
            STRICT_INNOVATION = True
            FAIL_ON_RANKING_DEGRADED = True

        class _StrictController(DummyController):
            def __init__(self):
                super().__init__()
                self.config = _StrictCfg()

            def _append_trace(self, event):
                return None

        controller = _StrictController()
        tools = Toolbox(controller, DummyStrategyRaises(), model=None)
        with self.assertRaises(RuntimeError):
            tools.get_top_k_samples(k=2, lambda_param=0.5)


class DummyConfigStrict:
    STRICT_INNOVATION = True
    FAIL_ON_AGENT_FALLBACK = True
    FAIL_ON_RANKING_DEGRADED = True
    REQUIRE_LLM_FOR_AGENT = False
    LLM_API_KEY = "key"
    POOLS_DIR = "/tmp"
    RESULTS_DIR = "/tmp"
    CHECKPOINT_DIR = "/tmp"
    START_MODE = "resume"


class DummyPipelineStrict:
    def __init__(self):
        self.config = DummyConfigStrict()
        self.run_id = "r"
        self.experiment_name = "full_model"
        self.current_round = 1
        self.use_agent = True
        self.sampler_type = "ad_kucs"
        self.sampler = object()
        self.unlabeled_indices = [1, 2, 3]
        self._last_score_precalc_error = None
        self._last_ranking_degraded = None
        self._selection_context = None
        self.fallback_history = []

    def _sampler_audit(self):
        return {"sampler_type": self.sampler_type, "sampler_class": "X"}

    def _append_trace(self, event):
        return None

    def _fallback_query_samples(self, model, preferred_ids, n_samples):
        return [1]

    def _classify_fallback_reason(self, *, exc=None, agent_result=None, required_count=None):
        return "llm_api_error", {"message": "x"}


class TestStrictInnovationGuards(unittest.TestCase):
    def test_strict_innovation_raises_on_agent_fallback(self):
        p = DummyPipelineStrict()
        with self.assertRaises(RuntimeError):
            n_samples = 1
            preferred = []
            fallback = p._fallback_query_samples(None, preferred, n_samples)
            reason_type, reason_detail = p._classify_fallback_reason(agent_result={"error_type": "LLMAPIError"}, required_count=n_samples)
            p._selection_context = {
                "source": "pipeline",
                "policy": "agent_fallback_topk",
                "fallback_used": True,
                "fallback_reason_type": reason_type,
                "fallback_reason_detail": reason_detail,
                **p._sampler_audit(),
            }
            p._append_trace({"type": "fallback", **p._sampler_audit(), "fallback_reason_type": reason_type})
            if getattr(p.config, "STRICT_INNOVATION", False) and getattr(p.config, "FAIL_ON_AGENT_FALLBACK", True):
                raise RuntimeError(f"STRICT_INNOVATION violation: agent_fallback_topk reason_type={reason_type}")
            _ = fallback


class DummyConfigStopOnLlmFailure:
    QUERY_SIZE = 3
    STOP_ON_LLM_FAILURE = True
    STRICT_INNOVATION = False
    FAIL_ON_AGENT_FALLBACK = True


class DummyAgentManagerIncompleteSelection:
    def run_cycle(self):
        return {"status": "success", "selected_count": 0, "valid_candidates": []}


class DummyToolbox:
    def __init__(self):
        self.model = None


class TestPipelineQueryFallback(unittest.TestCase):
    def test_stop_on_llm_failure_does_not_block_fallback_on_incomplete_selection(self):
        p = type("P", (), {})()
        p.config = DummyConfigStopOnLlmFailure()
        p.use_agent = True
        p.agent_manager = DummyAgentManagerIncompleteSelection()
        p.toolbox = DummyToolbox()
        p.current_round = 6
        p.fallback_history = []
        p._selection_context = None

        def _fallback_query_samples(model, preferred_ids, n_samples):
            return list(range(int(n_samples)))

        def _classify_fallback_reason(*, exc=None, agent_result=None, required_count=None):
            return "agent_selection_incomplete", {"required_count": int(required_count or 0)}

        def _sampler_audit():
            return {"sampler_type": "ad_kucs", "sampler_class": "X"}

        def _append_trace(event):
            return None

        p._fallback_query_samples = _fallback_query_samples
        p._classify_fallback_reason = _classify_fallback_reason
        p._sampler_audit = _sampler_audit
        p._append_trace = _append_trace

        selected = ActiveLearningPipeline._query_samples(p, model=None)
        self.assertEqual(len(selected), int(p.config.QUERY_SIZE))
