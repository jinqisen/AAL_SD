import json
from .config import AgentThresholds, AgentConstraints

class PromptBuilder:
    def build_system_prompt(self, total_iterations=0, current_iteration=0, last_miou=0.0, lambda_t=0.0, rollback_threshold=None, rollback_mode=None, k_definition=None, control_permissions=None):
        allowed_actions = []
        control_permissions_json = "null"
        alpha_allowed = None
        
        # 默认权限设置 (Getter 默认 True, Setter 默认 False)
        # 注意：这里需要与 Toolbox 保持一致，但 PromptBuilder 是无状态的，所以依赖传入的 control_permissions
        # 如果 control_permissions 为 None，假设全开(Getter)或全关(Setter)? 
        # 稳妥起见，我们解析传入的 dict，如果没传则不做假设（显示所有 standard tools）
        
        effective_permissions = {
            "get_system_status": True,
            "get_top_k_samples": True,
            "get_sample_details": True,
            "set_hyperparameter": False,
            "finalize_selection": True,
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "get_score_distribution": True
        }
        
        if isinstance(control_permissions, dict):
            control_permissions_json = json.dumps(control_permissions, ensure_ascii=False)
            effective_permissions.update(control_permissions)
            if effective_permissions.get("set_lambda"):
                allowed_actions.append("set_lambda")
            if effective_permissions.get("set_query_size"):
                allowed_actions.append("set_query_size")
            if effective_permissions.get("set_epochs_per_round"):
                allowed_actions.append("set_epochs_per_round")
            alpha_allowed = bool(effective_permissions.get("set_alpha", False))
            if alpha_allowed:
                allowed_actions.append("set_hyperparameter")
        
        allowed_actions_str = ", ".join(allowed_actions) if allowed_actions else "无"
        action_space = list(allowed_actions) if allowed_actions else []
        if "finalize_selection" not in action_space:
            action_space.append("finalize_selection")
        action_space_str = "{" + ", ".join(action_space) + "}"
        alpha_allowed_str = "未知"
        if alpha_allowed is True:
            alpha_allowed_str = "是"
        if alpha_allowed is False:
            alpha_allowed_str = "否"

        # 动态构建工具列表
        all_tools_definitions = [
            ("get_system_status", "1. get_system_status()\n            - 返回系统状态信息"),
            ("get_top_k_samples", "2. get_top_k_samples(k, lambda_param)\n            - 返回前K个候选样本"),
            ("get_sample_details", "3. get_sample_details(sample_id)\n            - 返回样本详细信息"),
            ("set_hyperparameter", "4. set_hyperparameter(alpha)\n            - 设置超参数alpha"),
            ("finalize_selection", "5. finalize_selection(sample_ids, reason)\n            - 提交最终选择"),
            ("set_lambda", "6. set_lambda(lambda_value, scope=\"round\")\n            - 设置融合权重lambda(0-1)"),
            ("set_query_size", "7. set_query_size(query_size, scope=\"round\")\n            - 设置本轮标注数量，自动裁剪到剩余预算"),
            ("set_epochs_per_round", "8. set_epochs_per_round(epochs, scope=\"round\")\n            - 设置每轮训练epoch数，上限20"),
            ("get_score_distribution", "9. get_score_distribution(n_bins, quantiles)\n            - 返回U/K分布统计与直方图")
        ]
        
        available_tools_list = []
        for key, desc in all_tools_definitions:
            # 特殊处理：set_alpha 对应 tool 名 set_hyperparameter
            perm_key = "set_alpha" if key == "set_hyperparameter" else key
            if effective_permissions.get(perm_key, False):
                available_tools_list.append(desc)
        
        available_tools_str = "\n            ".join(available_tools_list)

        k_def = str(k_definition or "clustering")
        rollback_threshold_val = None
        try:
            rollback_threshold_val = float(rollback_threshold) if rollback_threshold is not None else None
        except Exception:
            rollback_threshold_val = None
        if rollback_threshold_val is None:
            rollback_threshold_val = float(AgentThresholds.ROLLBACK_THRESHOLD)
        rollback_mode_str = str(rollback_mode) if rollback_mode is not None else "prev_drop"

        if k_def == "coreset_to_labeled":
            k_definition_desc = (
                "1. coreset-to-labeled：K(x)=min_{l∈L}||f_x-f_l|| 的归一化（越大越新颖/覆盖不足）。"
                "若已标注为空，则退化为代表性：对未标注特征聚类并使用 K(x)=1-d(x)。"
            )
        else:
            k_definition_desc = (
                "1. 冷启动期（已标注样本不足）：对未标注样本特征做KMeans聚类得到簇中心C_unlabeled，"
                "令 d(x)=min_dist(f_x, C_unlabeled)（可视为\"代表性距离\"），并做归一化；"
                "K(x)=1-d(x)，优先选择更靠近簇中心的代表性样本。"
                "\n              2. 标准期（已标注样本充足）：对已标注样本特征做KMeans聚类得到簇中心C_labeled，"
                "令 d(x)=min_dist(f_x, C_labeled)（可视为\"相对已标注特征的距离\"），并做归一化；"
                "K(x)=d(x)，优先选择更远离已标注簇中心的新颖样本。"
                f"\n              3. 阶段切换：当已标注样本数 >= {AgentThresholds.MIN_LABELED_FOR_NOVELTY} 时进入标准期。"
            )

        prompt = """
            你是一个主动学习系统的“动态控制器”（不是聊天助手），你的输出必须直接驱动本轮Round的控制动作与最终选样。
            总体目标：在固定总标注预算下最大化学习曲线面积(ALC)与最终mIoU，并降低不稳定性（回撤、过拟合、训练过载、预算越界、无效动作）。

            情境感知:
            - 总迭代轮数 (T_max): {total_iterations}
            - 当前迭代轮数 (t): {current_iteration}
            - 当前模型性能 (mIoU): {last_miou:.4f}
            - 当前自适应权重 (lambda_t): {lambda_t:.4f}
            - 控制权限(JSON): {control_permissions_json}
            - 允许控制动作: {allowed_actions_str}
            - set_hyperparameter 可用: {alpha_allowed_str}

            AD-KUCS 评分逻辑（必须遵守） ：
            - 不确定性 U(x) = entropy(p_x)，p_x为样本x预测概率分布。
            - 知识增益 K(x) 定义：
              {k_definition_desc}
            - 融合得分 Score(x) = (1-λ)·U(x) + λ·K(x)，λ∈[0,1]。
            - 系统提供的 lambda_t 为默认建议；建议将单轮调整幅度控制在±{lambda_adjust_range}以内。系统对λ的硬约束为[{lambda_min},{lambda_max}]。

            量化阈值（必须遵守）：
            - 显著为负：miou_delta < {significant_negative}
            - 后期：t / T_max > {late_stage_ratio}
            - 回撤阈值：miou_delta < {rollback_threshold}
            - 训练过载：epochs > {training_overload_epochs} 且 miou_delta < 0
            - 无效动作：调用 set_* 但参数未发生变化

            控制与评价机制（在Thought里显式说明）：
            - 观测维度：训练趋势、U/K分布统计、预算边界。
            - 动作空间：{action_space_str}。
            - 约束：remaining_budget硬约束；epochs<={epochs_cap}；λ∈[{lambda_min},{lambda_max}]；触发裁剪必须在reason记录。
            - 选择策略：
            - U分布整体高（均值>{high_uncertainty_mean}）且方差大（std>{high_uncertainty_std}）：降低λ偏向U。
            - 进入后期或K分布尾部更长（75分位>均值+{long_tail_k_threshold}）：提高λ偏向K。
            - rollback_flag为真（表示本轮mIoU相对上一轮下降）或miou_delta显著为负：降低epochs或减小query_size，并标注"回撤-保守控制"。

            异常处理（必须遵守）：
            - miou为NaN/Inf：使用上轮有效值并注明“miou异常-使用历史值”。
            - 分布统计为空：跳过分布分析，使用lambda_t并注明“分布数据缺失-使用默认λ”。
            - 工具调用失败：重试1次，仍失败则使用默认值并注明“工具调用失败-使用默认值”。
            - 参数非法：使用默认值（λ=0.5 / epochs=10 / query_size=remaining_budget）并注明原因。

            可用工具：
            {available_tools_str}

            执行顺序（必须遵循）：
            1) 观测：使用 get_system_status 与 get_score_distribution 获取状态与分布（每种观测工具每轮最多调用2次；通常1次足够）。
            2) 控参：根据约束调用 set_lambda / set_query_size / set_epochs_per_round。
            3) 选样：使用 get_top_k_samples 与 get_sample_details。
            4) 提交：使用 finalize_selection 提交样本与reason（必须在总步数上限内完成，否则该轮视为失败）。
            约束：建议每阶段最多调用{max_tool_calls_per_phase}次工具；系统同时限制总步数不超过{max_steps}步。

            ReAct格式（仅输出Thought与Action）：
            Thought: <包含观测摘要、动作三元组与约束考虑、预期收益与风险>
            Action: {{"tool_name": "...", "parameters": {{...}}}}

            严格约束：
            - 只能输出两行：Thought 与 Action（不要输出 Observation，不要使用代码块）。
            - Action 行必须以 "Action:" 开头，后面紧跟单个 JSON 对象，且 JSON 后不要追加任何文字。
            """
        formatted = prompt.format(
            total_iterations=int(total_iterations or 0),
            current_iteration=int(current_iteration or 0),
            last_miou=float(last_miou or 0.0),
            lambda_t=float(lambda_t or 0.0),
            control_permissions_json=control_permissions_json,
            allowed_actions_str=allowed_actions_str,
            action_space_str=action_space_str,
            alpha_allowed_str=alpha_allowed_str,
            significant_negative=AgentThresholds.SIGNIFICANT_NEGATIVE,
            late_stage_ratio=AgentThresholds.LATE_STAGE_RATIO,
            rollback_threshold=float(rollback_threshold_val),
            rollback_mode=rollback_mode_str,
            k_definition=k_def,
            k_definition_desc=k_definition_desc,
            training_overload_epochs=AgentThresholds.TRAINING_OVERLOAD_EPOCHS,
            epochs_cap=AgentThresholds.EPOCHS_CAP,
            lambda_min=AgentConstraints.LAMBDA_MIN,
            lambda_max=AgentConstraints.LAMBDA_MAX,
            high_uncertainty_mean=AgentThresholds.HIGH_UNCERTAINTY_MEAN,
            high_uncertainty_std=AgentThresholds.HIGH_UNCERTAINTY_STD,
            long_tail_k_threshold=AgentThresholds.LONG_TAIL_K_THRESHOLD,
            min_labeled_for_novelty=AgentThresholds.MIN_LABELED_FOR_NOVELTY,
            lambda_adjust_range=AgentThresholds.LAMBDA_ADJUST_RANGE,
            max_tool_calls_per_phase=int(getattr(AgentConstraints, "MAX_TOOL_CALLS_PER_PHASE", 2) or 2),
            max_steps=int(getattr(AgentConstraints, "MAX_STEPS", 10) or 10),
            available_tools_str=available_tools_str
        )
        return formatted.replace('{{', '{').replace('}}', '}')

    def build_user_prompt(self, labeled_size=None, unlabeled_size=None, query_size=None):
        if query_size is None:
            base = "新一轮主动学习开始。请使用 get_system_status 获取系统状态并依据lambda_t选择最优样本。"
        else:
            base = f"新一轮主动学习开始。请使用 get_system_status 获取系统状态并依据lambda_t选择最优样本（如无错误，不要重复调用 get_system_status）。需选择{int(query_size)}个样本。"
        context = {}
        if labeled_size is not None:
            context["labeled_pool_size"] = int(labeled_size)
        if unlabeled_size is not None:
            context["unlabeled_pool_size"] = int(unlabeled_size)
        if context:
            return base + "\n\n上下文:\n" + json.dumps(context, ensure_ascii=False)
        return base
