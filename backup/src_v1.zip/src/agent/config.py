import numpy as np

class AgentThresholds:
    SIGNIFICANT_NEGATIVE = -0.02
    LATE_STAGE_RATIO = 0.7
    ROLLBACK_THRESHOLD = -0.01
    TRAINING_OVERLOAD_EPOCHS = 15
    LAMBDA_ADJUST_RANGE = 0.3
    EPOCHS_CAP = 20
    MIN_LABELED_FOR_NOVELTY = 5
    HIGH_UNCERTAINTY_MEAN = 0.5
    HIGH_UNCERTAINTY_STD = 0.2
    LONG_TAIL_K_QUANTILE = 0.75
    LONG_TAIL_K_THRESHOLD = 0.3

    @staticmethod
    def calculate_lambda_t(progress, alpha=5.0):
        return 1 / (1 + np.exp(-alpha * (progress - 0.5)))


class AgentConstraints:
    LAMBDA_MIN = 0.0
    LAMBDA_MAX = 1.0
    QUERY_SIZE_MIN = 1
    EPOCHS_MIN = 1
    EPOCHS_MAX = 20
    ALPHA_MIN = 0.1
    ALPHA_MAX = 20.0
    MAX_TOOL_CALLS_PER_PHASE = 3
    MAX_STEPS = 12
