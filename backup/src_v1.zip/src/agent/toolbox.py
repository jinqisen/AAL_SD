
import json
import hashlib
import numpy as np
from typing import Dict, List, Optional, Any, Union
from .config import AgentThresholds, AgentConstraints
from .exceptions import (
    StateError,
    DataError,
    InvalidParameterError,
    ConstraintViolationError
)

class Toolbox:
    def __init__(self, agent_controller: Any, query_strategy: Any, model: Any) -> None:
        """
        Agent 工具集，封装了 Agent 可以调用的所有 Python 函数
        Args:
            agent_controller: ActiveLearningAgent 实例 (包含 dataset, indices 等)
            query_strategy: QueryStrategy 实例 (负责计算 U/K)
            model: 当前训练好的模型
        """
        self.controller = agent_controller
        self.strategy = query_strategy
        self.model = model
        self.current_scores: Dict[str, Dict[str, float]] = {}
        self.candidates_cache: List[Dict[str, Any]] = []
        self.training_state: Dict[str, Any] = {}
        cfg = getattr(agent_controller, "config", None)
        self.alpha: float = float(getattr(cfg, "ALPHA", 5.0) if cfg is not None else 5.0)
        self.control_state: Dict[str, Any] = {}
        self.control_meta: Dict[str, Any] = {}
        self.control_permissions: Dict[str, bool] = {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False,
            "get_top_k_samples": True,
            "get_sample_details": True,
            "get_score_distribution": True,
            "get_system_status": True,
            "finalize_selection": True
        }
        self.SCHEMA_VERSION: int = 1
        self.last_score_error: Optional[Dict[str, Any]] = None

    def _success_response(self, result: Any, meta: Optional[Dict] = None) -> str:
        return json.dumps({
            "status": "success",
            "result": result,
            "meta": meta or {}
        })

    def _error_response(self, error_type: str, message: str, meta: Optional[Dict] = None) -> str:
        return json.dumps({
            "status": "error",
            "error_type": error_type,
            "message": message,
            "meta": meta or {}
        })

    def _parse_response(self, response_str: str) -> Dict[str, Any]:
        """
        兼容解析层：处理新旧两种返回结构
        Args:
            response_str: JSON string from tool
        Returns:
            dict with unified structure: {status, result/error_type/message, meta}
        """
        try:
            parsed = json.loads(response_str)
        except Exception:
            return {
                "status": "error",
                "error_type": "ParseError",
                "message": "Invalid JSON response",
                "meta": {}
            }
        
        if not isinstance(parsed, dict):
            return {
                "status": "error",
                "error_type": "ParseError",
                "message": "Response is not a dict",
                "meta": {}
            }
        
        if "status" in parsed:
            return parsed
        
        return {
            "status": "success",
            "result": parsed,
            "meta": {}
        }

    def precalculate_scores(self) -> None:
        """
        在每一轮 AL 开始前调用，预计算所有未标注样本的得分
        """
        self.last_score_error = None
        if hasattr(self.controller, "_last_score_precalc_error"):
            try:
                self.controller._last_score_precalc_error = None
            except Exception:
                pass

        print("Pre-calculating scores for all unlabeled samples...")
        cfg = getattr(self.controller, "config", None)
        dataset = getattr(self.controller, 'dataset', None) or getattr(self.controller, 'full_dataset', None)
        if dataset is None:
            self.current_scores = {}
            if (
                cfg is not None
                and getattr(cfg, "STRICT_INNOVATION", False)
                and getattr(cfg, "FAIL_ON_RANKING_DEGRADED", True)
            ):
                try:
                    self.controller._last_score_precalc_error = {
                        "phase": "score_precalc",
                        "exception": "DatasetMissing",
                        "message": "Dataset not found in controller"
                    }
                except Exception:
                    pass
                try:
                    self.controller._append_trace({
                        "type": "ranking_degraded",
                        "round": int(getattr(self.controller, "current_round", 0) or 0),
                        "degraded": {
                            "source": "toolbox",
                            "reason_type": "dataset_missing",
                            "policy": "no_scores"
                        }
                    })
                except Exception:
                    pass
                raise RuntimeError("STRICT_INNOVATION violation: ranking_degraded toolbox_dataset_missing")
            return
        try:
            u_norm, k_norm = self.strategy.calculate_scores(
                self.model,
                dataset,
                self.controller.unlabeled_indices,
                self.controller.labeled_indices
            )
        except Exception as e:
            err = {
                "phase": "score_precalc",
                "exception": e.__class__.__name__,
                "message": str(e)
            }
            self.last_score_error = dict(err)
            if hasattr(self.controller, "_last_score_precalc_error"):
                try:
                    self.controller._last_score_precalc_error = dict(err)
                except Exception:
                    pass
            self.current_scores = {}
            if (
                cfg is not None
                and getattr(cfg, "STRICT_INNOVATION", False)
                and getattr(cfg, "FAIL_ON_RANKING_DEGRADED", True)
            ):
                try:
                    self.controller._append_trace({
                        "type": "ranking_degraded",
                        "round": int(getattr(self.controller, "current_round", 0) or 0),
                        "degraded": {
                            "source": "toolbox",
                            "reason_type": "score_precalc_failed",
                            "policy": "no_scores",
                            "exception": e.__class__.__name__,
                            "message": str(e)
                        }
                    })
                except Exception:
                    pass
                raise RuntimeError("STRICT_INNOVATION violation: ranking_degraded toolbox_score_precalc_failed")
            return

        self.current_scores = {}
        for i, idx in enumerate(self.controller.unlabeled_indices):
            self.current_scores[str(idx)] = {
                'U': float(u_norm[i]),
                'K': float(k_norm[i])
            }
        print("Score calculation completed.")

    def get_system_status(self) -> str:
        """
        Tool: 获取当前系统状态（唯一权威状态工具）
        Returns: JSON string with unified structure
        """
        if not self._check_permission("get_system_status"):
            return self._error_response(
                "PermissionDenied",
                "get_system_status action is not allowed in current configuration",
                {"action": "get_system_status"}
            )
        try:
            t = len(self.controller.labeled_indices)
            dataset = getattr(self.controller, 'dataset', None) or getattr(self.controller, 'full_dataset', None)
            if dataset is None:
                raise StateError("Dataset not found in controller", {"controller_type": type(self.controller).__name__})
            total = len(dataset)
            total_budget = getattr(self.controller, 'config', None)
            t_max = getattr(total_budget, 'TOTAL_BUDGET', None) if total_budget is not None else None
            if t_max in (None, 0):
                t_max = int(total * 0.1)
            if t_max == 0:
                t_max = 1
            
            progress = t / t_max
            lambda_t = AgentThresholds.calculate_lambda_t(progress, self.alpha)
            
            warnings: List[str] = []
            
            last_miou = self.training_state.get('last_miou', 0.0)
            prev_miou = self.training_state.get('prev_miou', 0.0)
            miou_delta = last_miou - prev_miou
            
            if np.isnan(miou_delta) or np.isinf(miou_delta):
                miou_delta = 0.0
                warnings.append("miou_delta异常-使用默认值0.0")
            
            rollback_flag = self.training_state.get('rollback_flag', False)
            rollback_mode = self.training_state.get('rollback_mode', None)
            rollback_threshold = self.training_state.get('rollback_threshold', None)
            k_definition = self.training_state.get('k_definition', None)
            remaining_budget = max(0, t_max - t)
            
            status = {
                "current_labeled_count": t,
                "total_budget": t_max,
                "progress_ratio": round(progress, 4),
                "lambda_t": round(lambda_t, 4),
                "stage_description": "Early Stage" if progress < (1 - AgentThresholds.LATE_STAGE_RATIO) else ("Late Stage" if progress > AgentThresholds.LATE_STAGE_RATIO else "Middle Stage"),
                "last_miou": round(last_miou, 4),
                "prev_miou": round(prev_miou, 4),
                "miou_delta": round(miou_delta, 4),
                "rollback_flag": bool(rollback_flag),
                "rollback_mode": rollback_mode,
                "rollback_threshold": rollback_threshold,
                "k_definition": k_definition,
                "remaining_budget": int(remaining_budget)
            }
            
            meta = {
                "schema_version": self.SCHEMA_VERSION,
                "warnings": warnings if warnings else None
            }
            
            return self._success_response(status, meta)
        except StateError as e:
            return self._error_response(e.error_type, str(e), e.details)
        except Exception as e:
            return self._error_response("TOOL_FAILURE", f"获取系统状态失败: {str(e)}")

    def reset_round_controls(self) -> None:
        self.control_state: Dict[str, Any] = {}
        self.control_meta: Dict[str, Any] = {}

    def set_control_permissions(self, permissions: Dict[str, bool]) -> None:
        """
        设置控制动作权限（用于消融实验）
        Args:
            permissions: Dict[str, bool] - Key为工具名，Value为是否允许
        """
        # Setter 类默认为 False (需显式开启)
        setter_keys = {"set_lambda", "set_query_size", "set_epochs_per_round", "set_alpha"}
        # Getter 类默认为 True (需显式关闭)
        getter_keys = {"get_top_k_samples", "get_sample_details", "get_score_distribution", "get_system_status", "finalize_selection"}
        
        valid_keys = setter_keys | getter_keys
        
        # 重置为默认状态
        self.control_permissions = {}
        for k in setter_keys:
            self.control_permissions[k] = False
        for k in getter_keys:
            self.control_permissions[k] = True
            
        # 应用用户配置
        for key, value in (permissions or {}).items():
            if key in valid_keys:
                self.control_permissions[key] = bool(value)

    def _check_permission(self, action_name: str) -> bool:
        """
        检查控制动作权限
        Args:
            action_name: 控制动作名称
        Returns:
            bool: 是否允许执行该动作
        """
        return self.control_permissions.get(action_name, False)

    def _is_alpha_allowed(self) -> bool:
        return bool(self.control_permissions.get("set_alpha", False))

    def _default_lambda(self) -> float:
        try:
            labeled = len(getattr(self.controller, "labeled_indices", []) or [])
            dataset = getattr(self.controller, 'dataset', None) or getattr(self.controller, 'full_dataset', None)
            total = len(dataset) if dataset is not None else 0
            cfg = getattr(self.controller, 'config', None)
            t_max = getattr(cfg, 'TOTAL_BUDGET', None) if cfg is not None else None
            if t_max in (None, 0):
                t_max = int(total * 0.1) if total > 0 else 0
            if t_max == 0:
                t_max = 1
            progress = labeled / t_max
            return float(AgentThresholds.calculate_lambda_t(progress, self.alpha))
        except Exception:
            return 0.5

    def get_candidate_samples(self, top_k: int = 10, sort_by: str = 'U', lambda_param: Optional[float] = None) -> str:
        """
        Tool: 获取候选样本列表（已弃用，请使用 get_top_k_samples）
        Args:
            top_k: 返回前 K 个
            sort_by: 'U' (Uncertainty), 'K' (Knowledge), 'Hybrid' (Legacy, defaults to lambda=0.5)
            lambda_param: float (0.0 - 1.0). If provided, overrides sort_by. 
                          Score = (1 - lambda) * U + lambda * K
        """
        # Determine lambda
        final_lambda = 0.0
        if not self._check_permission("set_lambda"):
            final_lambda = self._default_lambda()
        elif lambda_param is not None:
            final_lambda = float(lambda_param)
        else:
            if sort_by == 'U':
                final_lambda = 0.0
            elif sort_by == 'K':
                final_lambda = 1.0
            elif sort_by == 'Hybrid':
                final_lambda = 0.5
            else:
                final_lambda = 0.5
                
        # 将 scores 转为 list 用于排序
        score_list = []
        for idx, scores in self.current_scores.items():
            item = {'id': idx, 'U': scores['U'], 'K': scores['K']}
            # Score = (1 - lambda) * U + lambda * K
            item['score'] = (1 - final_lambda) * scores['U'] + final_lambda * scores['K']
            score_list.append(item)
            
        # 降序排列
        score_list.sort(key=lambda x: x['score'], reverse=True)
        
        candidates = score_list[:int(top_k)]
        self.candidates_cache = candidates # 缓存，供后续选择验证
        meta = {
            'schema_version': self.SCHEMA_VERSION,
            'deprecated': True,
            'replacement': 'get_top_k_samples'
        }
        return self._success_response(candidates, meta)

    def get_top_k_samples(self, k: int = 5, lambda_param: Optional[float] = None) -> str:
        if not self._check_permission("get_top_k_samples"):
            return self._error_response(
                "PermissionDenied",
                "get_top_k_samples action is not allowed in current configuration",
                {"action": "get_top_k_samples"}
            )
        if not self._check_permission("set_lambda"):
            final_lambda = self._default_lambda()
        else:
            final_lambda = 0.5 if lambda_param is None else float(lambda_param)
        if not self.current_scores:
            cfg = getattr(self.controller, "config", None)
            unlabeled = list(getattr(self.controller, "unlabeled_indices", []) or [])
            salt = (
                f"{getattr(self.controller, 'run_id', '')}:"
                f"{getattr(self.controller, 'experiment_name', '')}:"
                f"{getattr(self.controller, 'current_round', '')}:toolbox_no_scores"
            )
            def _key(idx: Any) -> str:
                try:
                    v = int(idx)
                except Exception:
                    v = str(idx)
                return hashlib.sha256(f"{salt}:{v}".encode("utf-8")).hexdigest()

            ordered = sorted(unlabeled, key=_key)
            result = []
            for idx in ordered[: int(k)]:
                result.append({'id': str(idx), 'U_score': 0.0, 'K_score': 0.0, 'final_score': 0.0})
            self.candidates_cache = result
            meta = {
                'schema_version': self.SCHEMA_VERSION,
                'lambda_param': final_lambda,
                'k': int(k),
                'degraded': True,
                'degraded_policy': 'deterministic_hash',
                'degraded_reason': 'no_scores'
            }
            if hasattr(self.controller, "_last_ranking_degraded"):
                try:
                    self.controller._last_ranking_degraded = {
                        "source": "toolbox",
                        "reason_type": "no_scores",
                        "policy": "deterministic_hash",
                        "k": int(k),
                        "lambda_param": float(final_lambda)
                    }
                except Exception:
                    pass
            if (
                cfg is not None
                and getattr(cfg, "STRICT_INNOVATION", False)
                and getattr(cfg, "FAIL_ON_RANKING_DEGRADED", True)
            ):
                try:
                    self.controller._append_trace({
                        "type": "ranking_degraded",
                        "round": int(getattr(self.controller, "current_round", 0) or 0),
                        "degraded": dict(getattr(self.controller, "_last_ranking_degraded", {}) or {}),
                    })
                except Exception:
                    pass
                raise RuntimeError("STRICT_INNOVATION violation: ranking_degraded toolbox_no_scores")
            return self._success_response(result, meta)
        items = []
        for idx, scores in self.current_scores.items():
            s = (1 - final_lambda) * scores['U'] + final_lambda * scores['K']
            items.append({'id': idx, 'U_score': scores['U'], 'K_score': scores['K'], 'final_score': s})
        items.sort(key=lambda x: x['final_score'], reverse=True)
        result = items[:int(k)]
        self.candidates_cache = result
        meta = {
            'schema_version': self.SCHEMA_VERSION,
            'lambda_param': final_lambda,
            'k': int(k)
        }
        return self._success_response(result, meta)

    def set_lambda(self, lambda_value: Union[float, str], scope: str = "round") -> str:
        if not self._check_permission("set_lambda"):
            return self._error_response(
                "PermissionDenied",
                "set_lambda action is not allowed in current configuration",
                {"action": "set_lambda", "scope": scope}
            )
        try:
            v = float(lambda_value)
        except (ValueError, TypeError) as e:
            return self._error_response(
                "InvalidParameter",
                f"Invalid lambda value: {lambda_value}",
                {"parameter": "lambda_value", "value": str(lambda_value)}
            )
        suggested_lambda = None
        delta_from_suggested = None
        exceeds_suggested_range = None
        try:
            t = len(getattr(self.controller, 'labeled_indices', []) or [])
            total_budget = int(self.training_state.get('total_budget') or 0)
            if total_budget <= 0:
                total_budget = int(getattr(getattr(self.controller, 'config', None), 'TOTAL_BUDGET', 0) or 0)
            if total_budget > 0:
                progress = float(t) / float(max(1, total_budget))
                suggested_lambda = float(AgentThresholds.calculate_lambda_t(progress, self.alpha))
                delta_from_suggested = float(v) - float(suggested_lambda)
                exceeds_suggested_range = bool(abs(delta_from_suggested) > float(AgentThresholds.LAMBDA_ADJUST_RANGE))
        except Exception:
            suggested_lambda = None
            delta_from_suggested = None
            exceeds_suggested_range = None
        clamped = False
        reason = None
        if v < AgentConstraints.LAMBDA_MIN:
            v = AgentConstraints.LAMBDA_MIN
            clamped = True
            reason = f"min_{AgentConstraints.LAMBDA_MIN}"
        if v > AgentConstraints.LAMBDA_MAX:
            v = AgentConstraints.LAMBDA_MAX
            clamped = True
            reason = f"max_{AgentConstraints.LAMBDA_MAX}"
        self.control_state['lambda_override_round'] = v
        self.control_meta['lambda_override_round'] = {
            'clamped': bool(clamped),
            'clamp_reason': reason,
            'suggested_lambda': suggested_lambda,
            'delta_from_suggested': delta_from_suggested,
            'suggested_adjust_range': float(AgentThresholds.LAMBDA_ADJUST_RANGE),
            'exceeds_suggested_range': exceeds_suggested_range
        }
        if hasattr(self.controller, "_append_trace"):
            try:
                self.controller._append_trace({
                    "type": "lambda_override",
                    "round": int(getattr(self.controller, "current_round", 0) or 0),
                    "scope": str(scope or "round"),
                    "applied": float(v),
                    "suggested_lambda": suggested_lambda,
                    "delta_from_suggested": delta_from_suggested,
                    "suggested_adjust_range": float(AgentThresholds.LAMBDA_ADJUST_RANGE),
                    "exceeds_suggested_range": exceeds_suggested_range,
                    "clamped": bool(clamped),
                    "clamp_reason": reason
                })
            except Exception:
                pass
        payload = {
            'status': 'success',
            'applied': v,
            'scope': scope,
            'clamped': bool(clamped),
            'clamp_reason': reason,
            'suggested_lambda': suggested_lambda,
            'delta_from_suggested': delta_from_suggested,
            'suggested_adjust_range': float(AgentThresholds.LAMBDA_ADJUST_RANGE),
            'exceeds_suggested_range': exceeds_suggested_range
        }
        return json.dumps(payload)

    def set_query_size(self, query_size: Union[int, str], scope: str = "round") -> str:
        if not self._check_permission("set_query_size"):
            return self._error_response(
                "PermissionDenied",
                "set_query_size action is not allowed in current configuration",
                {"action": "set_query_size", "scope": scope}
            )
        try:
            q = int(query_size)
        except (ValueError, TypeError) as e:
            return self._error_response(
                "InvalidParameter",
                f"Invalid query_size value: {query_size}",
                {"parameter": "query_size", "value": str(query_size)}
            )
        remaining = None
        try:
            total_budget = int(self.training_state.get('total_budget') or 0)
            current_labeled = int(self.training_state.get('current_labeled_count') or 0)
            if total_budget > 0:
                remaining = max(0, total_budget - current_labeled)
        except (ValueError, TypeError):
            remaining = None
        if remaining is None:
            try:
                total_budget = int(getattr(getattr(self.controller, 'config', None), 'TOTAL_BUDGET', 0) or 0)
                current_labeled = int(len(getattr(self.controller, 'labeled_indices', []) or []))
                if total_budget > 0:
                    remaining = max(0, total_budget - current_labeled)
            except (ValueError, TypeError):
                remaining = None
        clamped = False
        reason = None
        if q < AgentConstraints.QUERY_SIZE_MIN:
            q = AgentConstraints.QUERY_SIZE_MIN
            clamped = True
            reason = f'min_{AgentConstraints.QUERY_SIZE_MIN}'
        if remaining is not None and q > remaining:
            q = remaining
            clamped = True
            reason = 'remaining_budget'
        self.control_state['query_size_round'] = q
        self.control_meta['query_size_round'] = {
            'clamped': bool(clamped),
            'clamp_reason': reason
        }
        try:
            if hasattr(self.controller, 'config'):
                self.controller.config.QUERY_SIZE = int(q)
        except (AttributeError, TypeError):
            pass
        payload = {
            'status': 'success',
            'applied': int(q),
            'scope': scope,
            'remaining_budget': int(remaining) if remaining is not None else None,
            'clamped': bool(clamped),
            'clamp_reason': reason
        }
        return json.dumps(payload)

    def set_epochs_per_round(self, epochs: Union[int, str], scope: str = "round") -> str:
        if not self._check_permission("set_epochs_per_round"):
            return self._error_response(
                "PermissionDenied",
                "set_epochs_per_round action is not allowed in current configuration",
                {"action": "set_epochs_per_round", "scope": scope}
            )
        try:
            e = int(epochs)
        except (ValueError, TypeError) as ex:
            return self._error_response(
                "InvalidParameter",
                f"Invalid epochs value: {epochs}",
                {"parameter": "epochs", "value": str(epochs)}
            )
        clamped = False
        reason = None
        if e < AgentConstraints.EPOCHS_MIN:
            e = AgentConstraints.EPOCHS_MIN
            clamped = True
            reason = f'min_{AgentConstraints.EPOCHS_MIN}'
        if e > AgentConstraints.EPOCHS_MAX:
            e = AgentConstraints.EPOCHS_MAX
            clamped = True
            reason = f'max_{AgentConstraints.EPOCHS_MAX}'
        self.control_state['epochs_round'] = e
        self.control_meta['epochs_round'] = {
            'clamped': bool(clamped),
            'clamp_reason': reason
        }
        try:
            if hasattr(self.controller, 'config'):
                self.controller.config.EPOCHS_PER_ROUND = int(e)
        except (AttributeError, TypeError) as ex:
            pass
        payload = {
            'status': 'success',
            'applied': int(e),
            'scope': scope,
            'clamped': bool(clamped),
            'clamp_reason': reason
        }
        return json.dumps(payload)

    def get_score_distribution(self, n_bins: int = 10, quantiles: Optional[List[float]] = None) -> str:
        if not self._check_permission("get_score_distribution"):
            return self._error_response(
                "PermissionDenied",
                "get_score_distribution action is not allowed in current configuration",
                {"action": "get_score_distribution"}
            )
        try:
            qts = quantiles if isinstance(quantiles, list) and quantiles else [0.25, 0.5, 0.75]
        except (TypeError, AttributeError) as ex:
            qts = [0.25, 0.5, 0.75]
        u_vals: List[float] = []
        k_vals: List[float] = []
        for v in self.current_scores.values():
            try:
                u_vals.append(float(v['U']))
                k_vals.append(float(v['K']))
            except (KeyError, TypeError, ValueError) as ex:
                continue
        h_vals: List[float] = []
        for u, k in zip(u_vals, k_vals):
            h_vals.append((u + k) * 0.5)
        import numpy as np
        def _stats(arr: List[float]) -> Dict[str, Any]:
            a = np.asarray(arr, dtype=float)
            if a.size == 0:
                return {'min': None, 'max': None, 'mean': None, 'std': None, 'quantiles': {}}
            qs = {str(p): float(np.quantile(a, p)) for p in qts}
            return {'min': float(np.min(a)), 'max': float(np.max(a)), 'mean': float(np.mean(a)), 'std': float(np.std(a)), 'quantiles': qs}
        def _hist(arr: List[float]) -> Dict[str, Any]:
            a = np.asarray(arr, dtype=float)
            if a.size == 0:
                return {'bins': [], 'counts': []}
            counts, bins = np.histogram(a, bins=int(n_bins))
            return {'bins': [float(x) for x in bins.tolist()], 'counts': [int(x) for x in counts.tolist()]}
        n_unlabeled = int(len(getattr(self.controller, 'unlabeled_indices', []) or []))
        payload = {
            'U_stats': _stats(u_vals),
            'K_stats': _stats(k_vals),
            'H_stats': _stats(h_vals),
            'histograms': {
                'U': _hist(u_vals),
                'K': _hist(k_vals),
                'H': _hist(h_vals)
            },
            'n_unlabeled': n_unlabeled
        }
        meta = {
            'schema_version': self.SCHEMA_VERSION,
            'n_bins': int(n_bins),
            'quantiles': qts
        }
        return self._success_response(payload, meta)

    def _to_numpy(self, value: Any) -> np.ndarray:
        if hasattr(value, 'detach'):
            return value.detach().cpu().numpy()
        return np.asarray(value)

    def _get_sample_metadata(self, idx: int) -> Dict[str, Any]:
        info: Dict[str, Any] = {}
        dataset = getattr(self.controller, 'dataset', None)
        if dataset is None:
            return info
        if idx < 0 or idx >= len(dataset):
            return info
        try:
            item = dataset[idx]
        except (IndexError, KeyError, TypeError) as ex:
            return info

        image = None
        mask = None
        name = None

        if isinstance(item, (tuple, list)):
            if len(item) >= 1:
                image = item[0]
            if len(item) >= 2:
                if isinstance(item[1], str):
                    name = item[1]
                else:
                    mask = item[1]
        else:
            image = item

        if name is None and hasattr(dataset, 'images'):
            try:
                name = dataset.images[idx]
            except (IndexError, KeyError, TypeError) as ex:
                name = None

        if name is not None:
            info['image_name'] = name

        if hasattr(dataset, 'split'):
            info['split'] = dataset.split

        if image is not None:
            img_np = self._to_numpy(image)
            info['image_mean'] = float(np.mean(img_np))
            info['image_std'] = float(np.std(img_np))

        if mask is not None:
            mask_np = self._to_numpy(mask)
            info['mask_positive_ratio'] = float(np.mean(mask_np > 0))

        info['in_labeled_pool'] = idx in self.controller.labeled_indices
        info['in_unlabeled_pool'] = idx in self.controller.unlabeled_indices
        return info

    def get_sample_details(self, sample_id: Union[int, str]) -> str:
        if not self._check_permission("get_sample_details"):
            return self._error_response(
                "PermissionDenied",
                "get_sample_details action is not allowed in current configuration",
                {"action": "get_sample_details"}
            )
        sid = str(sample_id)
        info = {'id': sid}
        if sid in self.current_scores:
            scores = self.current_scores[sid]
            info.update({
                'U_score': scores['U'],
                'K_score': scores['K']
            })
        try:
            idx = int(sample_id)
        except (ValueError, TypeError) as ex:
            idx = None
        if idx is not None:
            info.update(self._get_sample_metadata(idx))
        return json.dumps({'status': 'success', 'result': info})

    def get_training_status(self) -> str:
        return json.dumps({'status': 'success', 'result': {'training_status': self.training_state}})

    def set_hyperparameter(self, alpha: Union[float, str]) -> str:
        if not self._check_permission("set_alpha"):
            return self._error_response(
                "PermissionDenied",
                "set_hyperparameter action is not allowed in current configuration",
                {"action": "set_hyperparameter"}
            )
        try:
            alpha_val = float(alpha)
        except (ValueError, TypeError) as ex:
            return self._error_response(
                "InvalidParameter",
                f"Invalid alpha value: {alpha}",
                {"parameter": "alpha", "value": str(alpha)}
            )
        clamped = False
        reason = None
        if alpha_val < AgentConstraints.ALPHA_MIN:
            alpha_val = float(AgentConstraints.ALPHA_MIN)
            clamped = True
            reason = f"min_{AgentConstraints.ALPHA_MIN}"
        if alpha_val > AgentConstraints.ALPHA_MAX:
            alpha_val = float(AgentConstraints.ALPHA_MAX)
            clamped = True
            reason = f"max_{AgentConstraints.ALPHA_MAX}"

        try:
            self.alpha = float(alpha_val)
            if hasattr(self.strategy, 'alpha'):
                self.strategy.alpha = float(alpha_val)
            if hasattr(self.controller, 'config') and hasattr(self.controller.config, 'ALPHA'):
                self.controller.config.ALPHA = float(alpha_val)
            self.control_state['alpha'] = float(alpha_val)
            self.control_meta['alpha'] = {
                'clamped': bool(clamped),
                'clamp_reason': reason
            }
            return json.dumps({'status': 'success', 'alpha': self.alpha, 'clamped': bool(clamped), 'clamp_reason': reason})
        except (AttributeError, TypeError) as ex:
            return self._error_response(
                "StateError",
                f"Failed to set alpha: {str(ex)}",
                {"alpha": alpha_val}
            )

    def set_training_state(self, state: Dict[str, Any]) -> None:
        self.training_state: Dict[str, Any] = dict(state or {})
        
        required_fields: Dict[str, Any] = {
            'last_miou': 0.0,
            'prev_miou': 0.0,
            'rollback_flag': False
        }
        
        for field, default_value in required_fields.items():
            if field not in self.training_state:
                self.training_state[field] = default_value

    def finalize_selection(self, sample_ids: List[str], reason: str, thought: Optional[str] = None) -> str:
        """
        Tool: 提交最终选择
        Args:
            sample_ids: list of strings (sample indices)
            reason: string
            thought: string (Agent的推理过程)
        """
        # 真正更新 Agent 状态
        result: Dict[str, Any] = {
            "status": "error",
            "selected_count": 0,
            "reason_recorded": reason
        }
        if hasattr(self.controller, 'update'):
            try:
                if hasattr(self.controller, "_selection_context"):
                    try:
                        ctx = {
                            "source": "agent",
                            "policy": "agent_finalize_selection",
                            "sampler_type": getattr(self.controller, "sampler_type", None),
                            "experiment_name": getattr(self.controller, "experiment_name", None),
                            "current_round": getattr(self.controller, "current_round", None),
                            "decision_reason": reason,
                            "llm_mode": "mock_no_api_key" if str(reason) == "mock_no_api_key" else None
                        }
                        self.controller._selection_context = ctx
                    except Exception:
                        pass
                update_result = self.controller.update(sample_ids)
                if isinstance(update_result, dict):
                    result.update(update_result)
                else:
                    result["status"] = "success"
            except (AttributeError, TypeError, KeyError) as ex:
                result["status"] = "error"
                result["error"] = str(ex)
        applied: Dict[str, Any] = {
            'lambda': self.control_state.get('lambda_override_round'),
            'query_size': self.control_state.get('query_size_round'),
            'epochs': self.control_state.get('epochs_round'),
            'alpha': self.control_state.get('alpha')
        }
        violations: Dict[str, Any] = dict(self.control_meta or {})
        result['decision_reason'] = reason
        result['control_applied'] = applied
        result['violations'] = violations
        try:
            constraints: Dict[str, Any] = {
                'remaining_budget': int(self.training_state.get('total_budget') or 0) - int(self.training_state.get('current_labeled_count') or 0) if self.training_state else None,
                'epochs_cap': AgentThresholds.EPOCHS_CAP
            }
            action: Dict[str, Any] = {
                'selected_ids': result.get('selected_ids') or sample_ids,
                'query_size': applied.get('query_size'),
                'epochs': applied.get('epochs'),
                'lambda': applied.get('lambda')
            }
            event: Dict[str, Any] = {
                'type': 'controller_step',
                'round': int(getattr(self.controller, 'current_round', 0) or 0),
                'state': dict(self.training_state or {}),
                'action': action,
                'constraints': constraints,
                'outcome_ref': {
                    'expected': result.get('expected_count'),
                    'selected': result.get('selected_count')
                },
                'reasoning': thought
            }
            self.controller._append_trace(event)
        except (AttributeError, TypeError, KeyError) as ex:
            pass
        return json.dumps(result)

    def reset(self) -> None:
        """
        Reset toolbox state to prevent contamination between experiments.
        Clears cached candidates, scores, and training state.
        """
        self.candidates_cache = []
        self.current_scores = {}
        self.training_state = {}
