import torch
import numpy as np
from tqdm import tqdm
import torch.nn.functional as F
from sklearn.cluster import KMeans
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agent.config import AgentThresholds


class ADKUCSSampler:
    def __init__(self, device="cpu", alpha=5.0, k_definition: str = "clustering"):
        self.device = device
        self.alpha = alpha
        self.k_definition = str(k_definition or "clustering")

    def _max_pairwise_distance(self, features: np.ndarray) -> float:
        x = np.asarray(features)
        if x.ndim != 2 or len(x) < 2:
            return 0.0
        x = x.astype(np.float32, copy=False)
        norms2 = np.einsum("ij,ij->i", x, x)
        gram = x @ x.T
        dist2 = norms2[:, None] + norms2[None, :] - 2.0 * gram
        dist2 = np.maximum(dist2, 0.0)
        max_dist2 = float(np.max(dist2))
        if not np.isfinite(max_dist2) or max_dist2 <= 0.0:
            return 0.0
        return float(np.sqrt(max_dist2))

    def _coreset_to_labeled_scores(
        self, features: np.ndarray, labeled_features: np.ndarray
    ) -> np.ndarray:
        x = np.asarray(features)
        lf = np.asarray(labeled_features)

        if x.ndim != 2 or len(x) == 0:
            return np.zeros((0,), dtype=np.float32)
        if lf.ndim != 2 or len(lf) == 0:
            return np.ones((len(x),), dtype=np.float32)
        if x.shape[1] != lf.shape[1]:
            return np.ones((len(x),), dtype=np.float32)

        x = x.astype(np.float32, copy=False)
        lf = lf.astype(np.float32, copy=False)

        max_dist = self._max_pairwise_distance(lf)
        if max_dist < 1e-10:
            return np.zeros((len(x),), dtype=np.float32)

        lf_norms2 = np.einsum("ij,ij->i", lf, lf)
        x_norms2 = np.einsum("ij,ij->i", x, x)
        dot = lf @ x.T
        dist2 = lf_norms2[:, None] + x_norms2[None, :] - 2.0 * dot
        dist2 = np.maximum(dist2, 0.0)
        min_dist2 = np.min(dist2, axis=0)
        min_dist = np.sqrt(min_dist2)
        scores = min_dist / float(max_dist)
        scores = np.where(np.isfinite(scores), scores, 0.0)
        return scores.astype(np.float32, copy=False)

    def _normalize_scores(self, scores: np.ndarray) -> np.ndarray:
        scores = np.asarray(scores)
        min_val = np.min(scores)
        max_val = np.max(scores)
        if max_val - min_val < 1e-10:
            return np.zeros_like(scores)
        return (scores - min_val) / (max_val - min_val)

    def _calculate_uncertainty(self, prob_map: np.ndarray) -> float:
        eps = 1e-10
        entropy = -np.sum(prob_map * np.log2(prob_map + eps), axis=0)
        return float(np.mean(entropy))

    def _calculate_bald_score(self, mc_predictions: np.ndarray) -> float:
        """
        计算BALD分数（互信息）

        Args:
            mc_predictions: (n_samples, C, H, W) MC Dropout预测

        Returns:
            互信息值（标量）
        """
        eps = 1e-10

        mean_pred = np.mean(mc_predictions, axis=0)
        predictive_entropy = -np.sum(mean_pred * np.log2(mean_pred + eps), axis=0)
        sample_entropies = -np.sum(
            mc_predictions * np.log2(mc_predictions + eps), axis=1
        )
        expected_entropy = np.mean(sample_entropies, axis=0)
        mutual_info = predictive_entropy - expected_entropy

        return float(np.mean(mutual_info))

    def calculate_bald_scores(
        self, model, dataset, unlabeled_indices, n_mc_samples: int = 10
    ) -> tuple:
        """
        计算所有未标注样本的BALD分数

        **学术严谨性**:
        本方法通过MC Dropout采样计算BALD分数，不支持降级。

        Args:
            model: PyTorch模型（必须支持MC Dropout）
            dataset: 数据集
            unlabeled_indices: 未标注样本索引
            n_mc_samples: MC Dropout采样次数

        Returns:
            (bald_scores_list, sample_ids)
            - bald_scores_list: 每个样本的BALD分数
            - sample_ids: 对应的样本ID

        Raises:
            RuntimeError: MC Dropout采样失败
        """
        from torch.utils.data import DataLoader, Subset

        subset_u = Subset(dataset, unlabeled_indices)
        loader_u = DataLoader(subset_u, batch_size=8, shuffle=False, num_workers=0)

        mc_probs_dict, _ = self.get_predictions_and_features(
            model, loader_u, mc_dropout=True, n_mc_samples=n_mc_samples
        )

        if mc_probs_dict is None or len(mc_probs_dict) == 0:
            raise RuntimeError(
                "MC Dropout sampling failed. Ensure model has Dropout layers "
                "and n_mc_samples >= 1."
            )

        bald_scores = []
        sample_ids = []

        for i, idx in enumerate(unlabeled_indices):
            # mc_probs_dict keys are 0..N-1 (subset indices), corresponding to the order of unlabeled_indices
            if i in mc_probs_dict:
                mc_pred = np.array(mc_probs_dict[i])
                bald_score = self._calculate_bald_score(mc_pred)
            else:
                raise RuntimeError(f"Missing MC predictions for subset index {i} (sample index {idx})")

            bald_scores.append(bald_score)
            sample_ids.append(idx)

        return bald_scores, sample_ids

    def _cluster_features(self, features: np.ndarray, n_clusters: int = 10) -> tuple:
        if len(features) < n_clusters:
            n_clusters = max(2, len(features) // 2)
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        cluster_labels = kmeans.fit_predict(features)
        cluster_centers = kmeans.cluster_centers_
        return cluster_labels, cluster_centers

    def _calculate_knowledge_gain_clustering(
        self,
        sample_feature: np.ndarray,
        cluster_labels: np.ndarray,
        cluster_centers: np.ndarray,
    ) -> float:
        if cluster_centers is None or len(cluster_centers) == 0:
            return 0.0
        dists = np.linalg.norm(cluster_centers - sample_feature, axis=1)
        assigned = int(np.argmin(dists))
        distance_to_center = float(dists[assigned])
        if len(cluster_centers) == 1:
            return 0.0
        max_distance = 0.0
        for i in range(len(cluster_centers)):
            for j in range(i + 1, len(cluster_centers)):
                dij = float(np.linalg.norm(cluster_centers[i] - cluster_centers[j]))
                if dij > max_distance:
                    max_distance = dij
        if max_distance < 1e-10:
            return 0.0
        return float(distance_to_center / max_distance)

    def _calculate_knowledge_gain(
        self, sample_feature: np.ndarray, labeled_features: np.ndarray
    ) -> float:
        if labeled_features is None or len(labeled_features) == 0:
            return 1.0
        labeled_features = np.asarray(labeled_features)
        if labeled_features.ndim != 2:
            return 1.0
        sample_feature = np.asarray(sample_feature)
        if (
            sample_feature.ndim != 1
            or labeled_features.shape[1] != sample_feature.shape[0]
        ):
            return 1.0
        dists = np.linalg.norm(labeled_features - sample_feature, axis=1)
        min_dist = float(np.min(dists))
        max_distance = self._max_pairwise_distance(labeled_features)
        if max_distance < 1e-10 or not np.isfinite(min_dist):
            return 0.0
        return float(min_dist / max_distance)

    def _get_adaptive_weight(
        self, current_iteration: int, total_iterations: int, override: float = None
    ) -> float:
        if override is not None:
            return float(override)
        total_iterations = max(int(total_iterations), 1)
        progress = float(current_iteration) / total_iterations
        return AgentThresholds.calculate_lambda_t(progress, alpha=self.alpha)

    def get_predictions_and_features(
        self, model, data_loader, mc_dropout: bool = False, n_mc_samples: int = 10
    ):
        """
        获取模型预测和特征

        Args:
            model: PyTorch模型
            data_loader: 数据加载器
            mc_dropout: 是否启用MC Dropout（用于BALD等贝叶斯方法）
            n_mc_samples: MC Dropout采样次数

        Returns:
            如果mc_dropout=False: (probs_tensor, features_tensor)
            如果mc_dropout=True: (mc_probs_dict, features_tensor)
                mc_probs_dict: {sample_idx: (n_mc_samples, C, H, W)}
        """
        model.eval()
        probs_list = []
        collected_features = []
        features_list = []

        def hook_fn(module, input, output):
            gap = F.adaptive_avg_pool2d(output, (1, 1)).flatten(1)
            features_list.append(gap.detach().cpu())

        layer = None
        if hasattr(model, "backbone"):
            layer = getattr(model.backbone, "layer4", None)
        if (
            layer is None
            and hasattr(model, "model")
            and hasattr(model.model, "encoder")
        ):
            layer = getattr(model.model, "encoder", None)
            if layer is not None:
                layer = getattr(layer, "layer4", None)

        if layer is None:
            candidates = ["features", "avgpool", "layer4", "layer3", "mixed_7c"]
            for name in candidates:
                if hasattr(model, name):
                    layer = getattr(model, name)
                    break
                if hasattr(model, "module") and hasattr(model.module, name):
                    layer = getattr(model.module, name)
                    break

        handle = None
        if layer is not None:
            handle = layer.register_forward_hook(hook_fn)

        mc_probs_dict = {} if mc_dropout else None
        sample_idx = 0

        if mc_dropout:
            model.enable_mc_dropout(True)
            with torch.no_grad():
                for batch in tqdm(data_loader, desc="MC Dropout Sampling"):
                    if isinstance(batch, (list, tuple)):
                        if len(batch) >= 1:
                            images = batch[0]
                        else:
                            continue
                    else:
                        images = batch

                    images = images.to(self.device)
                    batch_size = images.shape[0]

                    mc_batch_probs = []
                    for _ in range(n_mc_samples):
                        logits = model(images)
                        probs = F.softmax(logits, dim=1)
                        mc_batch_probs.append(probs.cpu().numpy())

                    mc_batch_probs = np.stack(mc_batch_probs, axis=0)
                    for i in range(batch_size):
                        mc_probs_dict[sample_idx + i] = mc_batch_probs[:, i, :, :, :]

                    probs_list.append(mc_batch_probs.mean(axis=0))
                    sample_idx += batch_size

            model.enable_mc_dropout(False)
        else:
            with torch.no_grad():
                for batch in tqdm(data_loader, desc="Querying Samples"):
                    if isinstance(batch, (list, tuple)):
                        if len(batch) >= 1:
                            images = batch[0]
                        else:
                            continue
                    else:
                        images = batch

                    images = images.to(self.device)
                    logits = model(images)
                    probs = F.softmax(logits, dim=1)
                    probs_list.append(probs.cpu())

        if handle is not None:
            handle.remove()

        features_tensor = torch.cat(features_list) if features_list else None

        if mc_dropout:
            return mc_probs_dict, features_tensor
        else:
            if not probs_list:
                return None, None
            probs_tensor = torch.cat(probs_list)
            return probs_tensor, features_tensor

    def calculate_scores(self, model, dataset, unlabeled_indices, labeled_indices=None):
        from torch.utils.data import DataLoader, Subset

        subset_u = Subset(dataset, unlabeled_indices)
        loader_u = DataLoader(subset_u, batch_size=8, shuffle=False, num_workers=0)
        probs_u, features_u = self.get_predictions_and_features(model, loader_u)
        if probs_u is None or features_u is None:
            raise RuntimeError(
                "Feature extraction failed: missing probabilities or features"
            )
        u_scores = []
        for prob_map in probs_u.numpy():
            u_scores.append(self._calculate_uncertainty(prob_map))

        features_u_np = features_u.numpy()

        # FIX: Extract Labeled Features for K-term (Diversity/Novelty) consistency
        labeled_features_np = None
        if labeled_indices is not None and len(labeled_indices) > 0:
            subset_l = Subset(dataset, labeled_indices)
            loader_l = DataLoader(subset_l, batch_size=8, shuffle=False, num_workers=0)
            _, features_l = self.get_predictions_and_features(model, loader_l)
            if features_l is not None:
                labeled_features_np = features_l.numpy()

        k_def = str(getattr(self, "k_definition", None) or "clustering")

        k_scores = []
        if k_def == "coreset_to_labeled":
            if labeled_features_np is not None and len(labeled_features_np) > 0:
                k_scores = self._coreset_to_labeled_scores(
                    features_u_np, labeled_features_np
                ).tolist()
            else:
                cluster_labels, cluster_centers = self._cluster_features(features_u_np)
                for feature in features_u_np:
                    raw_dist = self._calculate_knowledge_gain_clustering(
                        feature, cluster_labels, cluster_centers
                    )
                    k_scores.append(1.0 - raw_dist)
        else:
            use_labeled_for_k = (
                labeled_features_np is not None
                and len(labeled_features_np) >= AgentThresholds.MIN_LABELED_FOR_NOVELTY
            )

            if use_labeled_for_k:
                cluster_labels, cluster_centers = self._cluster_features(
                    labeled_features_np
                )
            else:
                cluster_labels, cluster_centers = self._cluster_features(features_u_np)

            for feature in features_u_np:
                raw_dist = self._calculate_knowledge_gain_clustering(
                    feature, cluster_labels, cluster_centers
                )
                if use_labeled_for_k:
                    k_scores.append(raw_dist)
                else:
                    k_scores.append(1.0 - raw_dist)

        u_norm = self._normalize_scores(np.array(u_scores))
        k_norm = self._normalize_scores(np.array(k_scores))
        return u_norm, k_norm

    def rank_samples(
        self,
        unlabeled_info: dict,
        labeled_features: np.ndarray,
        current_iteration: int,
        total_iterations: int,
        lambda_override: float = None,
    ) -> list:
        if not isinstance(unlabeled_info, dict) or not unlabeled_info:
            return []
        sample_ids = list(unlabeled_info.keys())
        u_scores = []
        features_list = []
        for sample_id in sample_ids:
            info = unlabeled_info[sample_id]
            u_scores.append(self._calculate_uncertainty(info["prob_map"]))
            features_list.append(info["feature"])

        features_array = np.array(features_list)

        k_def = str(getattr(self, "k_definition", None) or "clustering")

        k_scores = []
        if k_def == "coreset_to_labeled":
            lf = np.asarray(labeled_features) if labeled_features is not None else None
            if lf is not None and lf.ndim == 2 and len(lf) > 0:
                k_scores = self._coreset_to_labeled_scores(features_array, lf).tolist()
            else:
                cluster_labels, cluster_centers = self._cluster_features(features_array)
                for feature in features_array:
                    raw_dist = self._calculate_knowledge_gain_clustering(
                        feature, cluster_labels, cluster_centers
                    )
                    k_scores.append(1.0 - raw_dist)
        else:
            cluster_labels, cluster_centers = self._cluster_features(features_array)
            for feature in features_array:
                k_scores.append(
                    self._calculate_knowledge_gain_clustering(
                        feature, cluster_labels, cluster_centers
                    )
                )

        u_scores_norm = self._normalize_scores(np.array(u_scores))
        k_scores_norm = self._normalize_scores(np.array(k_scores))
        lambda_t = self._get_adaptive_weight(
            current_iteration, total_iterations, lambda_override
        )
        final_scores = (1 - lambda_t) * u_scores_norm + lambda_t * k_scores_norm
        ranked_list = sorted(
            zip(sample_ids, final_scores, u_scores_norm, k_scores_norm),
            key=lambda x: x[1],
            reverse=True,
        )
        return [
            {
                "sample_id": item[0],
                "final_score": float(item[1]),
                "uncertainty": float(item[2]),
                "knowledge_gain": float(item[3]),
                "lambda_t": float(lambda_t)
            }
            for item in ranked_list
        ]
