
# experiments/ablation_config.py

ABLATION_SETTINGS = {
    "full_model": {
        "description": "完整模型（正式方案）：coreset-to-labeled K + 自适应阈值 rollback + 风险驱动 λ 闭环控制（不调整 query_size）",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "warmup_start_round": 2,
            "warmup_rounds": 1,
            "warmup_lambda_range": [0.2, 0.25],
            "risk_control_start_round": 3
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "full_model_fixed_epochs_lambda_budget": {
        "description": "消融（固定epochs=10）：仅允许控制λ与query_size",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "control_permissions": {
            "set_lambda": True,
            "set_query_size": True,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "no_agent": {
        "description": "消融：移除Agent，仅使用固定规则的AD-KUCS选样",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": None
    },
    "uncertainty_only": {
        "description": "固定λ=0，仅使用不确定性",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": 0.0
    },
    "knowledge_only": {
        "description": "固定λ=1，仅使用知识增益",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": 1.0
    },
    "fixed_lambda": {
        "description": "固定λ=0.5",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": 0.5
    },
    "baseline_random": {
        "description": "随机采样基线",
        "use_agent": False,
        "sampler_type": "random",
        "lambda_override": None
    },
    "baseline_entropy": {
        "description": "熵采样基线",
        "use_agent": False,
        "sampler_type": "entropy",
        "lambda_override": None
    },
    "baseline_coreset": {
        "description": "Core-Set采样基线",
        "use_agent": False,
        "sampler_type": "coreset",
        "lambda_override": None
    },
    "baseline_bald": {
        "description": "BALD采样基线",
        "use_agent": False,
        "sampler_type": "bald",
        "lambda_override": None
    },
    "baseline_llm_us": {
        "description": "LLM仅基于不确定性分数",
        "use_agent": False,
        "sampler_type": "llm_us",
        "lambda_override": None
    },
    "baseline_llm_rs": {
        "description": "LLM仅基于随机分数",
        "use_agent": False,
        "sampler_type": "llm_rs",
        "lambda_override": None
    },
    "agent_control_lambda": {
        "description": "Agent控制消融：仅允许set_lambda",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "control_permissions": {
            "set_lambda": True,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "agent_control_budget": {
        "description": "Agent控制消融：仅允许set_query_size",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": True,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    }
}

MULTI_SEED_DEFAULTS = {
    "seeds": [42, 43, 44],
    "paper_experiments": [
        "full_model",
        "baseline_entropy",
        "baseline_random",
        "no_agent",
        "fixed_lambda",
    ],
}
