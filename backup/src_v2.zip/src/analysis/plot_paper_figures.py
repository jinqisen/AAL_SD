import argparse
import json
import re
import statistics
import textwrap
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


def _read_json(path: Path) -> Dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as f:
            obj = json.load(f)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return ""


def _iter_jsonl(path: Path):
    try:
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                if isinstance(obj, dict):
                    yield obj
    except Exception:
        return


def _parse_ts(ts: Any) -> Optional[datetime]:
    if not isinstance(ts, str):
        return None
    try:
        return datetime.fromisoformat(ts)
    except Exception:
        return None


def _t_critical_95(df: int) -> float:
    if df <= 0:
        return float("nan")
    if df == 1:
        return 12.706
    if df == 2:
        return 4.303
    if df == 3:
        return 3.182
    if df == 4:
        return 2.776
    if df == 5:
        return 2.571
    if df == 6:
        return 2.447
    if df == 7:
        return 2.365
    if df == 8:
        return 2.306
    if df == 9:
        return 2.262
    if df == 10:
        return 2.228
    return 1.96


def _summarize(values: List[float]) -> Dict[str, Any]:
    xs = [float(v) for v in values if v is not None and np.isfinite(float(v))]
    n = len(xs)
    if n <= 0:
        return {"n": 0, "mean": float("nan"), "std": float("nan"), "ci95": float("nan")}
    if n == 1:
        return {"n": 1, "mean": float(xs[0]), "std": 0.0, "ci95": float("nan")}
    mean = float(statistics.fmean(xs))
    std = float(statistics.stdev(xs))
    sem = std / float(np.sqrt(n))
    t = _t_critical_95(n - 1)
    ci95 = float(t * sem)
    return {"n": int(n), "mean": mean, "std": std, "ci95": ci95}


def _load_json_obj(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _discover_multi_seed_run_ids(group_dir: Path) -> List[str]:
    manifest = _load_json_obj(group_dir / "multi_seed_manifest.json")
    if isinstance(manifest, dict):
        run_ids = manifest.get("run_ids")
        if isinstance(run_ids, list) and all(isinstance(x, str) for x in run_ids):
            return [str(x) for x in run_ids]
    return []


def _load_multi_seed_summary(group_dir: Path) -> Dict[str, Any]:
    payload = _load_json_obj(group_dir / "multi_seed_summary.json")
    return payload if isinstance(payload, dict) else {}


@dataclass(frozen=True)
class ExperimentPaths:
    name: str
    status_path: Path
    trace_path: Path


def discover_experiments(run_dir: Path) -> Tuple[Dict[str, Any], List[ExperimentPaths]]:
    manifest = _read_json(run_dir / "manifest.json")
    exps: List[ExperimentPaths] = []
    for status_path in sorted(run_dir.glob("*_status.json")):
        name = status_path.name[: -len("_status.json")]
        trace_path = run_dir / f"{name}_trace.jsonl"
        exps.append(ExperimentPaths(name=name, status_path=status_path, trace_path=trace_path))
    return manifest, exps


def load_status_metrics(status_path: Path) -> Dict[str, Any]:
    payload = _read_json(status_path)
    result = payload.get("result") if isinstance(payload.get("result"), dict) else {}
    return {
        "status": payload.get("status"),
        "alc": result.get("alc"),
        "final_mIoU": result.get("final_mIoU"),
        "final_f1": result.get("final_f1"),
        "budget_history": result.get("budget_history"),
    }


def parse_trace(trace_path: Path) -> Tuple[pd.DataFrame, pd.DataFrame]:
    epoch_rows: List[Dict[str, Any]] = []
    ctrl_rows: List[Dict[str, Any]] = []

    if not trace_path.exists():
        return pd.DataFrame(), pd.DataFrame()

    for e in _iter_jsonl(trace_path):
        et = e.get("type")
        if et == "epoch_end":
            grad = e.get("grad") if isinstance(e.get("grad"), dict) else {}
            total_norm = grad.get("total_norm") if isinstance(grad.get("total_norm"), dict) else {}
            backbone_norm = grad.get("backbone_norm") if isinstance(grad.get("backbone_norm"), dict) else {}
            head_norm = grad.get("head_norm") if isinstance(grad.get("head_norm"), dict) else {}
            cos_consecutive = grad.get("cos_consecutive") if isinstance(grad.get("cos_consecutive"), dict) else {}
            cos_to_mean = grad.get("cos_to_mean") if isinstance(grad.get("cos_to_mean"), dict) else {}
            epoch_rows.append(
                {
                    "round": e.get("round"),
                    "epoch": e.get("epoch"),
                    "labeled_size": e.get("labeled_size"),
                    "mIoU": e.get("mIoU"),
                    "f1": e.get("f1"),
                    "ts": e.get("ts"),
                    "grad_total_norm_mean": total_norm.get("mean"),
                    "grad_backbone_norm_mean": backbone_norm.get("mean"),
                    "grad_head_norm_mean": head_norm.get("mean"),
                    "grad_cos_consecutive_mean": cos_consecutive.get("mean"),
                    "grad_cos_to_mean_mean": cos_to_mean.get("mean"),
                    "grad_train_val_cos": grad.get("train_val_cos"),
                    "grad_n_probe_batches": grad.get("n_probe_batches"),
                }
            )
        elif et == "controller_step":
            action = e.get("action") if isinstance(e.get("action"), dict) else {}
            state = e.get("state") if isinstance(e.get("state"), dict) else {}
            ctrl_rows.append(
                {
                    "round": e.get("round"),
                    "lambda": action.get("lambda"),
                    "epochs": action.get("epochs"),
                    "query_size": action.get("query_size"),
                    "rollback_flag": state.get("rollback_flag"),
                    "miou_delta": state.get("miou_delta"),
                    "last_miou": state.get("last_miou"),
                    "ts": e.get("ts"),
                }
            )

    df_epoch = pd.DataFrame(epoch_rows)
    df_ctrl = pd.DataFrame(ctrl_rows)

    if not df_epoch.empty:
        df_epoch["round"] = pd.to_numeric(df_epoch["round"], errors="coerce")
        df_epoch["epoch"] = pd.to_numeric(df_epoch["epoch"], errors="coerce")
        df_epoch["labeled_size"] = pd.to_numeric(df_epoch["labeled_size"], errors="coerce")
        df_epoch["mIoU"] = pd.to_numeric(df_epoch["mIoU"], errors="coerce")
        df_epoch["f1"] = pd.to_numeric(df_epoch["f1"], errors="coerce")
        for col in [
            "grad_total_norm_mean",
            "grad_backbone_norm_mean",
            "grad_head_norm_mean",
            "grad_cos_consecutive_mean",
            "grad_cos_to_mean_mean",
            "grad_train_val_cos",
            "grad_n_probe_batches",
        ]:
            if col in df_epoch.columns:
                df_epoch[col] = pd.to_numeric(df_epoch[col], errors="coerce")

    if not df_ctrl.empty:
        df_ctrl["round"] = pd.to_numeric(df_ctrl["round"], errors="coerce")
        df_ctrl["lambda"] = pd.to_numeric(df_ctrl["lambda"], errors="coerce")
        df_ctrl["epochs"] = pd.to_numeric(df_ctrl["epochs"], errors="coerce")
        df_ctrl["query_size"] = pd.to_numeric(df_ctrl["query_size"], errors="coerce")
        df_ctrl["miou_delta"] = pd.to_numeric(df_ctrl["miou_delta"], errors="coerce")
        df_ctrl["last_miou"] = pd.to_numeric(df_ctrl["last_miou"], errors="coerce")

    return df_epoch, df_ctrl


def build_round_curve(df_epoch: pd.DataFrame) -> pd.DataFrame:
    if df_epoch.empty:
        return pd.DataFrame()

    g = df_epoch.dropna(subset=["round"]).copy()
    g["round"] = g["round"].astype(int)
    agg = (
        g.groupby("round", as_index=False)
        .agg(
            labeled_size=("labeled_size", "max"),
            miou_round=("mIoU", "max"),
            f1_round=("f1", "max"),
            epochs_observed=("epoch", "max"),
        )
        .sort_values("round")
        .reset_index(drop=True)
    )
    return agg


def build_round_grad(df_epoch: pd.DataFrame) -> pd.DataFrame:
    if df_epoch.empty:
        return pd.DataFrame()
    cols = [
        "grad_total_norm_mean",
        "grad_backbone_norm_mean",
        "grad_head_norm_mean",
        "grad_cos_consecutive_mean",
        "grad_cos_to_mean_mean",
        "grad_train_val_cos",
        "grad_n_probe_batches",
    ]
    keep = [c for c in cols if c in df_epoch.columns]
    if not keep:
        return pd.DataFrame()
    g = df_epoch.dropna(subset=["round"]).copy()
    g["round"] = g["round"].astype(int)
    agg = g.groupby("round", as_index=False).agg({c: "mean" for c in keep}).sort_values("round").reset_index(drop=True)
    return agg


def compute_cost(df_epoch: pd.DataFrame, df_ctrl: pd.DataFrame) -> Dict[str, Any]:
    total_epochs = int(len(df_epoch)) if not df_epoch.empty else 0

    t0 = None
    t1 = None

    if not df_epoch.empty and df_epoch["ts"].dropna().shape[0]:
        t0 = _parse_ts(df_epoch["ts"].dropna().iloc[0])
        t1 = _parse_ts(df_epoch["ts"].dropna().iloc[-1])

    if (t0 is None or t1 is None) and (not df_ctrl.empty) and df_ctrl["ts"].dropna().shape[0]:
        t0 = _parse_ts(df_ctrl["ts"].dropna().iloc[0])
        t1 = _parse_ts(df_ctrl["ts"].dropna().iloc[-1])

    wall_clock_sec = None
    if t0 is not None and t1 is not None:
        wall_clock_sec = max(0.0, (t1 - t0).total_seconds())

    return {"total_epochs": total_epochs, "wall_clock_sec": wall_clock_sec}


def plot_aal_sd_active_learning_loop_diagram(
    outdir: Path,
    *,
    filename: str = "aal_sd_active_learning_loop.png",
) -> None:
    fig = plt.figure(figsize=(14, 5.2))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_axis_off()

    def add_box(x: float, y: float, w: float, h: float, text: str, *, fc: str, ec: str) -> None:
        patch = FancyBboxPatch(
            (x, y),
            w,
            h,
            boxstyle="round,pad=0.02,rounding_size=0.02",
            linewidth=1.4,
            facecolor=fc,
            edgecolor=ec,
        )
        ax.add_patch(patch)
        ax.text(
            x + w / 2,
            y + h / 2,
            text,
            ha="center",
            va="center",
            fontsize=11,
            wrap=True,
        )

    def add_arrow(x0: float, y0: float, x1: float, y1: float) -> None:
        arr = FancyArrowPatch(
            (x0, y0),
            (x1, y1),
            arrowstyle="-|>",
            mutation_scale=16,
            linewidth=1.4,
            color="#333333",
        )
        ax.add_patch(arr)

    w = 0.19
    h = 0.17
    y_top = 0.64
    y_bot = 0.23

    add_box(0.05, y_top, w, h, "未标注池 U", fc="#F2F2F2", ec="#666666")
    add_box(0.29, y_top, w, h, "模型推理\n(DeepLabV3+)", fc="#E8F0FE", ec="#3B6FB6")
    add_box(0.53, y_top, w, h, "计算得分\nU(x), K(x)", fc="#E8F7EE", ec="#2E8B57")
    add_box(0.77, y_top, w, h, "AD-KUCS\nScore(x)", fc="#FFF3E0", ec="#C77700")

    add_box(0.05, y_bot, w, h, "选择 Top-k\n(query size)", fc="#FFF3E0", ec="#C77700")
    add_box(0.29, y_bot, w, h, "人工标注\nOracle", fc="#FCE8E6", ec="#C43C35")
    add_box(0.53, y_bot, w, h, "已标注池 L\n+ 数据池更新", fc="#F2F2F2", ec="#666666")
    add_box(0.77, y_bot, w, h, "训练模型\n(固定 epochs=10)", fc="#E8F0FE", ec="#3B6FB6")

    add_box(
        0.77,
        0.43,
        w,
        0.14,
        "LLM Agent\n(控制 λ_t / 可选 query size)",
        fc="#EDE7F6",
        ec="#6A4FB6",
    )

    add_arrow(0.05 + w, y_top + h / 2, 0.29, y_top + h / 2)
    add_arrow(0.29 + w, y_top + h / 2, 0.53, y_top + h / 2)
    add_arrow(0.53 + w, y_top + h / 2, 0.77, y_top + h / 2)

    add_arrow(0.77 + w / 2, y_top, 0.05 + w / 2, y_bot + h)
    add_arrow(0.05 + w, y_bot + h / 2, 0.29, y_bot + h / 2)
    add_arrow(0.29 + w, y_bot + h / 2, 0.53, y_bot + h / 2)
    add_arrow(0.53 + w, y_bot + h / 2, 0.77, y_bot + h / 2)
    add_arrow(0.77, y_bot + h / 2, 0.29, y_top + h / 2)

    add_arrow(0.77, 0.50, 0.77, y_top + h * 0.25)

    ax.text(
        0.5,
        0.94,
        "AAL-SD 主动学习闭环（AD-KUCS 作为查询策略，LLM Agent 为受约束控制器）",
        ha="center",
        va="center",
        fontsize=13,
        fontweight="bold",
    )

    out_path = outdir / filename
    fig.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_learning_curves(
    curves: pd.DataFrame,
    outdir: Path,
    title: str,
    *,
    filename: str = "learning_curve_miou_vs_labeled.png",
    include_experiments: Optional[List[str]] = None,
    label_map: Optional[Dict[str, str]] = None,
):
    if curves.empty:
        return

    d = curves.copy()
    if include_experiments:
        keep = set(str(x) for x in include_experiments)
        d = d[d["experiment"].astype(str).isin(keep)]

    if d.empty:
        return

    label_map = label_map or {}
    plt.figure(figsize=(11, 6))
    for exp, df in d.groupby("experiment", sort=True):
        g = df.dropna(subset=["labeled_size", "miou_round"]).sort_values("labeled_size")
        if g.empty:
            continue
        plt.plot(
            g["labeled_size"].astype(float),
            g["miou_round"].astype(float),
            marker="o",
            linewidth=2.2,
            label=str(label_map.get(str(exp), exp)),
        )
    plt.title(title)
    plt.xlabel("标注样本数")
    plt.ylabel("mIoU（每轮最佳）")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(outdir / filename, dpi=300)
    plt.close()


def plot_multiseed_learning_curves(
    per_seed_curves: Dict[str, Dict[str, pd.DataFrame]],
    outdir: Path,
    title: str,
    *,
    filename: str = "multiseed_learning_curve_miou_vs_labeled.png",
    include_experiments: Optional[List[str]] = None,
    label_map: Optional[Dict[str, str]] = None,
) -> None:
    label_map = label_map or {}
    exps = sorted(per_seed_curves.keys())
    if include_experiments:
        keep = set(str(x) for x in include_experiments)
        exps = [e for e in exps if str(e) in keep]
    if not exps:
        return

    plt.figure(figsize=(11, 6))
    for exp in exps:
        seed_map = per_seed_curves.get(exp) or {}
        if not isinstance(seed_map, dict) or not seed_map:
            continue
        rows: List[pd.DataFrame] = []
        for df in seed_map.values():
            if not isinstance(df, pd.DataFrame) or df.empty:
                continue
            g = df.dropna(subset=["round", "labeled_size", "miou_round"]).copy()
            g["round"] = pd.to_numeric(g["round"], errors="coerce")
            g["labeled_size"] = pd.to_numeric(g["labeled_size"], errors="coerce")
            g["miou_round"] = pd.to_numeric(g["miou_round"], errors="coerce")
            g = g.dropna(subset=["round", "labeled_size", "miou_round"]).sort_values("round")
            if g.empty:
                continue
            rows.append(g[["round", "labeled_size", "miou_round"]])
        if not rows:
            continue

        all_rounds = sorted(set(int(r) for df in rows for r in df["round"].astype(int).tolist()))
        xs: List[float] = []
        ys_mean: List[float] = []
        ys_lo: List[float] = []
        ys_hi: List[float] = []

        for rr in all_rounds:
            vals: List[float] = []
            labeled_sizes: List[float] = []
            for df in rows:
                match = df[df["round"].astype(int) == int(rr)]
                if match.empty:
                    continue
                vals.append(float(match["miou_round"].iloc[0]))
                labeled_sizes.append(float(match["labeled_size"].iloc[0]))
            if not vals:
                continue
            stats = _summarize(vals)
            xs.append(float(statistics.fmean(labeled_sizes)) if labeled_sizes else float(rr))
            ys_mean.append(float(stats["mean"]))
            ci = stats.get("ci95")
            if ci is None or not np.isfinite(float(ci)):
                ys_lo.append(float(stats["mean"]))
                ys_hi.append(float(stats["mean"]))
            else:
                ys_lo.append(float(stats["mean"]) - float(ci))
                ys_hi.append(float(stats["mean"]) + float(ci))

        if not xs:
            continue

        label = str(label_map.get(str(exp), exp))
        plt.plot(xs, ys_mean, marker="o", linewidth=2.2, label=label)
        if any(abs(a - b) > 1e-12 for a, b in zip(ys_lo, ys_hi)):
            plt.fill_between(xs, ys_lo, ys_hi, alpha=0.18)

    plt.title(title)
    plt.xlabel("标注样本数")
    plt.ylabel("mIoU（每轮最佳，均值±95%CI）")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(outdir / filename, dpi=300)
    plt.close()


def plot_multiseed_metric_bars(
    summary: Dict[str, Any],
    outdir: Path,
    *,
    metric: str,
    title: str,
    filename: str,
    include_experiments: Optional[List[str]] = None,
    label_map: Optional[Dict[str, str]] = None,
) -> None:
    label_map = label_map or {}
    experiments = summary.get("experiments")
    if not isinstance(experiments, dict) or not experiments:
        return

    rows: List[Dict[str, Any]] = []
    for exp, payload in experiments.items():
        if include_experiments and str(exp) not in set(str(x) for x in include_experiments):
            continue
        if not isinstance(payload, dict):
            continue
        stats_block = payload.get("summary")
        if not isinstance(stats_block, dict):
            continue
        s = stats_block.get(metric)
        if not isinstance(s, dict):
            continue
        try:
            rows.append(
                {
                    "experiment": str(exp),
                    "mean": float(s.get("mean")),
                    "std": float(s.get("std")),
                    "ci95": float(s.get("ci95")),
                    "n": int(s.get("n")),
                }
            )
        except Exception:
            continue

    if not rows:
        return

    df = pd.DataFrame(rows).dropna(subset=["mean"]).sort_values("mean", ascending=False)
    if df.empty:
        return

    xs = [str(label_map.get(str(x), x)) for x in df["experiment"].astype(str).tolist()]
    ys = df["mean"].astype(float).tolist()
    errs = df["ci95"].astype(float).tolist()

    plt.figure(figsize=(11, 5))
    plt.bar(xs, ys, yerr=errs, capsize=4)
    plt.xticks(rotation=35, ha="right")
    plt.title(title)
    plt.xlabel("")
    plt.ylabel(metric)
    plt.tight_layout()
    plt.savefig(outdir / filename, dpi=300)
    plt.close()

def plot_bars(metrics: pd.DataFrame, outdir: Path):
    if metrics.empty:
        return

    m1 = metrics.dropna(subset=["alc"]).sort_values("alc", ascending=False)
    if not m1.empty:
        plt.figure(figsize=(11, 5))
        xs = m1["experiment"].astype(str).tolist()
        ys = m1["alc"].astype(float).tolist()
        plt.bar(xs, ys)
        plt.xticks(rotation=35, ha="right")
        plt.title("ALC 对比")
        plt.xlabel("")
        plt.ylabel("ALC")
        plt.tight_layout()
        plt.savefig(outdir / "alc_bar.png", dpi=300)
        plt.close()

    m2 = metrics.dropna(subset=["final_mIoU"]).sort_values("final_mIoU", ascending=False)
    if not m2.empty:
        plt.figure(figsize=(11, 5))
        xs = m2["experiment"].astype(str).tolist()
        ys = m2["final_mIoU"].astype(float).tolist()
        plt.bar(xs, ys)
        plt.xticks(rotation=35, ha="right")
        plt.title("最终 mIoU 对比")
        plt.xlabel("")
        plt.ylabel("最终 mIoU")
        plt.tight_layout()
        plt.savefig(outdir / "final_miou_bar.png", dpi=300)
        plt.close()


def plot_cost_tradeoff(metrics: pd.DataFrame, outdir: Path):
    m = metrics.dropna(subset=["final_mIoU", "total_epochs"]).copy()
    if m.empty:
        return

    plt.figure(figsize=(9, 6))
    exps = sorted(m["experiment"].astype(str).unique().tolist())
    cmap = plt.get_cmap("tab10")
    color_map = {exp: cmap(i % 10) for i, exp in enumerate(exps)}
    for exp in exps:
        df = m[m["experiment"].astype(str) == exp]
        plt.scatter(
            df["total_epochs"].astype(float),
            df["final_mIoU"].astype(float),
            s=120,
            label=exp,
            color=color_map.get(exp),
        )
        for _, r in df.iterrows():
            plt.text(float(r["total_epochs"]), float(r["final_mIoU"]), str(r["experiment"]), fontsize=8, alpha=0.8)
    plt.title("成本—性能权衡（成本代理：总训练epoch数）")
    plt.xlabel("总训练 epochs（按 epoch_end 计数）")
    plt.ylabel("最终 mIoU")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.legend(title="experiment", loc="best")
    plt.tight_layout()
    plt.savefig(outdir / "cost_tradeoff.png", dpi=300)
    plt.close()


def plot_controller_trajectories(ctrl: pd.DataFrame, outdir: Path):
    if ctrl.empty:
        return
    exps = sorted(ctrl["experiment"].unique().tolist())
    for exp in exps:
        df = ctrl[ctrl["experiment"] == exp].sort_values("round")
        if df.empty:
            continue

        show_epochs = False
        if "epochs" in df.columns:
            xs = pd.to_numeric(df["epochs"], errors="coerce").dropna()
            if xs.shape[0] > 0 and xs.nunique() > 1:
                show_epochs = True

        rows = 3 if show_epochs else 2
        fig, axes = plt.subplots(rows, 1, figsize=(10, 7.5 if rows == 2 else 9), sharex=True)
        if isinstance(axes, np.ndarray):
            axes = axes.flatten().tolist()
        else:
            axes = [axes]

        axes[0].plot(df["round"].astype(float), pd.to_numeric(df["lambda"], errors="coerce").astype(float), marker="o", linewidth=2.2)
        axes[0].set_ylabel("lambda")
        axes[0].set_ylim(-0.05, 1.05)
        axes[0].grid(True, linestyle="--", alpha=0.5)

        idx = 1
        if show_epochs:
            axes[idx].plot(df["round"].astype(float), pd.to_numeric(df["epochs"], errors="coerce").astype(float), marker="o", linewidth=2.2)
            axes[idx].set_ylabel("epochs")
            axes[idx].grid(True, linestyle="--", alpha=0.5)
            idx += 1

        axes[idx].plot(df["round"].astype(float), pd.to_numeric(df["query_size"], errors="coerce").astype(float), marker="o", linewidth=2.2)
        axes[idx].set_ylabel("query_size")
        axes[idx].set_xlabel("round")
        axes[idx].grid(True, linestyle="--", alpha=0.5)

        fig.suptitle(f"控制轨迹：{exp}")
        plt.tight_layout()
        fig.savefig(outdir / f"controller_trajectory__{exp}.png", dpi=300)
        plt.close(fig)


def plot_gradient_diagnostics(
    grad: pd.DataFrame,
    outdir: Path,
    *,
    title: str = "梯度诊断（按 round 汇总）",
    filename: str = "gradient_diagnostics.png",
    include_experiments: Optional[List[str]] = None,
    label_map: Optional[Dict[str, str]] = None,
) -> None:
    if grad.empty:
        return

    df = grad.copy()
    if include_experiments:
        df = df[df["experiment"].astype(str).isin([str(x) for x in include_experiments])].copy()
    if df.empty:
        return

    cols = set(df.columns.tolist())
    has_norm = "grad_total_norm_mean" in cols
    has_align = "grad_train_val_cos" in cols
    if not has_norm and not has_align:
        return

    fig, axes = plt.subplots(2, 1, figsize=(11, 7.6), sharex=True)
    if isinstance(axes, np.ndarray):
        axes = axes.flatten().tolist()
    else:
        axes = [axes]

    exps = sorted(df["experiment"].astype(str).unique().tolist())
    for exp in exps:
        d = df[df["experiment"].astype(str) == exp].sort_values("round")
        if d.empty:
            continue
        label = label_map.get(exp, exp) if isinstance(label_map, dict) else exp
        if has_norm:
            axes[0].plot(
                d["round"].astype(float),
                pd.to_numeric(d["grad_total_norm_mean"], errors="coerce").astype(float),
                marker="o",
                linewidth=2.0,
                label=label,
            )
        if has_align:
            axes[1].plot(
                d["round"].astype(float),
                pd.to_numeric(d["grad_train_val_cos"], errors="coerce").astype(float),
                marker="o",
                linewidth=2.0,
                label=label,
            )

    if has_norm:
        axes[0].set_ylabel("grad_total_norm (mean)")
        axes[0].grid(True, linestyle="--", alpha=0.5)
    else:
        axes[0].set_axis_off()

    if has_align:
        axes[1].set_ylabel("train-val cosine")
        axes[1].set_xlabel("round")
        axes[1].set_ylim(-1.05, 1.05)
        axes[1].grid(True, linestyle="--", alpha=0.5)
    else:
        axes[1].set_axis_off()

    handles, labels = axes[1].get_legend_handles_labels()
    if not handles:
        handles, labels = axes[0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.02), frameon=False)

    fig.suptitle(title)
    plt.tight_layout()
    fig.savefig(outdir / filename, dpi=300, bbox_inches="tight")
    plt.close(fig)


def _parse_report_numbers(text: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    m = re.search(r"\*\*mIoU:\*\*\s*([0-9]*\.?[0-9]+)", text)
    if m:
        out["miou"] = float(m.group(1))
    m = re.search(r"\*\*F1 Score:\*\*\s*([0-9]*\.?[0-9]+)", text)
    if m:
        out["f1"] = float(m.group(1))
    m = re.search(r"\*\*Labeled Samples:\*\*\s*([0-9]+)", text)
    if m:
        out["labeled"] = int(m.group(1))
    m = re.search(r"\*\*mIoU Change:\*\*\s*([+-]?[0-9]*\.?[0-9]+)", text)
    if m:
        out["miou_delta"] = float(m.group(1))
    m = re.search(r"\*\*F1 Change:\*\*\s*([+-]?[0-9]*\.?[0-9]+)", text)
    if m:
        out["f1_delta"] = float(m.group(1))
    return out


def _extract_anomalies_from_report(text: str) -> List[str]:
    m = re.search(r"## Anomalies\s*\n(\[[\s\S]*?\])", text)
    if not m:
        return []
    try:
        xs = json.loads(m.group(1))
        return [str(x) for x in xs] if isinstance(xs, list) else []
    except Exception:
        return []


def _add_text_page(pdf: PdfPages, title: str, paragraphs: List[str]):
    fig = plt.figure(figsize=(8.27, 11.69))
    fig.suptitle(title, fontsize=16, y=0.98)
    y = 0.94
    for p in paragraphs:
        wrapped = textwrap.fill(p, width=95)
        fig.text(0.06, y, wrapped, fontsize=10, va="top")
        y -= 0.03 * (wrapped.count("\n") + 1) + 0.02
        if y < 0.08:
            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)
            fig = plt.figure(figsize=(8.27, 11.69))
            y = 0.97
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def _add_image_page(pdf: PdfPages, title: str, image_paths: List[Path], cols: int = 1):
    image_paths = [p for p in image_paths if p.exists()]
    if not image_paths:
        return
    rows = (len(image_paths) + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(8.27, 11.69))
    if not isinstance(axes, (list, tuple)) and hasattr(axes, "shape"):
        axes_list = axes.flatten().tolist()
    else:
        axes_list = axes if isinstance(axes, list) else [axes]
    fig.suptitle(title, fontsize=14, y=0.98)
    for ax, p in zip(axes_list, image_paths):
        img = plt.imread(str(p))
        ax.imshow(img)
        ax.set_axis_off()
        ax.set_title(p.name, fontsize=9)
    for ax in axes_list[len(image_paths) :]:
        ax.set_axis_off()
    plt.tight_layout()
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def _markdown_to_sections(markdown: str) -> List[Tuple[str, List[str]]]:
    lines = markdown.splitlines()
    sections: List[Tuple[str, List[str]]] = []
    title = "正文"
    buf: List[str] = []
    in_code = False

    def _flush():
        nonlocal buf, title
        paragraphs: List[str] = []
        cur: List[str] = []
        for ln in buf:
            if not ln.strip():
                if cur:
                    paragraphs.append(" ".join(cur).strip())
                    cur = []
                continue
            cur.append(ln.rstrip())
        if cur:
            paragraphs.append(" ".join(cur).strip())
        if paragraphs:
            sections.append((title, paragraphs))
        buf = []

    for raw in lines:
        ln = raw.rstrip("\n")
        if ln.strip().startswith("```"):
            in_code = not in_code
            buf.append(ln)
            continue
        if not in_code:
            if ln.strip() in {"---", "***", "___"}:
                continue
            if ln.lstrip().startswith("![]("):
                continue
            if ln.startswith("# "):
                _flush()
                title = ln[2:].strip() or "正文"
                continue
            if ln.startswith("## "):
                _flush()
                title = ln[3:].strip() or "正文"
                continue
            if ln.startswith("### "):
                buf.append(f"【{ln[4:].strip()}】")
                continue
        buf.append(ln)

    _flush()
    return sections


def export_theory_based_pdf_report(
    run_dir: Path,
    outdir: Path,
    metrics: pd.DataFrame,
    reports_dir: Optional[Path],
    pdf_path: Path,
    theory_md_path: Path,
):
    theory_text = _read_text(theory_md_path)
    sections = _markdown_to_sections(theory_text) if theory_text.strip() else []

    ours = metrics[metrics["experiment"] == "full_model"]
    ours_row = ours.iloc[0].to_dict() if not ours.empty else {}

    trad = metrics[metrics["experiment"].isin(["baseline_entropy", "baseline_bald", "baseline_coreset", "baseline_random"])]
    trad = trad.dropna(subset=["final_mIoU"]).sort_values("final_mIoU", ascending=False)
    best_trad = trad.iloc[0].to_dict() if not trad.empty else {}

    delta_lines: List[str] = []
    if ours_row and best_trad:
        delta_lines.append(
            f"相对最强传统基线 {best_trad.get('experiment')}：最终 mIoU "
            f"{float(ours_row.get('final_mIoU')) - float(best_trad.get('final_mIoU')):+.4f}，ALC "
            f"{float(ours_row.get('alc')) - float(best_trad.get('alc')):+.4f}。"
        )
    fixed_epochs = bool(int(metrics["total_epochs"].nunique() <= 1)) if "total_epochs" in metrics.columns else False
    if (not fixed_epochs) and ours_row:
        delta_lines.append(
            f"训练成本代理（total_epochs）：full_model={int(ours_row.get('total_epochs') or 0)}；多数基线约为 45。"
        )

    anomalies_lines: List[str] = []
    if reports_dir and reports_dir.exists():
        for prefix in [
            "baseline_random_anomaly_report_",
            "no_agent_anomaly_report_",
            "agent_control_budget_anomaly_report_",
            "agent_control_lambda_anomaly_report_",
        ]:
            cand = sorted(reports_dir.glob(f"{prefix}*.md"))
            if not cand:
                continue
            xs = _extract_anomalies_from_report(_read_text(cand[-1]))
            if xs:
                anomalies_lines.append(f"{cand[-1].stem}: " + "; ".join(xs))

    with PdfPages(str(pdf_path)) as pdf:
        cover_paras = [
            f"Run: {run_dir.name}",
            f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"理论框架来源: {theory_md_path.name}",
        ]
        if ours_row:
            cover_paras.append(
                f"full_model: ALC={float(ours_row.get('alc')):.4f}, final mIoU={float(ours_row.get('final_mIoU')):.4f}, "
                f"final F1={float(ours_row.get('final_f1')):.4f}"
            )
        cover_paras.extend(delta_lines)
        if anomalies_lines:
            cover_paras.append("异常摘要（自动诊断）： " + " | ".join(anomalies_lines))
        _add_text_page(pdf, title="AAL-SD 理论驱动报告（内嵌图表版）", paragraphs=cover_paras)

        if sections:
            for sec_title, paras in sections:
                _add_text_page(pdf, title=sec_title, paragraphs=paras)
        else:
            _add_text_page(
                pdf,
                title="理论正文缺失",
                paragraphs=[f"无法读取理论文档：{theory_md_path}"],
            )

        show = metrics.dropna(subset=["final_mIoU"]).sort_values("final_mIoU", ascending=False).copy()
        cols = ["experiment", "alc", "final_mIoU", "final_f1", "total_epochs", "wall_clock_sec"]
        show = show[[c for c in cols if c in show.columns]].copy()
        for c in ["alc", "final_mIoU", "final_f1"]:
            if c in show.columns:
                show[c] = show[c].astype(float).map(lambda x: f"{x:.4f}")
        if "total_epochs" in show.columns:
            show["total_epochs"] = show["total_epochs"].fillna(0).astype(int).astype(str)
        if "wall_clock_sec" in show.columns:
            show["wall_clock_sec"] = show["wall_clock_sec"].map(lambda x: "" if pd.isna(x) else f"{float(x):.0f}")

        fig = plt.figure(figsize=(8.27, 11.69))
        ax = fig.add_subplot(111)
        ax.set_axis_off()
        fig.suptitle("实验结果汇总（按最终 mIoU 排序）", fontsize=14, y=0.98)
        tbl = ax.table(
            cellText=show.values.tolist(),
            colLabels=show.columns.tolist(),
            loc="center",
            cellLoc="center",
            colLoc="center",
        )
        tbl.auto_set_font_size(False)
        tbl.set_fontsize(8)
        tbl.scale(1.0, 1.25)
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)

        _add_image_page(
            pdf,
            title="核心图表：标注效率曲线",
            image_paths=[outdir / "learning_curve_miou_vs_labeled.png"],
            cols=1,
        )
        _add_image_page(
            pdf,
            title="核心图表：ALC / 最终 mIoU / 成本权衡",
            image_paths=[
                outdir / "alc_bar.png",
                outdir / "final_miou_bar.png",
                outdir / "cost_tradeoff.png",
            ],
            cols=1,
        )
        _add_image_page(
            pdf,
            title="核心图表：控制策略轨迹",
            image_paths=[
                outdir / "controller_trajectory__full_model.png",
                outdir / "controller_trajectory__agent_control_lambda.png",
                outdir / "controller_trajectory__agent_control_budget.png",
            ],
            cols=1,
        )


def export_pdf_report(
    run_dir: Path,
    outdir: Path,
    metrics: pd.DataFrame,
    reports_dir: Optional[Path],
    pdf_path: Path,
):
    metrics_sorted = metrics.dropna(subset=["final_mIoU"]).sort_values("final_mIoU", ascending=False)
    best_row = metrics_sorted.iloc[0].to_dict() if not metrics_sorted.empty else {}

    def _get_row(exp: str) -> Dict[str, Any]:
        r = metrics[metrics["experiment"] == exp]
        return r.iloc[0].to_dict() if not r.empty else {}

    ours = _get_row("full_model")
    best_trad = metrics[metrics["experiment"].isin(["baseline_entropy", "baseline_bald", "baseline_coreset", "baseline_random"])]
    best_trad = best_trad.dropna(subset=["final_mIoU"]).sort_values("final_mIoU", ascending=False)
    best_trad_row = best_trad.iloc[0].to_dict() if not best_trad.empty else {}

    effect_lines: List[str] = []
    if ours and best_trad_row:
        effect_lines.append(
            f"在固定标注预算下，full_model 相比最强传统基线 {best_trad_row.get('experiment')} 的最终 mIoU 提升 "
            f"{float(ours.get('final_mIoU')) - float(best_trad_row.get('final_mIoU')):+.4f}，ALC 提升 "
            f"{float(ours.get('alc')) - float(best_trad_row.get('alc')):+.4f}。"
        )
    fixed_epochs = bool(int(metrics["total_epochs"].nunique() <= 1)) if "total_epochs" in metrics.columns else False
    if (not fixed_epochs) and ours:
        effect_lines.append(
            f"训练成本代理（total_epochs）显示 full_model 为 {int(ours.get('total_epochs') or 0)}，多数基线约为 45，"
            f"存在训练预算不一致带来的混杂，需要在论文中明确并用固定训练预算的补充实验解耦。"
        )

    anomalies_lines: List[str] = []
    if reports_dir and reports_dir.exists():
        anomaly_targets = [
            "baseline_random_anomaly_report_",
            "no_agent_anomaly_report_",
            "agent_control_budget_anomaly_report_",
            "agent_control_lambda_anomaly_report_",
        ]
        for prefix in anomaly_targets:
            cand = sorted(reports_dir.glob(f"{prefix}*.md"))
            if not cand:
                continue
            txt = _read_text(cand[-1])
            xs = _extract_anomalies_from_report(txt)
            if xs:
                anomalies_lines.append(f"{cand[-1].stem}: " + "; ".join(xs))

    round_refs: List[str] = []
    if reports_dir and reports_dir.exists():
        for p in [
            reports_dir / "full_model_round_15_report.md",
            reports_dir / "baseline_entropy_round_15_report.md",
            reports_dir / "baseline_llm_us_round_15_report.md",
            reports_dir / "baseline_random_round_4_report.md",
        ]:
            if p.exists():
                nums = _parse_report_numbers(_read_text(p))
                if nums:
                    s = f"{p.stem}: mIoU={nums.get('miou')}"
                    if "miou_delta" in nums:
                        s += f" (Δ={nums.get('miou_delta'):+.4f})"
                    round_refs.append(s)

    with PdfPages(str(pdf_path)) as pdf:
        _add_text_page(
            pdf,
            title=f"CVPR 风格结果分析（{run_dir.name}）",
            paragraphs=[
                "本报告基于固定标注预算（最终标注样本数一致）比较多种主动学习基线、LLM 打分基线、规则策略与我们的方法。",
                f"整体最佳方法：{best_row.get('experiment')}，最终 mIoU={best_row.get('final_mIoU')}, ALC={best_row.get('alc')}。",
                *effect_lines,
                "建议在最终论文中同时报告：固定标注预算结果（ALC/最终 mIoU）与固定训练预算结果（相同 epochs 或相同 wall-clock），以获得可归因的结论。",
            ],
        )

        if not metrics.empty:
            show = metrics.copy()
            show = show.dropna(subset=["final_mIoU"]).sort_values("final_mIoU", ascending=False)
            cols = ["experiment", "alc", "final_mIoU", "final_f1", "total_epochs", "wall_clock_sec"]
            show = show[[c for c in cols if c in show.columns]].copy()
            for c in ["alc", "final_mIoU", "final_f1"]:
                if c in show.columns:
                    show[c] = show[c].astype(float).map(lambda x: f"{x:.4f}")
            for c in ["total_epochs"]:
                if c in show.columns:
                    show[c] = show[c].fillna(0).astype(int).astype(str)
            if "wall_clock_sec" in show.columns:
                show["wall_clock_sec"] = show["wall_clock_sec"].map(lambda x: "" if pd.isna(x) else f"{float(x):.0f}")

            fig = plt.figure(figsize=(8.27, 11.69))
            ax = fig.add_subplot(111)
            ax.set_axis_off()
            fig.suptitle("汇总指标（按最终 mIoU 排序）", fontsize=14, y=0.98)
            tbl = ax.table(
                cellText=show.values.tolist(),
                colLabels=show.columns.tolist(),
                loc="center",
                cellLoc="center",
                colLoc="center",
            )
            tbl.auto_set_font_size(False)
            tbl.set_fontsize(8)
            tbl.scale(1.0, 1.25)
            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)

        figs_dir = outdir
        _add_image_page(
            pdf,
            title="标注效率曲线",
            image_paths=[figs_dir / "learning_curve_miou_vs_labeled.png"],
            cols=1,
        )
        _add_image_page(
            pdf,
            title="ALC / 最终 mIoU / 成本权衡",
            image_paths=[
                figs_dir / "alc_bar.png",
                figs_dir / "final_miou_bar.png",
                figs_dir / "cost_tradeoff.png",
            ],
            cols=1,
        )

        ctrl_imgs = [
            figs_dir / "controller_trajectory__full_model.png",
            figs_dir / "controller_trajectory__agent_control_lambda.png",
            figs_dir / "controller_trajectory__agent_control_budget.png",
        ]
        _add_image_page(pdf, title="控制策略轨迹", image_paths=ctrl_imgs, cols=1)

        if anomalies_lines or round_refs:
            _add_text_page(
                pdf,
                title="异常与轮次诊断摘要",
                paragraphs=[
                    "异常摘要来自自动诊断报告，建议在论文中作为稳定性/失败模式的补充说明，并在多随机种子上复核。",
                    *([("异常检测：" + " | ".join(anomalies_lines))] if anomalies_lines else []),
                    *([("关键轮次：" + " | ".join(round_refs))] if round_refs else []),
                ],
            )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run_dir", default=None)
    parser.add_argument("--multi_seed_group_dir", default=None)
    parser.add_argument("--output_dir", default=None)
    parser.add_argument("--exclude_prefix", default="")
    parser.add_argument("--export_pdf", action="store_true")
    parser.add_argument("--export_theory_pdf", action="store_true")
    parser.add_argument("--reports_dir", default=None)
    parser.add_argument("--pdf_path", default=None)
    parser.add_argument("--theory_md", default=None)
    args = parser.parse_args()

    plt.rcParams["font.sans-serif"] = ["PingFang SC", "Heiti SC", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    if not args.run_dir and not args.multi_seed_group_dir:
        raise SystemExit("Either --run_dir or --multi_seed_group_dir must be provided.")

    run_dir = Path(args.run_dir).expanduser().resolve() if args.run_dir else None
    multi_seed_group_dir = Path(args.multi_seed_group_dir).expanduser().resolve() if args.multi_seed_group_dir else None

    default_outdir = None
    if run_dir is not None:
        default_outdir = run_dir / "figures"
    elif multi_seed_group_dir is not None:
        default_outdir = multi_seed_group_dir / "figures"
    outdir = Path(args.output_dir).expanduser().resolve() if args.output_dir else default_outdir
    if outdir is None:
        raise SystemExit("Cannot determine output_dir.")
    outdir.mkdir(parents=True, exist_ok=True)

    paper_include = [
        "full_model",
        "full_model_fixed_epochs_lambda_budget",
        "no_agent",
        "fixed_lambda",
        "uncertainty_only",
        "knowledge_only",
        "baseline_random",
        "baseline_entropy",
        "baseline_bald",
        "baseline_coreset",
        "baseline_llm_us",
        "baseline_llm_rs",
        "agent_control_lambda",
        "agent_control_budget",
    ]
    paper_labels = {
        "full_model": "AAL-SD (Full)",
        "full_model_fixed_epochs_lambda_budget": "AAL-SD (λ+budget, fixed epochs)",
        "no_agent": "AD-KUCS (No Agent)",
        "fixed_lambda": "AD-KUCS (Fixed λ=0.5)",
        "uncertainty_only": "Uncertainty-only (λ=0)",
        "knowledge_only": "Knowledge-only (λ=1)",
        "baseline_random": "Random",
        "baseline_entropy": "Entropy",
        "baseline_bald": "BALD",
        "baseline_coreset": "Core-set",
        "baseline_llm_us": "LLM-US",
        "baseline_llm_rs": "LLM-RS",
        "agent_control_lambda": "Agent control λ",
        "agent_control_budget": "Agent control query size",
    }

    if run_dir is not None:
        manifest, exps = discover_experiments(run_dir)
        exp_meta = manifest.get("experiments") if isinstance(manifest.get("experiments"), dict) else {}
        cfg = manifest.get("config") if isinstance(manifest.get("config"), dict) else {}
        fixed_epochs = bool(cfg.get("FIX_EPOCHS_PER_ROUND")) or (
            cfg.get("EPOCHS_PER_ROUND_SCHEDULE") in (None, "null") and cfg.get("EPOCHS_PER_ROUND") is not None
        )

        exclude_prefixes = [p.strip() for p in str(args.exclude_prefix).split(",") if p.strip()]

        metrics_rows: List[Dict[str, Any]] = []
        curves_rows: List[pd.DataFrame] = []
        ctrl_rows: List[pd.DataFrame] = []
        grad_rows: List[pd.DataFrame] = []

        for ep in exps:
            if any(ep.name.startswith(px) for px in exclude_prefixes):
                continue

            status = load_status_metrics(ep.status_path)
            df_epoch, df_ctrl = parse_trace(ep.trace_path)
            curve = build_round_curve(df_epoch)
            if not curve.empty:
                curve["experiment"] = ep.name
                curves_rows.append(curve)

            round_grad = build_round_grad(df_epoch)
            if not round_grad.empty:
                round_grad["experiment"] = ep.name
                grad_rows.append(round_grad)

            cost = compute_cost(df_epoch, df_ctrl)
            meta = exp_meta.get(ep.name, {}) if isinstance(exp_meta.get(ep.name), dict) else {}
            description = meta.get("description")

            metrics_rows.append(
                {
                    "experiment": ep.name,
                    "description": description,
                    "status": status.get("status"),
                    "alc": status.get("alc"),
                    "final_mIoU": status.get("final_mIoU"),
                    "final_f1": status.get("final_f1"),
                    "total_epochs": cost.get("total_epochs"),
                    "wall_clock_sec": cost.get("wall_clock_sec"),
                    "n_rounds": int(cfg.get("N_ROUNDS")) if cfg.get("N_ROUNDS") is not None else None,
                }
            )

            if not df_ctrl.empty:
                d = df_ctrl.copy()
                d["experiment"] = ep.name
                ctrl_rows.append(d)

        metrics = pd.DataFrame(metrics_rows)
        metrics.to_csv(outdir / "metrics_summary.csv", index=False, encoding="utf-8")

        curves = pd.concat(curves_rows, ignore_index=True) if curves_rows else pd.DataFrame()
        if not curves.empty:
            curves.to_csv(outdir / "round_curves.csv", index=False, encoding="utf-8")

        ctrl = pd.concat(ctrl_rows, ignore_index=True) if ctrl_rows else pd.DataFrame()
        if not ctrl.empty:
            ctrl.to_csv(outdir / "controller_trajectories.csv", index=False, encoding="utf-8")

        grad = pd.concat(grad_rows, ignore_index=True) if grad_rows else pd.DataFrame()
        if not grad.empty:
            grad.to_csv(outdir / "round_gradients.csv", index=False, encoding="utf-8")

        plot_learning_curves(curves, outdir, title=f"标注效率曲线（全量曲线，{run_dir.name}）", filename="learning_curve_miou_vs_labeled_all.png")

        plot_learning_curves(
            curves,
            outdir,
            title=f"标注效率曲线（用于论文展示，{run_dir.name}）",
            filename="learning_curve_miou_vs_labeled.png",
            include_experiments=[
                x
                for x in paper_include
                if (not curves.empty) and (x in set(curves["experiment"].astype(str).unique().tolist()))
            ],
            label_map=paper_labels,
        )
        plot_bars(metrics, outdir)
        if not fixed_epochs:
            plot_cost_tradeoff(metrics, outdir)
        plot_controller_trajectories(ctrl, outdir)
        plot_gradient_diagnostics(
            grad,
            outdir,
            title=f"梯度诊断（{run_dir.name}）",
            filename="gradient_diagnostics.png",
            include_experiments=[
                x for x in paper_include if (not grad.empty) and (x in set(grad["experiment"].astype(str).unique().tolist()))
            ],
            label_map=paper_labels,
        )
        plot_aal_sd_active_learning_loop_diagram(outdir)

        if args.export_pdf:
            reports_dir = Path(args.reports_dir).expanduser().resolve() if args.reports_dir else None
            if args.pdf_path:
                pdf_path = Path(args.pdf_path).expanduser().resolve()
            else:
                analyze_dir = (run_dir.parent.parent / "analyze").resolve()
                analyze_dir.mkdir(parents=True, exist_ok=True)
                pdf_path = analyze_dir / f"{run_dir.name}__cvpr_baseline_analysis.pdf"
            export_pdf_report(
                run_dir=run_dir,
                outdir=outdir,
                metrics=metrics,
                reports_dir=reports_dir,
                pdf_path=pdf_path,
            )
            print(f"Saved pdf to: {pdf_path}")

        if args.export_theory_pdf:
            reports_dir = Path(args.reports_dir).expanduser().resolve() if args.reports_dir else None
            if args.theory_md:
                theory_md_path = Path(args.theory_md).expanduser().resolve()
            else:
                theory_md_path = (run_dir.parent.parent.parent / ".trae" / "documents" / "论AAL-SD框架中的动态训练梯度选择策略.md").resolve()
            if args.pdf_path:
                pdf_path = Path(args.pdf_path).expanduser().resolve()
            else:
                analyze_dir = (run_dir.parent.parent / "analyze").resolve()
                analyze_dir.mkdir(parents=True, exist_ok=True)
                pdf_path = analyze_dir / f"{run_dir.name}__theory_based_report.pdf"
            export_theory_based_pdf_report(
                run_dir=run_dir,
                outdir=outdir,
                metrics=metrics,
                reports_dir=reports_dir,
                pdf_path=pdf_path,
                theory_md_path=theory_md_path,
            )
            print(f"Saved theory pdf to: {pdf_path}")

        print(f"Saved figures to: {outdir}")
        print(f"Saved csv to: {outdir / 'metrics_summary.csv'}")

    if multi_seed_group_dir is not None:
        summary = _load_multi_seed_summary(multi_seed_group_dir)
        if not summary:
            run_ids = _discover_multi_seed_run_ids(multi_seed_group_dir)
            if not run_ids:
                raise SystemExit(f"multi-seed manifest not found or empty: {multi_seed_group_dir}")
            summary = {"run_ids": run_ids, "experiments": {}}

        run_ids = summary.get("run_ids")
        if not isinstance(run_ids, list) or not run_ids:
            run_ids = _discover_multi_seed_run_ids(multi_seed_group_dir)
        run_ids = [str(x) for x in run_ids] if isinstance(run_ids, list) else []
        if not run_ids:
            raise SystemExit(f"Cannot find multi-seed run_ids under: {multi_seed_group_dir}")

        experiments = summary.get("experiments")
        exp_names = sorted(experiments.keys()) if isinstance(experiments, dict) else []
        focus = [x for x in ["full_model", "no_agent", "fixed_lambda", "baseline_entropy", "baseline_random"] if x in exp_names] or exp_names

        multi_seed_rows: List[Dict[str, Any]] = []
        if isinstance(experiments, dict):
            for exp in focus:
                payload = experiments.get(exp)
                if not isinstance(payload, dict):
                    continue
                summary_block = payload.get("summary")
                if not isinstance(summary_block, dict):
                    continue
                for metric, stats in summary_block.items():
                    if not isinstance(stats, dict):
                        continue
                    try:
                        multi_seed_rows.append(
                            {
                                "experiment": str(exp),
                                "metric": str(metric),
                                "n": int(stats.get("n")),
                                "mean": float(stats.get("mean")),
                                "std": float(stats.get("std")),
                                "ci95": float(stats.get("ci95")),
                            }
                        )
                    except Exception:
                        continue
        if multi_seed_rows:
            pd.DataFrame(multi_seed_rows).to_csv(outdir / "multiseed_metrics_summary.csv", index=False, encoding="utf-8")

        plot_multiseed_metric_bars(
            summary,
            outdir,
            metric="alc",
            title=f"Multi-seed ALC (mean ± 95% CI, {multi_seed_group_dir.name})",
            filename="multiseed_alc_bar.png",
            include_experiments=focus,
            label_map=paper_labels,
        )
        plot_multiseed_metric_bars(
            summary,
            outdir,
            metric="final_miou",
            title=f"Multi-seed Final mIoU (mean ± 95% CI, {multi_seed_group_dir.name})",
            filename="multiseed_final_miou_bar.png",
            include_experiments=focus,
            label_map=paper_labels,
        )

        base_runs_dir = multi_seed_group_dir.parent
        per_seed_curves: Dict[str, Dict[str, pd.DataFrame]] = {}
        for exp in focus:
            per_seed_curves[exp] = {}
        for rid in run_ids:
            seed_run_dir = (base_runs_dir / rid).resolve()
            for exp in focus:
                trace_path = seed_run_dir / f"{exp}_trace.jsonl"
                df_epoch, _ = parse_trace(trace_path)
                curve = build_round_curve(df_epoch)
                if curve.empty:
                    continue
                per_seed_curves[exp][rid] = curve

        plot_multiseed_learning_curves(
            per_seed_curves,
            outdir,
            title=f"Multi-seed learning curves (mean ± 95% CI, {multi_seed_group_dir.name})",
            filename="multiseed_learning_curve_miou_vs_labeled.png",
            include_experiments=focus,
            label_map=paper_labels,
        )

        print(f"Saved multi-seed figures to: {outdir}")


if __name__ == "__main__":
    main()
