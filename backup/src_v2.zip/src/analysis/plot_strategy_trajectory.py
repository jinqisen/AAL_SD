import os
import re
import json
import argparse
import matplotlib.pyplot as plt
import pandas as pd
from typing import Dict, Any, Optional, List, Tuple

def _parse_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        return float(x)
    except Exception:
        return None


def _extract_distribution_hints(decision_reason: Optional[str]) -> Dict[str, Optional[float]]:
    text = decision_reason or ""

    def _find(pattern: str) -> Optional[float]:
        m = re.search(pattern, text, flags=re.IGNORECASE)
        if not m:
            return None
        return _parse_float(m.group(1))

    return {
        "u_mean": _find(r"U\s*(?:分布)?\s*(?:均值|mean)\s*[^0-9\-]*\(?\s*([0-9]*\.?[0-9]+)\s*\)?"),
        "u_p75": _find(r"U\s*(?:分布)?\s*75\s*(?:分位|percentile)\s*[^0-9\-]*\(?\s*([0-9]*\.?[0-9]+)\s*\)?"),
        "k_mean": _find(r"K\s*(?:分布)?\s*(?:均值|mean)\s*[^0-9\-]*\(?\s*([0-9]*\.?[0-9]+)\s*\)?"),
        "k_p75": _find(r"K\s*(?:分布)?\s*75\s*(?:分位|percentile)\s*[^0-9\-]*\(?\s*([0-9]*\.?[0-9]+)\s*\)?"),
    }


def load_trace(trace_path: str) -> pd.DataFrame:
    if not os.path.exists(trace_path):
        raise FileNotFoundError(trace_path)

    per_round: Dict[int, Dict[str, Any]] = {}

    def _row(r: Any) -> Dict[str, Any]:
        try:
            rr = int(r)
        except Exception:
            rr = -1
        if rr not in per_round:
            per_round[rr] = {"round": rr}
        return per_round[rr]

    with open(trace_path, "r") as f:
        for line in f:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            etype = entry.get("type")

            if etype == "epoch_end":
                r = entry.get("round")
                row = _row(r)
                row["final_epoch"] = entry.get("epoch")
                row["final_miou"] = entry.get("mIoU")
                row["final_f1"] = entry.get("f1")
                row["labeled_size"] = entry.get("labeled_size")
                grad = entry.get("grad") if isinstance(entry.get("grad"), dict) else {}
                row["grad_train_val_cos_last"] = grad.get("train_val_cos")

            elif etype == "selection":
                r = entry.get("round")
                row = _row(r)
                context = entry.get("context", {}) if isinstance(entry.get("context", {}), dict) else {}
                decision_reason = context.get("decision_reason")
                hints = _extract_distribution_hints(decision_reason)
                row.update(
                    {
                        "selected_count": entry.get("selected"),
                        "sampler_type": entry.get("sampler_type") or context.get("sampler") or "unknown",
                        "sampler_class": entry.get("sampler_class"),
                        "k_definition": entry.get("k_definition"),
                        "decision_reason": decision_reason,
                        "selected_ids": entry.get("selected_ids"),
                        "u_mean": hints.get("u_mean"),
                        "u_p75": hints.get("u_p75"),
                        "k_mean": hints.get("k_mean"),
                        "k_p75": hints.get("k_p75"),
                    }
                )

            elif etype == "controller_step":
                r = entry.get("round")
                row = _row(r)
                action = entry.get("action") if isinstance(entry.get("action"), dict) else {}
                state = entry.get("state") if isinstance(entry.get("state"), dict) else {}
                row.update(
                    {
                        "lambda_t": action.get("lambda"),
                        "epochs": action.get("epochs"),
                        "query_size": action.get("query_size"),
                        "rollback_flag": state.get("rollback_flag"),
                        "miou_delta": state.get("miou_delta"),
                        "last_miou": state.get("last_miou"),
                    }
                )

            elif etype == "lambda_override":
                r = entry.get("round")
                row = _row(r)
                row["lambda_override"] = entry.get("applied")

            elif etype == "overfit_signal":
                r = entry.get("round")
                row = _row(r)
                row.update(
                    {
                        "grad_tvc_mean": entry.get("grad_train_val_cos_mean"),
                        "grad_tvc_min": entry.get("grad_train_val_cos_min"),
                        "grad_tvc_max": entry.get("grad_train_val_cos_max"),
                        "grad_tvc_last": entry.get("grad_train_val_cos_last"),
                        "grad_tvc_neg_rate": entry.get("grad_train_val_cos_neg_rate"),
                        "overfit_risk": entry.get("overfit_risk"),
                    }
                )

            elif etype == "lambda_guard":
                r = entry.get("round")
                row = _row(r)
                row["lambda_guard_cap"] = entry.get("cap")
                row["lambda_guard_before"] = entry.get("lambda_before")
                row["lambda_guard_after"] = entry.get("lambda_after")

    df = pd.DataFrame(list(per_round.values()))
    if df.empty:
        return df
    df = df.sort_values("round").reset_index(drop=True)

    if "selected_ids" in df.columns:
        df["selected_ids_count"] = df["selected_ids"].apply(lambda x: len(x) if isinstance(x, list) else None)

    return df

def plot_lambda_trajectory(df: pd.DataFrame, output_dir: str):
    if "lambda_t" not in df.columns or df["lambda_t"].isnull().all():
        print("Skipping Lambda Plot: No lambda_t data found.")
        return

    plt.figure(figsize=(10, 6))
    plt.plot(df["round"], df["lambda_t"], marker="o", linewidth=2.5)
    plt.title("Lambda Trajectory", fontsize=14)
    plt.xlabel("Round", fontsize=12)
    plt.ylabel("Lambda", fontsize=12)
    plt.grid(True, linestyle="--", alpha=0.7)
    plt.ylim(-0.05, 1.05)
    plt.savefig(os.path.join(output_dir, "strategy_lambda_trajectory.png"), dpi=300)
    plt.close()

def plot_gradient_decomposition(df: pd.DataFrame, output_dir: str):
    if "avg_uncertainty" in df.columns and "avg_knowledge_gain" in df.columns:
        u_col, k_col = "avg_uncertainty", "avg_knowledge_gain"
    elif "u_mean" in df.columns and "k_mean" in df.columns:
        u_col, k_col = "u_mean", "k_mean"
    else:
        print("Skipping Decomposition Plot: Missing score components.")
        return

    if df[u_col].isnull().all() or df[k_col].isnull().all():
        print("Skipping Decomposition Plot: All score components are null.")
        return

    plt.figure(figsize=(12, 6))
    plt.plot(df["round"], df[u_col], label=u_col, marker="s", linestyle="-", color="#1f77b4")
    plt.plot(df["round"], df[k_col], label=k_col, marker="^", linestyle="-", color="#ff7f0e")
    plt.title("Component Evolution", fontsize=14)
    plt.xlabel("Round", fontsize=12)
    plt.ylabel("Score", fontsize=12)
    plt.legend()
    plt.grid(True, linestyle="--", alpha=0.7)
    plt.savefig(os.path.join(output_dir, "strategy_gradient_components.png"), dpi=300)
    plt.close()

def plot_phase_space(df: pd.DataFrame, output_dir: str):
    if "avg_uncertainty" in df.columns and "avg_knowledge_gain" in df.columns:
        u_col, k_col = "avg_uncertainty", "avg_knowledge_gain"
        x_label, y_label = "Uncertainty", "Diversity"
    elif "u_mean" in df.columns and "k_mean" in df.columns:
        u_col, k_col = "u_mean", "k_mean"
        x_label, y_label = "U mean", "K mean"
    else:
        print("Skipping Phase Space Plot: Missing score components.")
        return

    if df[u_col].isnull().all() or df[k_col].isnull().all():
        print("Skipping Phase Space Plot: All score components are null.")
        return

    plt.figure(figsize=(8, 8))
    sc = plt.scatter(
        df[u_col],
        df[k_col],
        c=df["round"],
        cmap="viridis",
        s=100,
        edgecolors="k",
        zorder=2,
    )

    plt.plot(df[u_col], df[k_col], color="gray", alpha=0.5, zorder=1)
    cbar = plt.colorbar(sc)
    cbar.set_label("Round")

    plt.title("Phase Space Trajectory", fontsize=14)
    plt.xlabel(x_label, fontsize=12)
    plt.ylabel(y_label, fontsize=12)
    plt.grid(True, linestyle="--", alpha=0.7)

    plt.savefig(os.path.join(output_dir, "strategy_phase_space.png"), dpi=300)
    plt.close()

def load_epoch_end(trace_path: str) -> pd.DataFrame:
    if not os.path.exists(trace_path):
        return pd.DataFrame()

    rows: List[Dict[str, Any]] = []
    with open(trace_path, "r") as f:
        for line in f:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if entry.get("type") != "epoch_end":
                continue
            grad = entry.get("grad") if isinstance(entry.get("grad"), dict) else {}
            cos_to_mean = grad.get("cos_to_mean") if isinstance(grad.get("cos_to_mean"), dict) else {}
            cos_consecutive = grad.get("cos_consecutive") if isinstance(grad.get("cos_consecutive"), dict) else {}
            total_norm = grad.get("total_norm") if isinstance(grad.get("total_norm"), dict) else {}
            rows.append(
                {
                    "round": entry.get("round"),
                    "epoch": entry.get("epoch"),
                    "labeled_size": entry.get("labeled_size"),
                    "loss": entry.get("loss"),
                    "mIoU": entry.get("mIoU"),
                    "f1": entry.get("f1"),
                    "grad_train_val_cos": grad.get("train_val_cos"),
                    "grad_cos_to_mean_mean": cos_to_mean.get("mean"),
                    "grad_cos_consecutive_mean": cos_consecutive.get("mean"),
                    "grad_total_norm_mean": total_norm.get("mean"),
                }
            )

    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["round"] = pd.to_numeric(df["round"], errors="coerce").astype("Int64")
    df["epoch"] = pd.to_numeric(df["epoch"], errors="coerce").astype("Int64")
    for c in ["loss", "mIoU", "f1", "grad_train_val_cos", "grad_cos_to_mean_mean", "grad_cos_consecutive_mean", "grad_total_norm_mean"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").astype(float)
    df = df.sort_values(["round", "epoch"]).reset_index(drop=True)
    return df

def aggregate_gradients_per_round(epoch_df: pd.DataFrame) -> pd.DataFrame:
    if epoch_df.empty:
        return pd.DataFrame()

    def _last(series: pd.Series) -> Any:
        if series is None or series.empty:
            return None
        return series.iloc[-1]

    g = epoch_df.groupby("round", dropna=False)
    rounds = list(g.size().index)
    out = pd.DataFrame({"round": rounds})
    out = out.merge(g["grad_train_val_cos"].mean().rename("grad_tvc_mean"), left_on="round", right_index=True, how="left")
    out = out.merge(g["grad_train_val_cos"].median().rename("grad_tvc_median"), left_on="round", right_index=True, how="left")
    out = out.merge(g["grad_train_val_cos"].min().rename("grad_tvc_min"), left_on="round", right_index=True, how="left")
    out = out.merge(g["grad_train_val_cos"].max().rename("grad_tvc_max"), left_on="round", right_index=True, how="left")
    out = out.merge(g["grad_train_val_cos"].apply(_last).rename("grad_tvc_last"), left_on="round", right_index=True, how="left")
    out = out.merge(
        g["grad_train_val_cos"]
        .apply(lambda s: float((pd.to_numeric(s, errors="coerce") < 0).mean()) if len(s) else None)
        .rename("grad_tvc_neg_rate"),
        left_on="round",
        right_index=True,
        how="left",
    )
    out = out.merge(g.size().astype(int).rename("grad_epochs"), left_on="round", right_index=True, how="left")
    out["round"] = pd.to_numeric(out["round"], errors="coerce").astype("Int64")
    for c in ["grad_tvc_mean", "grad_tvc_median", "grad_tvc_min", "grad_tvc_max", "grad_tvc_last", "grad_tvc_neg_rate"]:
        out[c] = pd.to_numeric(out[c], errors="coerce").astype(float)
    out["grad_epochs"] = pd.to_numeric(out["grad_epochs"], errors="coerce").astype("Int64")
    out = out.sort_values("round").reset_index(drop=True)
    return out

def _effective_lambda(per_round_df: pd.DataFrame) -> pd.Series:
    if "lambda_override" in per_round_df.columns:
        lam = pd.to_numeric(per_round_df["lambda_override"], errors="coerce")
    else:
        lam = pd.Series([pd.NA] * len(per_round_df))
    if "lambda_t" in per_round_df.columns:
        lam2 = pd.to_numeric(per_round_df["lambda_t"], errors="coerce")
        lam = lam.where(~lam.isna(), lam2)
    return pd.to_numeric(lam, errors="coerce").astype(float)

def _corr(x: pd.Series, y: pd.Series) -> Optional[float]:
    try:
        xx = pd.to_numeric(x, errors="coerce").astype(float)
        yy = pd.to_numeric(y, errors="coerce").astype(float)
        mask = xx.notna() & yy.notna()
        if int(mask.sum()) < 3:
            return None
        return float(xx[mask].corr(yy[mask]))
    except Exception:
        return None

def _miou_gain(per_round_df: pd.DataFrame) -> pd.Series:
    if "final_miou" not in per_round_df.columns:
        return pd.Series([float("nan")] * len(per_round_df))
    m = pd.to_numeric(per_round_df["final_miou"], errors="coerce").astype(float)
    return m - m.shift(1)

def add_overfit_signals(
    per_round_df: pd.DataFrame,
    risk_w_neg_rate: float = 1.0,
    risk_w_min: float = 0.5,
    risk_w_last: float = 0.5,
) -> pd.DataFrame:
    if per_round_df.empty:
        return per_round_df

    df = per_round_df.copy()
    if "grad_tvc_neg_rate" not in df.columns:
        df["grad_tvc_neg_rate"] = float("nan")
    if "grad_tvc_min" not in df.columns:
        df["grad_tvc_min"] = float("nan")
    if "grad_tvc_last" not in df.columns:
        df["grad_tvc_last"] = float("nan")

    if "overfit_risk" not in df.columns:
        df["overfit_risk"] = float("nan")

    neg_rate = pd.to_numeric(df["grad_tvc_neg_rate"], errors="coerce").astype(float)
    tvc_min = pd.to_numeric(df["grad_tvc_min"], errors="coerce").astype(float)
    tvc_last = pd.to_numeric(df["grad_tvc_last"], errors="coerce").astype(float)

    risk_in_trace = pd.to_numeric(df["overfit_risk"], errors="coerce").astype(float)
    min_bad = (-tvc_min).clip(lower=0.0)
    last_bad = (-tvc_last).clip(lower=0.0)
    computed_risk = (risk_w_neg_rate * neg_rate) + (risk_w_min * min_bad) + (risk_w_last * last_bad)
    if risk_in_trace.notna().any():
        diff = (risk_in_trace - computed_risk).abs()
        bad = diff.notna() & (diff > 1e-6)
        if bool(bad.any()):
            raise RuntimeError("overfit_risk in trace is inconsistent with computed risk")
        df["overfit_risk"] = risk_in_trace
    else:
        df["overfit_risk"] = computed_risk

    df["miou_gain"] = _miou_gain(df)
    df["miou_gain_next"] = pd.to_numeric(df["miou_gain"], errors="coerce").shift(-1)

    lam = _effective_lambda(df)
    df["lambda_eff"] = lam
    df["overfit_risk_next"] = pd.to_numeric(df["overfit_risk"], errors="coerce").shift(-1)
    return df

def analyze_trace_with_gradients(trace_path: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    per_round = load_trace(trace_path)
    epoch = load_epoch_end(trace_path)
    grad_round = aggregate_gradients_per_round(epoch)
    if not per_round.empty and not grad_round.empty:
        per_round = per_round.merge(grad_round, on="round", how="left")
    return per_round, epoch

def plot_overfit_vs_gain(per_round_df: pd.DataFrame, output_dir: str, name: str):
    if per_round_df.empty:
        return
    if "overfit_risk" not in per_round_df.columns or "miou_gain" not in per_round_df.columns:
        return
    x = pd.to_numeric(per_round_df["overfit_risk"], errors="coerce").astype(float)
    y = pd.to_numeric(per_round_df["miou_gain"], errors="coerce").astype(float)
    mask = x.notna() & y.notna()
    if int(mask.sum()) < 3:
        return
    plt.figure(figsize=(8, 6))
    plt.scatter(x[mask], y[mask], c=per_round_df.loc[mask, "round"], cmap="viridis", s=80, edgecolors="k")
    plt.xlabel("overfit_risk", fontsize=12)
    plt.ylabel("mIoU gain (this round)", fontsize=12)
    plt.title(f"overfit_risk vs mIoU gain ({name})", fontsize=13)
    plt.grid(True, linestyle="--", alpha=0.5)
    cbar = plt.colorbar()
    cbar.set_label("round")
    plt.savefig(os.path.join(output_dir, f"{name}_overfit_vs_miou_gain.png"), dpi=300)
    plt.close()

def plot_lambda_vs_tvc(per_round_df: pd.DataFrame, output_dir: str, name: str):
    if per_round_df.empty:
        return
    lam = _effective_lambda(per_round_df)
    if lam.isna().all():
        return
    if "grad_tvc_mean" not in per_round_df.columns and "grad_tvc_last" not in per_round_df.columns:
        return
    tvc = per_round_df["grad_tvc_mean"] if "grad_tvc_mean" in per_round_df.columns else per_round_df["grad_tvc_last"]
    tvc = pd.to_numeric(tvc, errors="coerce").astype(float)
    mask = lam.notna() & tvc.notna()
    if int(mask.sum()) < 3:
        return

    plt.figure(figsize=(8, 6))
    plt.scatter(lam[mask], tvc[mask], c=per_round_df.loc[mask, "round"], cmap="viridis", s=80, edgecolors="k")
    plt.xlabel("lambda", fontsize=12)
    plt.ylabel("grad_train_val_cos (per-round agg)", fontsize=12)
    plt.title(f"lambda vs grad_train_val_cos ({name})", fontsize=13)
    plt.grid(True, linestyle="--", alpha=0.5)
    cbar = plt.colorbar()
    cbar.set_label("round")
    plt.savefig(os.path.join(output_dir, f"{name}_lambda_vs_tvc.png"), dpi=300)
    plt.close()

    plt.figure(figsize=(10, 6))
    ax1 = plt.gca()
    ax1.plot(per_round_df["round"], lam, marker="o", linewidth=2.0, color="#1f77b4", label="lambda")
    ax1.set_xlabel("round", fontsize=12)
    ax1.set_ylabel("lambda", fontsize=12, color="#1f77b4")
    ax1.tick_params(axis="y", labelcolor="#1f77b4")
    ax1.set_ylim(-0.05, 1.05)

    ax2 = ax1.twinx()
    ax2.plot(per_round_df["round"], tvc, marker="s", linewidth=2.0, color="#d62728", label="tvc")
    ax2.set_ylabel("grad_train_val_cos", fontsize=12, color="#d62728")
    ax2.tick_params(axis="y", labelcolor="#d62728")
    ax1.grid(True, linestyle="--", alpha=0.5)
    plt.title(f"lambda & grad_train_val_cos over rounds ({name})", fontsize=13)
    plt.savefig(os.path.join(output_dir, f"{name}_lambda_tvc_trajectory.png"), dpi=300)
    plt.close()

def analyze_run_dir(run_dir: str, output_dir: str, experiment_name: Optional[str]) -> None:
    if not os.path.isdir(run_dir):
        raise NotADirectoryError(run_dir)

    traces = [
        fn
        for fn in os.listdir(run_dir)
        if fn.endswith("_trace.jsonl") and os.path.isfile(os.path.join(run_dir, fn))
    ]
    if experiment_name:
        want = f"{experiment_name}_trace.jsonl"
        traces = [t for t in traces if t == want]
    traces = sorted(traces)
    if not traces:
        raise FileNotFoundError("No *_trace.jsonl found")

    os.makedirs(output_dir, exist_ok=True)

    combined_round_rows: List[pd.DataFrame] = []
    combined_epoch_rows: List[pd.DataFrame] = []
    report_rows: List[Dict[str, Any]] = []
    overfit_report_rows: List[Dict[str, Any]] = []

    for fn in traces:
        trace_path = os.path.join(run_dir, fn)
        name = fn.replace("_trace.jsonl", "")
        per_round, epoch = analyze_trace_with_gradients(trace_path)
        if per_round.empty:
            continue
        per_round = add_overfit_signals(per_round)
        per_round["experiment_name"] = name
        if not epoch.empty:
            epoch["experiment_name"] = name
            combined_epoch_rows.append(epoch)
        combined_round_rows.append(per_round)

        export_path = os.path.join(output_dir, f"{name}_per_round_with_grad.csv")
        per_round.to_csv(export_path, index=False)

        lam = _effective_lambda(per_round)
        corr_lam_tvc_mean = _corr(lam, per_round.get("grad_tvc_mean", pd.Series(dtype=float)))
        corr_lam_tvc_last = _corr(lam, per_round.get("grad_tvc_last", pd.Series(dtype=float)))
        corr_lam_neg_rate = _corr(lam, per_round.get("grad_tvc_neg_rate", pd.Series(dtype=float)))

        report_rows.append(
            {
                "experiment_name": name,
                "n_rounds": int(per_round["round"].notna().sum()) if "round" in per_round.columns else int(len(per_round)),
                "lambda_corr_tvc_mean": corr_lam_tvc_mean,
                "lambda_corr_tvc_last": corr_lam_tvc_last,
                "lambda_corr_tvc_neg_rate": corr_lam_neg_rate,
                "tvc_mean_all_rounds": float(pd.to_numeric(per_round.get("grad_tvc_mean"), errors="coerce").mean()) if "grad_tvc_mean" in per_round.columns else None,
                "tvc_neg_rate_all_rounds_mean": float(pd.to_numeric(per_round.get("grad_tvc_neg_rate"), errors="coerce").mean()) if "grad_tvc_neg_rate" in per_round.columns else None,
                "tvc_min_any": float(pd.to_numeric(per_round.get("grad_tvc_min"), errors="coerce").min()) if "grad_tvc_min" in per_round.columns else None,
                "tvc_max_any": float(pd.to_numeric(per_round.get("grad_tvc_max"), errors="coerce").max()) if "grad_tvc_max" in per_round.columns else None,
            }
        )

        overfit_report_rows.append(
            {
                "experiment_name": name,
                "n_rounds": int(per_round["round"].notna().sum()) if "round" in per_round.columns else int(len(per_round)),
                "overfit_risk_mean": float(pd.to_numeric(per_round.get("overfit_risk"), errors="coerce").mean()) if "overfit_risk" in per_round.columns else None,
                "overfit_risk_max": float(pd.to_numeric(per_round.get("overfit_risk"), errors="coerce").max()) if "overfit_risk" in per_round.columns else None,
                "corr_risk_miou_gain": _corr(per_round.get("overfit_risk", pd.Series(dtype=float)), per_round.get("miou_gain", pd.Series(dtype=float))),
                "corr_risk_miou_gain_next": _corr(per_round.get("overfit_risk", pd.Series(dtype=float)), per_round.get("miou_gain_next", pd.Series(dtype=float))),
                "corr_tvc_mean_miou_gain": _corr(per_round.get("grad_tvc_mean", pd.Series(dtype=float)), per_round.get("miou_gain", pd.Series(dtype=float))),
                "corr_tvc_mean_miou_gain_next": _corr(per_round.get("grad_tvc_mean", pd.Series(dtype=float)), per_round.get("miou_gain_next", pd.Series(dtype=float))),
            }
        )

        plot_lambda_vs_tvc(per_round, output_dir, name)
        plot_overfit_vs_gain(per_round, output_dir, name)

    if combined_round_rows:
        combined_round = pd.concat(combined_round_rows, ignore_index=True)
        combined_round_path = os.path.join(output_dir, "run_all_experiments_per_round_with_grad.csv")
        combined_round.to_csv(combined_round_path, index=False)
        print(f"Saved {combined_round_path}")

    if combined_epoch_rows:
        combined_epoch = pd.concat(combined_epoch_rows, ignore_index=True)
        combined_epoch_path = os.path.join(output_dir, "run_all_experiments_epoch_end_with_grad.csv")
        combined_epoch.to_csv(combined_epoch_path, index=False)
        print(f"Saved {combined_epoch_path}")

    if report_rows:
        report = pd.DataFrame(report_rows).sort_values("experiment_name").reset_index(drop=True)
        report_path = os.path.join(output_dir, "run_grad_alignment_report.csv")
        report.to_csv(report_path, index=False)
        print(f"Saved {report_path}")
        cols = [c for c in ["experiment_name", "n_rounds", "lambda_corr_tvc_mean", "lambda_corr_tvc_last", "tvc_mean_all_rounds", "tvc_neg_rate_all_rounds_mean", "tvc_min_any", "tvc_max_any"] if c in report.columns]
        if cols:
            print(report[cols].to_string(index=False))

    if overfit_report_rows:
        overfit = pd.DataFrame(overfit_report_rows).sort_values("experiment_name").reset_index(drop=True)
        overfit_path = os.path.join(output_dir, "run_overfit_risk_report.csv")
        overfit.to_csv(overfit_path, index=False)
        print(f"Saved {overfit_path}")
        cols = [
            c
            for c in [
                "experiment_name",
                "n_rounds",
                "overfit_risk_mean",
                "overfit_risk_max",
                "corr_risk_miou_gain",
                "corr_risk_miou_gain_next",
                "corr_tvc_mean_miou_gain",
                "corr_tvc_mean_miou_gain_next",
            ]
            if c in overfit.columns
        ]
        if cols:
            print(overfit[cols].to_string(index=False))

def _resolve_trace_path(experiment_dir_or_trace: str, experiment_name: Optional[str]) -> Optional[str]:
    if os.path.isfile(experiment_dir_or_trace) and experiment_dir_or_trace.endswith(".jsonl"):
        return experiment_dir_or_trace

    if not os.path.isdir(experiment_dir_or_trace):
        return None

    direct = os.path.join(experiment_dir_or_trace, "trace.jsonl")
    if os.path.exists(direct):
        return direct

    candidates = [
        fn
        for fn in os.listdir(experiment_dir_or_trace)
        if fn.endswith("_trace.jsonl") and os.path.isfile(os.path.join(experiment_dir_or_trace, fn))
    ]

    if not candidates:
        return None

    if experiment_name:
        expected = f"{experiment_name}_trace.jsonl"
        if expected in candidates:
            return os.path.join(experiment_dir_or_trace, expected)

    if len(candidates) == 1:
        return os.path.join(experiment_dir_or_trace, candidates[0])

    candidates = sorted(candidates)
    print("Error: multiple *_trace.jsonl found; please pass --experiment_name. Candidates:")
    for c in candidates:
        print(f"- {c}")
    return None


def main():
    parser = argparse.ArgumentParser(description="Analyze Strategy from Trace Logs")
    parser.add_argument(
        "experiment_dir",
        type=str,
        help="Path to results/runs/<run_id>/ OR a specific *_trace.jsonl file",
    )
    parser.add_argument("--experiment_name", type=str, default=None, help="Experiment name (used to pick <exp>_trace.jsonl)")
    parser.add_argument("--output", type=str, default=None, help="Output directory for plots/exports")
    parser.add_argument("--export_csv", action="store_true", help="Export per-round summary CSV")
    parser.add_argument("--grad_report", action="store_true", help="Analyze grad alignment across all *_trace.jsonl in a run dir")

    args = parser.parse_args()

    if args.grad_report:
        run_dir = args.experiment_dir
        output_dir = args.output if args.output else run_dir
        analyze_run_dir(run_dir, output_dir, args.experiment_name)
        return

    trace_path = _resolve_trace_path(args.experiment_dir, args.experiment_name)
    if not trace_path:
        raise FileNotFoundError(f"cannot resolve trace path from {args.experiment_dir}")

    df, _epoch = analyze_trace_with_gradients(trace_path)
    df = add_overfit_signals(df)

    if df.empty:
        raise RuntimeError("No per-round data found in trace")

    output_dir = args.output if args.output else (os.path.dirname(trace_path) if os.path.isfile(trace_path) else args.experiment_dir)
    os.makedirs(output_dir, exist_ok=True)

    cols = [
        c
        for c in [
            "round",
            "final_miou",
            "lambda_t",
            "lambda_override",
            "query_size",
            "selected_count",
            "selected_ids_count",
            "u_mean",
            "k_mean",
            "k_p75",
        ]
        if c in df.columns
    ]
    print(f"Loaded {len(df)} rounds from {os.path.basename(trace_path)}")
    if cols:
        print(df[cols].head(20).to_string(index=False))

    if args.export_csv:
        name = args.experiment_name or os.path.basename(trace_path).replace("_trace.jsonl", "")
        export_path = os.path.join(output_dir, f"{name}_per_round_summary.csv")
        df.to_csv(export_path, index=False)
        print(f"CSV exported to {export_path}")

    plot_lambda_trajectory(df, output_dir)
    plot_gradient_decomposition(df, output_dir)
    plot_phase_space(df, output_dir)
    name = args.experiment_name or os.path.basename(trace_path).replace("_trace.jsonl", "")
    plot_lambda_vs_tvc(df, output_dir, name)
    plot_overfit_vs_gain(df, output_dir, name)

    print(f"Outputs saved to {output_dir}")

if __name__ == "__main__":
    main()
