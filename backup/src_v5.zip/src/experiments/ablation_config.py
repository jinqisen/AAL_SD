
# experiments/ablation_config.py

ABLATION_SETTINGS = {
    "full_model": {
        "description": "完整模型（最佳λ日程）：R1-2 λ=0.0；R3 warmup=0.2；R4+ 风险闭环λ（不调整query_size）",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "agent_threshold_overrides": {
            "OVERFIT_RISK_HI": 0.9,
            "OVERFIT_TVC_MIN_HI": 0.6
        },
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 2,
            "warmup_start_round": 3,
            "warmup_rounds": 1,
            "warmup_lambda": 0.2,
            "risk_control_start_round": 4
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "full_model_policy_lambda": {
        "description": "完整模型（规则闭环λ）：固定Warmup(0.2) + 自适应阈值 rollback + 风险驱动 λ 闭环控制（不调整 query_size）",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 2,
            "warmup_start_round": 3,
            "warmup_rounds": 1,
            "warmup_lambda": 0.2,
            "risk_control_start_round": 4
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "full_model_default_thresholds": {
        "description": "完整模型（旧阈值）：固定Warmup(0.2)+默认过拟合阈值(0.8/0.5) + 自适应阈值 rollback + 风险驱动 λ 闭环控制（不调整 query_size）",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "agent_threshold_overrides": {
            "OVERFIT_RISK_HI": 0.8,
            "OVERFIT_TVC_MIN_HI": 0.5
        },
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 2,
            "warmup_start_round": 3,
            "warmup_rounds": 1,
            "warmup_lambda": 0.2,
            "risk_control_start_round": 4
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "full_model_v3_optimized": {
        "description": "完整模型（V3优化版）：Lambda上限0.8，上调步长0.1，Risk阈值1.2，EMA平滑0.6，冷却2轮",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "agent_threshold_overrides": {
            "OVERFIT_RISK_HI": 1.2,
            "OVERFIT_TVC_MIN_HI": 0.6,
            "LAMBDA_CLAMP_MAX": 0.80,
            "LAMBDA_DELTA_UP": 0.10,
            "OVERFIT_RISK_EMA_ALPHA": 0.6,
            "LAMBDA_DOWN_COOLING_ROUNDS": 2
        },
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 2,
            "warmup_start_round": 3,
            "warmup_rounds": 1,
            "warmup_lambda": 0.2,
            "risk_control_start_round": 4
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "full_model_v3_conservative": {
        "description": "完整模型（V3保守版）：仅启用EMA平滑0.6与冷却2轮，其余保持full_model阈值/步长/上限",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "agent_threshold_overrides": {
            "OVERFIT_RISK_HI": 0.9,
            "OVERFIT_TVC_MIN_HI": 0.6,
            "LAMBDA_CLAMP_MAX": 0.65,
            "LAMBDA_DELTA_UP": 0.05,
            "OVERFIT_RISK_EMA_ALPHA": 0.6,
            "LAMBDA_DOWN_COOLING_ROUNDS": 2
        },
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 2,
            "warmup_start_round": 3,
            "warmup_rounds": 1,
            "warmup_lambda": 0.2,
            "risk_control_start_round": 4
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "full_model_v4_robust_severe_last": {
        "description": "完整模型（V4鲁棒severe）：TVC_last+AND判定，mIoU信号EMA，Top-M去冗余与正样本面积约束",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "agent_threshold_overrides": {
            "OVERFIT_RISK_HI": 0.9,
            "OVERFIT_TVC_MIN_HI": 0.6,
            "LAMBDA_CLAMP_MAX": 0.65,
            "LAMBDA_DELTA_UP": 0.05,
            "OVERFIT_RISK_EMA_ALPHA": 0.6,
            "LAMBDA_DOWN_COOLING_ROUNDS": 2
        },
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 2,
            "warmup_start_round": 3,
            "warmup_rounds": 1,
            "warmup_lambda": 0.2,
            "risk_control_start_round": 4,
            "severe_tvc_key": "grad_train_val_cos_last",
            "severe_logic": "and"
        },
        "training_state_policy": {
            "miou_signal": "ema",
            "ema_alpha": 0.6,
            "last_k": 3,
            "delta_source": "miou_signal"
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "selection_postprocess": {
            "mode": "fps_feature",
            "candidate_multiplier": 5,
            "seed": 42
        },
        "candidate_constraints": {
            "use_pred_pos_area": True,
            "pos_class": 1,
            "pos_threshold": 0.5,
            "pos_area_min": 0.001,
            "pos_quota_ratio": 0.5
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "full_model_v3_tvc_relaxed": {
        "description": "完整模型（V3放宽TVC）：维持λ上限0.8/上调0.1/冷却2轮，同时放宽TVC_min阈值0.7",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "agent_threshold_overrides": {
            "OVERFIT_RISK_HI": 1.2,
            "OVERFIT_TVC_MIN_HI": 0.7,
            "LAMBDA_CLAMP_MAX": 0.80,
            "LAMBDA_DELTA_UP": 0.10,
            "OVERFIT_RISK_EMA_ALPHA": 0.6,
            "LAMBDA_DOWN_COOLING_ROUNDS": 2
        },
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 2,
            "warmup_start_round": 3,
            "warmup_rounds": 1,
            "warmup_lambda": 0.2,
            "risk_control_start_round": 4
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "no_cold_start": {
        "description": "消融：去除冷启动与warmup，直接进入风险闭环",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 0,
            "warmup_start_round": 1,
            "warmup_rounds": 0,
            "warmup_lambda": 0.0,
            "risk_control_start_round": 1
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "fixed_k": {
        "description": "消融：固定K阶段（保持coreset-to-labeled），仅保留λ闭环",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "k_definition": "coreset_to_labeled_fixed",
        "lambda_policy": {
            "mode": "warmup_risk_closed_loop",
            "r1_lambda": 0.0,
            "uncertainty_only_rounds": 2,
            "warmup_start_round": 3,
            "warmup_rounds": 1,
            "warmup_lambda": 0.2,
            "risk_control_start_round": 4
        },
        "rollback_config": {
            "mode": "adaptive_threshold",
            "std_factor": 1.5,
            "tau_min": 0.005
        },
        "overfit_guard": True,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "full_model_fixed_epochs_lambda_budget": {
        "description": "消融（固定epochs=10）：仅允许控制λ与query_size",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "control_permissions": {
            "set_lambda": True,
            "set_query_size": True,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "no_agent": {
        "description": "消融：移除Agent；λ由sigmoid自适应(随标注进度变化)，仅使用AD-KUCS数值策略选样",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": None
    },
    "random_lambda": {
        "description": "消融：随机λ控制（无LLM）",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "lambda_controller": {
            "mode": "random",
            "lambda_min": 0.0,
            "lambda_max": 1.0
        }
    },
    "rule_based_controller_r1": {
        "description": "消融：Rule-based Controller R1（性能驱动）",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_controller": {
            "mode": "rule_based",
            "rule": "r1",
            "lambda_min": 0.0,
            "lambda_max": 1.0,
            "step_up": 0.05,
            "step_down": 0.1,
            "miou_delta_threshold": 0.0,
            "rollback_priority": True
        }
    },
    "rule_based_controller_r2": {
        "description": "消融：Rule-based Controller R2（轮次日程）",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_controller": {
            "mode": "rule_based",
            "rule": "r2",
            "lambda_min": 0.0,
            "lambda_max": 1.0,
            "schedule": [
                {"round": 1, "lambda": 0.2},
                {"round": 4, "lambda": 0.5},
                {"round": 8, "lambda": 0.8}
            ]
        }
    },
    "rule_based_controller_r3": {
        "description": "消融：Rule-based Controller R3（日程+性能微调）",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256,
        "lambda_controller": {
            "mode": "rule_based",
            "rule": "r3",
            "lambda_min": 0.0,
            "lambda_max": 1.0,
            "schedule": [
                {"round": 1, "lambda": 0.2},
                {"round": 4, "lambda": 0.5},
                {"round": 8, "lambda": 0.8}
            ],
            "step_up": 0.05,
            "step_down": 0.1,
            "miou_delta_threshold": 0.0,
            "rollback_priority": True
        }
    },
    "uncertainty_only": {
        "description": "固定λ=0，仅使用不确定性",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": 0.0
    },
    "knowledge_only": {
        "description": "固定λ=1，仅使用知识增益",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": 1.0
    },
    "fixed_lambda": {
        "description": "消融：固定λ=0.5（对应方案A1：No LLM Agent）",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": 0.5
    },
    "no_normalization": {
        "description": "消融：不进行U/K归一化",
        "use_agent": False,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "score_normalization": False
    },
    "baseline_random": {
        "description": "随机采样基线",
        "use_agent": False,
        "sampler_type": "random",
        "lambda_override": None
    },
    "baseline_entropy": {
        "description": "熵采样基线",
        "use_agent": False,
        "sampler_type": "entropy",
        "lambda_override": None
    },
    "baseline_coreset": {
        "description": "Core-Set采样基线",
        "use_agent": False,
        "sampler_type": "coreset",
        "lambda_override": None
    },
    "baseline_bald": {
        "description": "BALD采样基线",
        "use_agent": False,
        "sampler_type": "bald",
        "lambda_override": None
    },
    "baseline_dial_style": {
        "description": "DIAL-style基线：分簇多样性约束+不确定性",
        "use_agent": False,
        "sampler_type": "dial",
        "lambda_override": None,
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256
    },
    "baseline_wang_style": {
        "description": "Wang-style基线：两阶段U→K重排",
        "use_agent": False,
        "sampler_type": "wang",
        "lambda_override": None,
        "enable_l3_logging": True,
        "l3_topk": 256,
        "l3_max_selected": 256
    },
    "baseline_llm_us": {
        "description": "LLM仅基于不确定性分数",
        "use_agent": False,
        "sampler_type": "llm_us",
        "lambda_override": None
    },
    "baseline_llm_rs": {
        "description": "LLM仅基于随机分数",
        "use_agent": False,
        "sampler_type": "llm_rs",
        "lambda_override": None
    },
    "agent_control_lambda": {
        "description": "Agent控制消融：仅允许set_lambda",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "control_permissions": {
            "set_lambda": True,
            "set_query_size": False,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    },
    "agent_control_budget": {
        "description": "Agent控制消融：仅允许set_query_size",
        "use_agent": True,
        "sampler_type": "ad_kucs",
        "lambda_override": None,
        "control_permissions": {
            "set_lambda": False,
            "set_query_size": True,
            "set_epochs_per_round": False,
            "set_alpha": False
        }
    }
}

MULTI_SEED_DEFAULTS = {
    "seeds": [42, 43, 44],
    "paper_experiments": [
        "full_model",
        "full_model_policy_lambda",
        "rule_based_controller_r1",
        "rule_based_controller_r2",
        "rule_based_controller_r3",
        "random_lambda",
        "no_cold_start",
        "fixed_k",
        "no_normalization",
        "baseline_entropy",
        "baseline_random",
        "baseline_coreset",
        "baseline_bald",
        "baseline_dial_style",
        "baseline_wang_style",
        "no_agent",
        "fixed_lambda",
    ],
}
