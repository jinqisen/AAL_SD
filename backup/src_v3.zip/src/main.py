
import argparse
import os
from datetime import datetime
import hashlib
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset
import numpy as np
import random

from config import Config
from core.data_preprocessing import DataPreprocessor
from core.dataset import Landslide4SenseDataset
from core.model import LandslideDeepLabV3
from core.trainer import Trainer
from core.sampler import ADKUCSSampler
from agent.agent_manager import AgentManager
from agent.toolbox import Toolbox
from agent.prompt_template import PromptBuilder
from agent.agent_manager import SiliconFlowClient
from agent.config import AgentThresholds
from baselines.random_sampler import RandomSampler
from baselines.entropy_sampler import EntropySampler
from baselines.coreset_sampler import CoresetSampler
from baselines.bald_sampler import BALDSampler
from baselines.llm_us_sampler import LLMUncertaintySampler
from baselines.llm_rs_sampler import LLMRandomSampler
from experiments.ablation_config import ABLATION_SETTINGS
from utils.logger import logger
from utils.evaluation import calculate_alc
from utils.reproducibility import set_global_seed, worker_init_fn
from core.checkpoint import CheckpointManager

class ActiveLearningPipeline:
    def __init__(self, config, experiment_name, run_id=None):
        self.config = config
        self.experiment_name = experiment_name
        self.run_id = run_id
        if getattr(self.config, "RESEARCH_MODE", False) and not self.run_id:
            raise ValueError("Research mode requires explicit run_id")
        if not self.run_id:
            self.run_id = "default"
        self.exp_config = ABLATION_SETTINGS.get(experiment_name)
        if not self.exp_config:
            raise ValueError(f"Unknown experiment: {experiment_name}")
        
        # Centralized Randomness Control
        self.seed = int(getattr(self.config, "RANDOM_SEED", 42) or 42)
        self.deterministic = getattr(self.config, "DETERMINISTIC", True)
        set_global_seed(self.seed, deterministic=self.deterministic)

        logger.info(f"Initializing Experiment: {experiment_name}")
        logger.info(f"Description: {self.exp_config['description']}")
        logger.info(
            f"Isolation: run_id={self.run_id} experiment={self.experiment_name} pools_dir={getattr(self.config, 'POOLS_DIR', None)} "
            f"results_dir={getattr(self.config, 'RESULTS_DIR', None)} checkpoint_dir={getattr(self.config, 'CHECKPOINT_DIR', None)}"
        )
        
        self.pools_dir = self._resolve_pools_dir()

        checkpoint_dir = os.path.join(config.CHECKPOINT_DIR, self.run_id)
        self.checkpoint_manager = CheckpointManager(checkpoint_dir, experiment_name)

        self.run_reports_dir = os.path.join(config.RESULTS_DIR, "runs", self.run_id)
        os.makedirs(self.run_reports_dir, exist_ok=True)
        self.status_path = os.path.join(self.run_reports_dir, f"{self.experiment_name}_status.json")
        self.trace_path = os.path.join(self.run_reports_dir, f"{self.experiment_name}_trace.jsonl")

        # 1. Data Preprocessing
        start_mode = getattr(self.config, "START_MODE", "resume")
        if start_mode == "fresh":
            if os.path.exists(self.checkpoint_manager.checkpoint_path):
                try:
                    os.remove(self.checkpoint_manager.checkpoint_path)
                except Exception:
                    pass
            if os.path.exists(self.status_path):
                try:
                    os.remove(self.status_path)
                except Exception:
                    pass
            if os.path.exists(self.trace_path):
                try:
                    os.remove(self.trace_path)
                except Exception:
                    pass

        legacy_mode = bool(getattr(self.config, "ALLOW_LEGACY_POOLS", False) and self.run_id == "default")
        if legacy_mode:
            pools_subdir = os.path.relpath(self.pools_dir, config.POOLS_DIR)
            preprocessor = DataPreprocessor(config, experiment_name=pools_subdir)
            preprocessor.create_data_pools(force=(start_mode == "fresh"))
        else:
            import shutil
            base_subdir = os.path.join(self.run_id, "_base")
            base_preprocessor = DataPreprocessor(config, experiment_name=base_subdir)
            base_preprocessor.create_data_pools(force=(start_mode == "fresh"))

            base_dir = os.path.join(config.POOLS_DIR, base_subdir)
            os.makedirs(self.pools_dir, exist_ok=True)
            for name in ("labeled_pool.csv", "unlabeled_pool.csv", "test_pool.csv"):
                src = os.path.join(base_dir, name)
                dst = os.path.join(self.pools_dir, name)
                if not os.path.exists(src):
                    pools_subdir = os.path.relpath(self.pools_dir, config.POOLS_DIR)
                    fallback_preprocessor = DataPreprocessor(config, experiment_name=pools_subdir)
                    fallback_preprocessor.create_data_pools(force=(start_mode == "fresh"))
                    break
                if start_mode == "fresh" or (not os.path.exists(dst)):
                    tmp = dst + ".tmp"
                    shutil.copy2(src, tmp)
                    os.replace(tmp, dst)
        
        # 2. Load Data Pools
        import pandas as pd
        self.labeled_df = pd.read_csv(os.path.join(self.pools_dir, 'labeled_pool.csv'))
        self.unlabeled_df = pd.read_csv(os.path.join(self.pools_dir, 'unlabeled_pool.csv'))
        self.test_df = pd.read_csv(os.path.join(self.pools_dir, 'test_pool.csv'))
        
        # Map sample_id to indices in the full dataset is tricky if we don't load full dataset.
        # But Dataset class loads by directory. 
        # Strategy: Load Full Train/Val Dataset, then map file names to indices.
        
        # NOTE: Landslide4SenseDataset loads all files in a dir.
        # We need to construct indices based on file names.
        
        self.full_dataset = Landslide4SenseDataset(config.DATA_DIR, split='train')
        self.dataset = self.full_dataset
        # Assuming 'train' split in dataset class points to the folder containing all training candidates
        
        self.labeled_indices = self._map_filenames_to_indices(self.full_dataset, self.labeled_df['sample_id'].tolist())
        self.unlabeled_indices = self._map_filenames_to_indices(self.full_dataset, self.unlabeled_df['sample_id'].tolist())
        
        self.test_dataset = Landslide4SenseDataset(config.DATA_DIR, split='test') # or val if split logic differs
        # Wait, create_data_pools split TrainData into Labeled/Unlabeled/Test.
        # So 'test_pool.csv' are samples from 'TrainData' folder that we reserved for testing this AL experiment.
        # They are NOT the official 'TestData' folder (which usually has no masks).
        # So we should use full_dataset for everything, just different indices.
        
        self.test_indices = self._map_filenames_to_indices(self.full_dataset, self.test_df['sample_id'].tolist())
        
        logger.info(f"Initial Labeled: {len(self.labeled_indices)}, Unlabeled: {len(self.unlabeled_indices)}, Test: {len(self.test_indices)}")

        self._assert_pool_integrity()
        if getattr(self.config, 'TOTAL_BUDGET', None) in (None, 0):
            self.config.TOTAL_BUDGET = max(int(len(self.full_dataset) * 0.1), 1)
        logger.info(
            f"Config budget: ESTIMATED_TOTAL_SAMPLES={getattr(self.config, 'ESTIMATED_TOTAL_SAMPLES', None)} "
            f"BUDGET_RATIO={getattr(self.config, 'BUDGET_RATIO', None)} TOTAL_BUDGET={getattr(self.config, 'TOTAL_BUDGET', None)}"
        )
        
        # 3. Initialize Sampler
        self.sampler_type = self.exp_config['sampler_type']
        if self.sampler_type == 'random':
            self.sampler = RandomSampler(config)
        elif self.sampler_type == 'entropy':
            self.sampler = EntropySampler(config)
        elif self.sampler_type == 'coreset':
            self.sampler = CoresetSampler(config)
        elif self.sampler_type == 'bald':
            self.sampler = BALDSampler(config)
        elif self.sampler_type == 'llm_us':
            self.sampler = LLMUncertaintySampler(config)
        elif self.sampler_type == 'llm_rs':
            self.sampler = LLMRandomSampler(config)
        else: # ad_kucs
            self.k_definition = "coreset_to_labeled"
            self.rollback_config = self.exp_config.get("rollback_config") or {
                "mode": "adaptive_threshold",
                "std_factor": 1.5,
                "tau_min": 0.005,
            }
            self.sampler = ADKUCSSampler(device=config.DEVICE, alpha=config.ALPHA)
            
        # 4. Agent Setup
        self.use_agent = self.exp_config['use_agent']
        self.agent_manager = None
        if (
            self.use_agent
            and getattr(self.config, "REQUIRE_LLM_FOR_AGENT", True)
            and (not getattr(self.config, "LLM_API_KEY", None))
            and getattr(self.config, "STRICT_INNOVATION", False)
        ):
            raise RuntimeError("STRICT_INNOVATION requires LLM_API_KEY for agent experiments")
        if self.use_agent:
            # We need a model placeholder to init toolbox, but model changes every round
            # We will set toolbox.model later
            dummy_model = None 
            # We need a wrapper to act as 'controller' for toolbox (providing dataset/indices)
            self.toolbox = Toolbox(self, self.sampler, dummy_model)
            
            # Set control permissions for ablation experiments
            control_permissions = self.exp_config.get('control_permissions')
            if control_permissions is None:
                if getattr(self.config, "RESEARCH_MODE", False):
                    raise ValueError(
                        f"Research mode requires explicit control_permissions for agent experiment: {self.experiment_name}"
                    )
                fixed_epochs = bool(getattr(self.config, "FIX_EPOCHS_PER_ROUND", False))
                control_permissions = {
                    "set_lambda": True,
                    "set_query_size": True,
                    "set_epochs_per_round": (not fixed_epochs),
                    "set_alpha": True,
                }

            self.toolbox.set_control_permissions(control_permissions)
            logger.info(f"Control permissions set: {control_permissions}")
            
            client = SiliconFlowClient(
                api_key=config.LLM_API_KEY,
                base_url=config.LLM_BASE_URL,
                model=config.LLM_MODEL,
                temperature=config.LLM_TEMPERATURE,
                timeout=config.LLM_TIMEOUT,
                max_retries=int(getattr(config, "LLM_MAX_RETRIES", 0) or 0),
                retry_delay=float(getattr(config, "LLM_RETRY_BASE_SECONDS", 0.0) or 5.0),
                retry_backoff=float(getattr(config, "LLM_RETRY_BACKOFF", 1.0) or 2.0)
            )
            self.agent_manager = AgentManager(self.toolbox, client=client, verbose=True)
            self.agent_manager.llm_max_retries = int(getattr(config, "LLM_MAX_RETRIES", 0) or 0)
            self.agent_manager.llm_retry_base_seconds = float(getattr(config, "LLM_RETRY_BASE_SECONDS", 0.0) or 0.0)
            self.agent_manager.llm_retry_backoff = float(getattr(config, "LLM_RETRY_BACKOFF", 1.0) or 1.0)
            self.agent_manager.llm_retry_max_seconds = float(getattr(config, "LLM_RETRY_MAX_SECONDS", 0.0) or 0.0)
            self.agent_manager.reset()
        self.current_round = None
        self._last_query_selected_count = None
        self._selection_context = None
        self._last_score_precalc_error = None
        self._last_ranking_degraded = None
        self.default_query_size = int(getattr(self.config, "QUERY_SIZE", 0) or 0)
        self.default_epochs_per_round = int(getattr(self.config, "EPOCHS_PER_ROUND", 0) or 0)
        self._pending_round_controls = {}

        self._write_status({
            "status": "initialized",
            "pools_dir": self.pools_dir,
            "checkpoint_path": self.checkpoint_manager.checkpoint_path,
            "initial": {
                "labeled": int(len(self.labeled_indices)),
                "unlabeled": int(len(self.unlabeled_indices)),
                "test": int(len(self.test_indices))
            }
        })

        self._append_trace({
            "type": "initialized",
            "pools_dir": self.pools_dir,
            "checkpoint_path": self.checkpoint_manager.checkpoint_path,
            "counts": {
                "labeled": int(len(self.labeled_indices)),
                "unlabeled": int(len(self.unlabeled_indices)),
                "test": int(len(self.test_indices))
            }
        })

        try:
            import torch
            logger.info(
                f"Runtime: device={getattr(self.config, 'DEVICE', None)} num_workers={getattr(self.config, 'NUM_WORKERS', None)} "
                f"torch_threads={torch.get_num_threads()} torch_interop_threads={torch.get_num_interop_threads()}"
            )
        except Exception:
            logger.info(
                f"Runtime: device={getattr(self.config, 'DEVICE', None)} num_workers={getattr(self.config, 'NUM_WORKERS', None)}"
            )

    def _write_status(self, patch):
        import json
        payload = {}
        try:
            if os.path.exists(self.status_path):
                with open(self.status_path, "r", encoding="utf-8") as f:
                    existing = json.load(f)
                if isinstance(existing, dict):
                    payload.update(existing)
        except Exception:
            payload = {}

        base = {
            "run_id": self.run_id,
            "experiment_name": self.experiment_name,
            "updated_at": datetime.now().isoformat()
        }
        payload.update(base)
        if isinstance(patch, dict):
            payload.update(patch)

        tmp = self.status_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self.status_path)

    def _append_trace(self, event):
        import json
        payload = {
            "run_id": self.run_id,
            "experiment_name": self.experiment_name,
            "ts": datetime.now().isoformat(),
        }
        if isinstance(event, dict):
            payload.update(event)
        line = json.dumps(payload, ensure_ascii=False)
        with open(self.trace_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")

    def _resolve_pools_dir(self):
        if (
            getattr(self.config, "ALLOW_LEGACY_POOLS", False)
            and self.run_id == "default"
        ):
            legacy = os.path.join(self.config.POOLS_DIR, self.experiment_name)
            labeled = os.path.join(legacy, "labeled_pool.csv")
            unlabeled = os.path.join(legacy, "unlabeled_pool.csv")
            test = os.path.join(legacy, "test_pool.csv")
            if os.path.exists(labeled) or os.path.exists(unlabeled) or os.path.exists(test):
                return legacy
        return os.path.join(self.config.POOLS_DIR, self.run_id, self.experiment_name)

    def _map_filenames_to_indices(self, dataset, filenames):
        # Create a map name -> idx
        # dataset.images is list of filenames like 'img_1.h5'
        name_to_idx = {os.path.splitext(f)[0]: i for i, f in enumerate(dataset.images)}
        indices = []
        for name in filenames:
            if name in name_to_idx:
                indices.append(name_to_idx[name])
        return indices

    def _pool_integrity(self):
        labeled_ids = set(self.labeled_df['sample_id'].tolist()) if hasattr(self, 'labeled_df') else set()
        unlabeled_ids = set(self.unlabeled_df['sample_id'].tolist()) if hasattr(self, 'unlabeled_df') else set()
        test_ids = set(self.test_df['sample_id'].tolist()) if hasattr(self, 'test_df') else set()
        overlap_l_u = len(labeled_ids.intersection(unlabeled_ids))
        overlap_l_t = len(labeled_ids.intersection(test_ids))
        overlap_u_t = len(unlabeled_ids.intersection(test_ids))
        union = labeled_ids.union(unlabeled_ids).union(test_ids)
        return {
            "counts": {
                "labeled": int(len(labeled_ids)),
                "unlabeled": int(len(unlabeled_ids)),
                "test": int(len(test_ids)),
                "union": int(len(union)),
                "dataset": int(len(getattr(self.full_dataset, 'images', []) or []))
            },
            "overlaps": {
                "labeled_unlabeled": int(overlap_l_u),
                "labeled_test": int(overlap_l_t),
                "unlabeled_test": int(overlap_u_t)
            }
        }

    def _assert_pool_integrity(self):
        integrity = self._pool_integrity()
        if int(integrity["counts"].get("labeled") or 0) <= 0:
            if getattr(self.config, "STRICT_RESUME", False):
                raise RuntimeError(f"Labeled pool is empty: {integrity}")
        ok = (
            integrity["overlaps"]["labeled_unlabeled"] == 0
            and integrity["overlaps"]["labeled_test"] == 0
            and integrity["overlaps"]["unlabeled_test"] == 0
            and integrity["counts"]["union"] == integrity["counts"]["dataset"]
        )
        self._write_status({"pool_integrity": integrity, "pool_integrity_ok": bool(ok)})
        if not ok and getattr(self.config, "STRICT_RESUME", False):
            raise RuntimeError(f"Pool integrity check failed: {integrity}")
        return ok

    def _dataset_fingerprint(self):
        import hashlib
        names = list(getattr(self.full_dataset, 'images', []) or [])
        names = sorted([os.path.basename(n) for n in names])
        h = hashlib.sha256()
        for name in names:
            h.update(name.encode("utf-8", errors="ignore"))
            h.update(b"\n")
        return {"count": int(len(names)), "sha256": h.hexdigest()}

    def _classify_error(self, message):
        text = (message or "").lower()
        if "dataloader worker" in text and "exited unexpectedly" in text:
            return "dataloader_worker_exit"
        if "out of memory" in text:
            return "out_of_memory"
        if "timed out" in text:
            return "timeout"
        if "selection failed" in text:
            return "selection_failed"
        return "unknown"

    def _sampler_audit(self):
        rollback_cfg = getattr(self, "rollback_config", None)
        if not isinstance(rollback_cfg, dict):
            rollback_cfg = {}
        return {
            "sampler_type": getattr(self, "sampler_type", None),
            "sampler_class": self.sampler.__class__.__name__ if hasattr(self, "sampler") and self.sampler is not None else None,
            "k_definition": getattr(self, "k_definition", None),
            "rollback_mode": rollback_cfg.get("mode"),
            "rollback_threshold": rollback_cfg.get("threshold"),
            "rollback_std_factor": rollback_cfg.get("std_factor"),
        }

    def _deterministic_hash_order(self, indices, salt: str):
        def _key(x):
            try:
                v = int(x)
            except Exception:
                v = str(x)
            return hashlib.sha256(f"{salt}:{v}".encode("utf-8")).hexdigest()

        return sorted(list(indices or []), key=_key)

    def _append_md(self, log_path, content):
        if not log_path:
            return
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(content)

    def _parse_log_resume_state(self, log_path):
        if not log_path or not os.path.exists(log_path):
            return None, None, None
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception:
            return None, None, None
        
        if "## 实验汇总" in content:
            return None, None, None
        
        import re
        rounds = re.findall(r"## Round (\d+)", content)
        if not rounds:
            return None, None, None
        
        last_round = int(rounds[-1])
        
        labeled_sizes = re.findall(r"Labeled Pool Size: (\d+)", content)
        if not labeled_sizes:
            return None, None, None
        
        last_labeled_size = int(labeled_sizes[-1])
        
        performance_history = []
        miou_matches = re.findall(r"Round=(\d+), Labeled=(\d+), mIoU=([\d.]+), F1=([\d.]+)", content)
        for match in miou_matches:
            round_num, labeled_size, miou, f1 = match
            performance_history.append({
                "round": int(round_num),
                "mIoU": float(miou),
                "f1_score": float(f1),
                "labeled_size": int(labeled_size)
            })
        
        return last_round, last_labeled_size, performance_history

    def run_and_collect(self, log_path=None):
        performance_history = []
        budget_history = []
        best_miou_so_far = 0.0

        start_mode = getattr(self.config, "START_MODE", "resume")

        dataset_fingerprint = self._dataset_fingerprint()
        self._write_status({"dataset_fingerprint": dataset_fingerprint})
        self._append_trace({"type": "dataset_fingerprint", "fingerprint": dataset_fingerprint})

        manifest_path = os.path.join(self.run_reports_dir, "manifest.json")
        if os.path.exists(manifest_path):
            try:
                import json
                with open(manifest_path, "r", encoding="utf-8") as f:
                    manifest = json.load(f)
                expected_fp = manifest.get("dataset_fingerprint") if isinstance(manifest, dict) else None
                if isinstance(expected_fp, dict) and expected_fp.get("sha256") and expected_fp != dataset_fingerprint:
                    if getattr(self.config, "STRICT_RESUME", False):
                        raise RuntimeError(f"Dataset fingerprint mismatch: expected={expected_fp} actual={dataset_fingerprint}")
                    self._write_status({"dataset_fingerprint_mismatch": {"expected": expected_fp, "actual": dataset_fingerprint}})

                if start_mode != "fresh" and isinstance(manifest, dict):
                    cfg_snapshot = manifest.get("config")
                    if isinstance(cfg_snapshot, dict):
                        tracked_keys = (
                            "RANDOM_SEED",
                            "DETERMINISTIC",
                            "ESTIMATED_TOTAL_SAMPLES",
                            "BUDGET_RATIO",
                            "TOTAL_BUDGET",
                            "INITIAL_LABELED_SIZE",
                            "TEST_SIZE",
                            "N_ROUNDS",
                            "QUERY_SIZE",
                            "EPOCHS_PER_ROUND",
                            "BATCH_SIZE",
                            "LR",
                            "ALPHA",
                        )
                        mismatches = {}
                        for key in tracked_keys:
                            if key not in cfg_snapshot:
                                continue
                            value = cfg_snapshot.get(key)
                            if value is None:
                                continue
                            current = getattr(self.config, key, None)
                            if current is not None and current != value:
                                mismatches[key] = {"current": current, "manifest": value}
                            try:
                                setattr(self.config, key, value)
                            except Exception:
                                pass
                        if mismatches:
                            self._write_status({"manifest_config_mismatch": mismatches})
                            self._append_trace({"type": "manifest_config_mismatch", "mismatches": mismatches})
                            if getattr(self.config, "STRICT_RESUME", False):
                                raise RuntimeError(f"Manifest config mismatch: {mismatches}")
                        applied = {k: cfg_snapshot.get(k) for k in tracked_keys if k in cfg_snapshot}
                        self._append_trace({"type": "manifest_config_applied", "config": applied})
            except Exception as e:
                if getattr(self.config, "STRICT_RESUME", False):
                    raise
                self._write_status({"manifest_read_error": str(e)})
        
        if start_mode == "fresh":
            if log_path:
                try:
                    with open(log_path, "w", encoding="utf-8") as f:
                        f.write(
                            f"# 实验日志\n\n实验名称: {self.experiment_name}\n描述: {self.exp_config['description']}\n开始时间: {datetime.now().isoformat()}\n\n"
                        )
                except Exception:
                    pass
            start_round = 0
        else:
            state = self.checkpoint_manager.load()
            if state:
                performance_history = state.get('performance_history', [])
                budget_history = state.get('budget_history', [])
                start_round = state.get('round', 0)

                logger.info(f"Resumed from checkpoint: Round {start_round}")

                # 1. Rollback Pools if necessary (Atomic Guarantee)
                target_size = state.get('labeled_size', len(self.labeled_indices) if hasattr(self, 'labeled_indices') else 0)
                # Note: self.labeled_indices might not be inited yet if we don't load pools first.
                # Actually we call _load_pool_states later. 
                # But _rollback_pools reads CSV directly.
                
                # Check if we need to rollback before loading pools?
                # Actually, _rollback_pools writes CSVs.
                if not self._rollback_pools(target_size):
                     if getattr(self.config, "STRICT_RESUME", False):
                          logger.error("Pool rollback failed.")
                          # If rollback failed (e.g. pool files missing), we rely on _load_pool_states to check.
                
                # 2. Truncate Trace (Idempotency Guarantee)
                self._truncate_trace(start_round)
                
                # 3. Restore RNG States (Reproducibility Guarantee)
                self._set_rng_states(state.get('rng_states', {}))
                
                if self.use_agent and self.agent_manager:
                     # Restore pending controls
                     self._pending_round_controls = state.get('pending_round_controls', {})

                fixed_epochs = bool(getattr(self.config, "FIX_EPOCHS_PER_ROUND", False))
                if fixed_epochs and isinstance(self._pending_round_controls, dict):
                    self._pending_round_controls.pop("epochs_round", None)

                loaded = self._load_pool_states()
                if not loaded:
                    if getattr(self.config, "STRICT_RESUME", False):
                        raise RuntimeError("Checkpoint found but pool files missing")
                    logger.warning("Checkpoint found but pool files missing! State might be inconsistent.")
                else:
                    self._assert_pool_integrity()

                if log_path:
                    self._append_md(
                        log_path,
                        f"\n--- [Checkpoint] 续跑开始时间: {datetime.now().isoformat()} ---\n\n"
                    )
            else:
                if log_path:
                    # Legacy log parsing
                    last_round, last_labeled_size, log_performance_history = self._parse_log_resume_state(log_path)
                    if last_round is not None:
                        performance_history = log_performance_history
                        budget_history = [p["labeled_size"] for p in performance_history]
                        logger.info(f"Resuming from Round {last_round}, Labeled Pool Size: {last_labeled_size}")
                        loaded = self._load_pool_states()
                        if not loaded:
                            if getattr(self.config, "STRICT_RESUME", False):
                                raise RuntimeError("Legacy log resume requested but pool files missing")
                            logger.warning("Failed to load pool states, using current state")
                        else:
                            self._assert_pool_integrity()
                        self._append_md(
                            log_path,
                            f"\n--- [Legacy Log] 续跑开始时间: {datetime.now().isoformat()} ---\n\n"
                        )
                    else:
                        self._append_md(
                            log_path,
                            f"# 实验日志\n\n实验名称: {self.experiment_name}\n描述: {self.exp_config['description']}\n开始时间: {datetime.now().isoformat()}\n\n"
                        )
                start_round = 0
                if performance_history:
                    start_round = performance_history[-1]["round"]

        self._write_status({
            "status": "running",
            "resume": {
                "start_round": int(start_round)
            }
        })

        for round_idx in range(start_round, self.config.N_ROUNDS):
            self.current_round = round_idx + 1
            self._selection_context = None
            self._last_score_precalc_error = None
            self._last_ranking_degraded = None
            self._last_ranking_metadata = None

            fixed_epochs = bool(getattr(self.config, "FIX_EPOCHS_PER_ROUND", False))
            epochs_schedule = getattr(self.config, "EPOCHS_PER_ROUND_SCHEDULE", None)
            scheduled_epochs = None
            if (not fixed_epochs) and isinstance(epochs_schedule, (list, tuple)) and round_idx < len(epochs_schedule):
                scheduled_epochs = epochs_schedule[round_idx]

            self.config.QUERY_SIZE = int(self.default_query_size)
            self.config.EPOCHS_PER_ROUND = int(self.default_epochs_per_round)
            if (not fixed_epochs) and scheduled_epochs is not None:
                try:
                    self.config.EPOCHS_PER_ROUND = int(scheduled_epochs)
                except Exception:
                    self.config.EPOCHS_PER_ROUND = int(self.default_epochs_per_round)

            if self.use_agent and self.agent_manager:
                self.toolbox.reset_round_controls()
                pending_epochs = None
                if (not fixed_epochs) and isinstance(self._pending_round_controls, dict):
                    pending_epochs = self._pending_round_controls.pop('epochs_round', None)
                allow_epoch_control = bool(getattr(self.toolbox, "control_permissions", {}).get("set_epochs_per_round", False))
                if (not fixed_epochs) and allow_epoch_control and pending_epochs is not None:
                    self.config.EPOCHS_PER_ROUND = int(pending_epochs)
                    self.toolbox.control_state['epochs_round'] = int(pending_epochs)
            logger.info(f"=== Round {round_idx + 1}/{self.config.N_ROUNDS} ===")
            logger.info(f"Labeled Pool Size: {len(self.labeled_indices)}")
            self._append_md(
                log_path,
                f"## Round {round_idx+1}\n\nLabeled Pool Size: {len(self.labeled_indices)}\n\n"
            )

            try:
                early_stop = False
                model = LandslideDeepLabV3(in_channels=self.config.IN_CHANNELS, classes=self.config.NUM_CLASSES)
                trainer = Trainer(model, self.config, self.config.DEVICE)

                labeled_subset = Subset(self.full_dataset, self.labeled_indices)
                
                # Unified Seeding: Ensure each round has a deterministic but distinct seed
                current_seed = self.seed + int(round_idx + 1)
                set_global_seed(current_seed, deterministic=self.deterministic)
                
                # Generator for DataLoader shuffling
                g = torch.Generator()
                g.manual_seed(current_seed)

                labeled_loader = DataLoader(
                    labeled_subset,
                    batch_size=self.config.BATCH_SIZE,
                    shuffle=True,
                    num_workers=self.config.NUM_WORKERS,
                    drop_last=True,
                    generator=g,
                    worker_init_fn=worker_init_fn,
                )

                test_subset = Subset(self.full_dataset, self.test_indices)
                test_loader = DataLoader(
                    test_subset, 
                    batch_size=self.config.BATCH_SIZE, 
                    shuffle=False, 
                    num_workers=self.config.NUM_WORKERS,
                    generator=g,
                    worker_init_fn=worker_init_fn
                )

                best_miou = 0.0
                best_f1 = 0.0
                epoch_mious = []
                grad_tvc_values = []
                for epoch in range(self.config.EPOCHS_PER_ROUND):
                    grad = None
                    try:
                        out = trainer.train_one_epoch(
                            labeled_loader,
                            grad_probe_loader=(test_loader if getattr(self.config, "GRAD_LOG_VAL_ALIGNMENT", False) else None),
                        )
                    except TypeError:
                        out = trainer.train_one_epoch(labeled_loader)

                    if isinstance(out, tuple) and len(out) == 2:
                        loss, grad = out
                    else:
                        loss = out

                    if isinstance(grad, dict) and grad.get("train_val_cos") is not None:
                        try:
                            grad_tvc_values.append(float(grad.get("train_val_cos")))
                        except Exception:
                            pass
                    metrics = trainer.evaluate(test_loader)
                    try:
                        epoch_mious.append(float(metrics.get("mIoU", 0.0)))
                    except Exception:
                        pass
                    logger.info(f"Epoch {epoch+1}: Loss={loss:.4f}, mIoU={metrics['mIoU']:.4f}, F1={metrics['f1_score']:.4f}")
                    self._append_md(
                        log_path,
                        f"- Epoch {epoch+1}: Loss={loss:.4f}, mIoU={metrics['mIoU']:.4f}, F1={metrics['f1_score']:.4f}\n"
                    )
                    if metrics['mIoU'] > best_miou:
                        best_miou = metrics['mIoU']
                        best_f1 = metrics['f1_score']

                    warnings = []
                    try:
                        import math
                        if not math.isfinite(float(loss)):
                            warnings.append("loss_not_finite")
                        if not math.isfinite(float(metrics.get('mIoU', 0.0))):
                            warnings.append("miou_not_finite")
                        if not math.isfinite(float(metrics.get('f1_score', 0.0))):
                            warnings.append("f1_not_finite")
                    except Exception:
                        pass

                    self._write_status({
                        "status": "running",
                        "progress": {
                            "round": int(round_idx + 1),
                            "epoch": int(epoch + 1),
                            "labeled_size": int(len(self.labeled_indices)),
                            "loss": float(loss),
                            "mIoU": float(metrics['mIoU']),
                            "f1": float(metrics['f1_score']),
                            "best_mIoU_round": float(best_miou),
                            "warnings": warnings
                        }
                    })
                    self._append_trace({
                        "type": "epoch_end",
                        "round": int(round_idx + 1),
                        "epoch": int(epoch + 1),
                        "labeled_size": int(len(self.labeled_indices)),
                        "loss": float(loss),
                        "mIoU": float(metrics['mIoU']),
                        "f1": float(metrics['f1_score']),
                        "warnings": warnings,
                        "grad": grad
                    })

                performance_history.append({
                    "round": round_idx + 1,
                    "mIoU": float(best_miou),
                    "f1_score": float(best_f1),
                    "labeled_size": len(self.labeled_indices)
                })
                if best_miou > best_miou_so_far:
                    best_miou_so_far = float(best_miou)
                budget_history.append(len(self.labeled_indices))
                self._append_md(
                    log_path,
                    f"\n当前轮次最佳结果: Round={round_idx+1}, Labeled={len(self.labeled_indices)}, mIoU={best_miou:.4f}, F1={best_f1:.4f}\n\n"
                )

                # --- 基础设施增强: 无论是否使用 Agent，都计算并记录过拟合信号 (TVC) ---
                tvc_mean = None
                tvc_min = None
                tvc_max = None
                tvc_last = None
                tvc_neg_rate = None
                overfit_risk = None
                if grad_tvc_values:
                    try:
                        arr = np.asarray(grad_tvc_values, dtype=float)
                        arr = arr[np.isfinite(arr)]
                        if int(arr.size) > 0:
                            tvc_mean = float(np.mean(arr))
                            tvc_min = float(np.min(arr))
                            tvc_max = float(np.max(arr))
                            tvc_last = float(arr[-1])
                            tvc_neg_rate = float(np.mean(arr < 0))
                            overfit_risk = float((tvc_neg_rate or 0.0) + max(0.0, -tvc_min) * 0.5 + max(0.0, -tvc_last) * 0.5)
                    except Exception:
                        tvc_mean = None
                        tvc_min = None
                        tvc_max = None
                        tvc_last = None
                        tvc_neg_rate = None
                        overfit_risk = None

                self._append_trace({
                    "type": "overfit_signal",
                    "round": int(round_idx + 1),
                    "grad_train_val_cos_mean": tvc_mean,
                    "grad_train_val_cos_min": tvc_min,
                    "grad_train_val_cos_max": tvc_max,
                    "grad_train_val_cos_last": tvc_last,
                    "grad_train_val_cos_neg_rate": tvc_neg_rate,
                    "overfit_risk": overfit_risk,
                })
                # ------------------------------------------------------------------

                if self.use_agent and self.agent_manager:
                    prev_miou = performance_history[-2]["mIoU"] if len(performance_history) > 1 else None
                    miou_delta = None if prev_miou is None else float(best_miou) - float(prev_miou)

                    rollback_cfg = getattr(self, "rollback_config", None)
                    if not isinstance(rollback_cfg, dict):
                        rollback_cfg = {}
                    rollback_mode = "adaptive_threshold"

                    rollback_threshold_used = None
                    if miou_delta is not None:
                        std_factor = abs(float(rollback_cfg.get("std_factor", 1.5)))
                        tau_min = abs(float(rollback_cfg.get("tau_min", 0.005)))
                        epoch_std = 0.0
                        try:
                            if isinstance(epoch_mious, list) and len(epoch_mious) >= 2:
                                epoch_std = float(np.std(np.array(epoch_mious, dtype=float), ddof=1))
                        except Exception:
                            epoch_std = 0.0
                        if not np.isfinite(epoch_std) or float(epoch_std) < 0.0:
                            epoch_std = 0.0
                        tau = max(float(tau_min), float(std_factor) * float(epoch_std))
                        if (not np.isfinite(tau)) or float(tau) <= 0.0:
                            raise RuntimeError(f"adaptive rollback threshold requires positive finite tau, got {tau}")
                        rollback_threshold_used = -tau
                        rollback_flag = bool(float(miou_delta) < float(rollback_threshold_used))
                    else:
                        rollback_flag = False

                    remaining_budget = None
                    try:
                        remaining_budget = int(self.config.TOTAL_BUDGET) - int(len(self.labeled_indices))
                    except Exception:
                        remaining_budget = None
                    self.toolbox.set_training_state({
                        "round_idx": int(round_idx + 1),
                        "last_miou": best_miou,
                        "prev_miou": prev_miou if prev_miou is not None else 0.0,
                        "best_miou_so_far": best_miou_so_far,
                        "miou_delta": miou_delta,
                        "rollback_flag": bool(rollback_flag),
                        "rollback_mode": rollback_mode,
                        "rollback_threshold": float(rollback_threshold_used) if rollback_threshold_used is not None else None,
                        "k_definition": getattr(self, "k_definition", None),
                        "current_labeled_count": int(len(self.labeled_indices)),
                        "total_budget": int(self.config.TOTAL_BUDGET),
                        "remaining_budget": remaining_budget,
                        "last_round_selected_count": self._last_query_selected_count,
                        "grad_train_val_cos_mean": tvc_mean,
                        "grad_train_val_cos_min": tvc_min,
                        "grad_train_val_cos_max": tvc_max,
                        "grad_train_val_cos_last": tvc_last,
                        "grad_train_val_cos_neg_rate": tvc_neg_rate,
                        "overfit_risk": overfit_risk,
                    })

                if round_idx < self.config.N_ROUNDS - 1:
                    new_indices = self._query_samples(trainer.model)
                    if new_indices is not None:
                        update_result = self.update(new_indices)
                        if isinstance(update_result, dict) and update_result.get("status") != "success":
                            raise ValueError(f"Selection failed: {update_result}")
                        expected = int(update_result.get("expected_count") or self.config.QUERY_SIZE)
                        selected = int(update_result.get("selected_count") or 0)
                        if expected > 0 and selected < expected:
                            early_stop = True
                        if expected > 0 and selected < expected:
                            self._write_status({
                                "progress": {
                                    "round": int(round_idx + 1),
                                    "selection": {
                                        "expected": int(expected),
                                        "selected": int(selected),
                                        "early_stop": True
                                    }
                                }
                            })
                    elif self.use_agent and self._last_query_selected_count is not None:
                        expected = int(getattr(self.config, "QUERY_SIZE", 0) or 0)
                        if expected > 0 and int(self._last_query_selected_count) < expected:
                            early_stop = True
                
                self._save_pool_states()
                
                # Checkpoint - Atomic Guarantee
                state_dict = {
                    "round": int(round_idx + 1),
                    "performance_history": performance_history,
                    "budget_history": budget_history,
                    "labeled_indices": self.labeled_indices,
                    "labeled_size": int(len(self.labeled_indices)), # Crucial for rollback
                    "unlabeled_size": int(len(self.unlabeled_indices)),
                    "rng_states": self._get_rng_states(), # Reproducibility
                }
                if self.use_agent and self.agent_manager:
                    state_dict['pending_round_controls'] = dict(self._pending_round_controls)
                    
                self.checkpoint_manager.save(state_dict)
                self._write_status({
                    "status": "running",
                    "progress": {
                        "round": int(round_idx + 1),
                        "epoch": "finished",
                        "labeled_size": int(len(self.labeled_indices))
                    }
                })
                
                if early_stop:
                    self._append_trace({
                        "type": "early_stop",
                        "round": int(round_idx + 1),
                        "reason": "selection_short"
                    })
                    break
            except Exception as e:
                logger.error(f"Round {round_idx + 1} failed: {str(e)}")
                error_type = None
                try:
                    error_type = self._classify_error(str(e))
                except Exception:
                    error_type = "unknown"
                self._write_status({
                    "status": "failed",
                    "error": {
                        "round": int(round_idx + 1),
                        "message": str(e),
                        "type": error_type,
                        "exception": e.__class__.__name__
                    }
                })
                self._append_trace({
                    "type": "failed",
                    "round": int(round_idx + 1),
                    "message": str(e),
                    "error_type": error_type,
                    "exception": e.__class__.__name__
                })
                self._append_md(
                    log_path,
                    f"\n**[ERROR] Round {round_idx + 1} 失败: {str(e)}**\n\n"
                )
                raise

        alc = calculate_alc(
            [p["mIoU"] for p in performance_history],
            budget_history,
            total_budget=int(getattr(self.config, "TOTAL_BUDGET", 0) or 0),
            pad_to_total_budget=True,
        )
        result = {
            "performance_history": performance_history,
            "budget_history": budget_history,
            "alc": float(alc),
            "final_miou": float(performance_history[-1]["mIoU"]),
            "final_f1": float(performance_history[-1]["f1_score"]),
        }
        self._append_md(
            log_path,
            f"\n## 实验汇总\n\n预算历史: {budget_history}\nALC: {result['alc']:.4f}\n最终 mIoU: {result['final_miou']:.4f}\n最终 F1: {result['final_f1']:.4f}\n"
        )
        self._write_status({
            "status": "completed",
            "result": {
                "alc": float(result['alc']),
                "final_mIoU": float(result['final_miou']),
                "final_f1": float(result['final_f1']),
                "budget_history": list(result['budget_history'])
            }
        })
        return result

    def run(self):
        result = self.run_and_collect()
        logger.info("=== Experiment Finished ===")
        logger.info(f"Experiment: {self.experiment_name}")
        logger.info(f"Budget History: {result['budget_history']}")
        logger.info(f"Performance (mIoU) History: {[p['mIoU'] for p in result['performance_history']]}")
        logger.info(f"ALC: {result['alc']:.4f}")

    def _query_samples(self, model):
        logger.info("Querying samples...")
        
        # Common logic: rank samples
        # Need unlabeled info
        # To avoid re-extracting features for baseline samplers if they don't need model,
        # we check sampler type. But AD-KUCS needs model.
        
        # For simplicity, we assume samplers might need model features or predictions.
        # We need a helper to get unlabeled data info efficiently.
        # But our sampler interface varies.
        
        # 统一接口: rank_samples(model, dataset, unlabeled_indices, labeled_indices, ...)
        # Or specialized handling.
        
        n_samples = int(self.config.QUERY_SIZE)
        
        if self.use_agent and self.agent_manager:
            self.toolbox.model = model
            self._last_query_selected_count = None
            try:
                result = self.agent_manager.run_cycle()
            except Exception as e:
                logger.error(f"Agent run_cycle failed: {str(e)}")
                raise RuntimeError(f"LLM Agent failed at Round {self.current_round}: {str(e)}")

            n_samples = int(self.config.QUERY_SIZE)
            if not isinstance(result, dict):
                logger.error(f"Agent returned non-dict result at Round {self.current_round}: {type(result).__name__}")
                raise RuntimeError(f"LLM Agent failed at Round {self.current_round}: invalid_result_type {type(result).__name__}")

            if result.get("status") != "success":
                error_type = result.get("error_type") or "AgentError"
                message = result.get("message") or json.dumps(result, ensure_ascii=False)
                logger.error(f"Agent failed at Round {self.current_round}: {error_type}: {message}")
                raise RuntimeError(f"LLM Agent failed at Round {self.current_round}: {error_type}: {message}")

            control_applied = result.get("control_applied")
            if isinstance(control_applied, dict) and control_applied.get("epochs") is not None:
                fixed_epochs = bool(getattr(self.config, "FIX_EPOCHS_PER_ROUND", False))
                allow_epoch_control = bool(getattr(getattr(self, "toolbox", None), "control_permissions", {}).get("set_epochs_per_round", False))
                if (not fixed_epochs) and allow_epoch_control:
                    self._pending_round_controls['epochs_round'] = int(control_applied.get("epochs"))

            selected_ids = result.get("valid_candidates") or result.get("selected_ids") or []
            selected_count = int(result.get("selected_count") or 0)
            self._last_query_selected_count = selected_count

            if selected_count <= 0:
                logger.error(f"Agent returned success but selected_count={selected_count} at Round {self.current_round}")
                raise RuntimeError(f"Agent selection incomplete at Round {self.current_round}: selected_count={selected_count}, required={n_samples}")

            if not isinstance(selected_ids, list) or len(selected_ids) < n_samples:
                error_msg = f"Agent selected {len(selected_ids) if isinstance(selected_ids, list) else 0} samples, but {n_samples} required"
                logger.error(f"Agent selection incomplete at Round {self.current_round}: {error_msg}")
                raise RuntimeError(f"Agent selection incomplete at Round {self.current_round}: {error_msg}")

            return None

        ranked_ids = self._rank_samples_by_sampler(model)
        selected = ranked_ids[:n_samples]
        self._selection_context = {
            "source": "pipeline",
            "policy": "pipeline_rank_topk",
            "fallback_used": False,
            **self._sampler_audit(),
            **(getattr(self, "_last_ranking_metadata", {}) or {}),
            "degraded": dict(self._last_ranking_degraded) if isinstance(getattr(self, "_last_ranking_degraded", None), dict) else None
        }
        return selected

    def _rank_samples_by_sampler(self, model):
        if isinstance(self.sampler, BALDSampler):
            # BALD requires MC Dropout predictions
            n_mc = self.sampler.n_samples
            unlabeled_info, labeled_features = self._prepare_unlabeled_info(model, mc_dropout=True, n_mc_samples=n_mc)
            
            if not unlabeled_info:
                 raise RuntimeError("BALD: unlabeled_info is empty")

            # Prepare kwargs for BALD (it expects bulk mc_predictions)
            sample_indices = list(unlabeled_info.keys())
            mc_predictions = []
            for sid in sample_indices:
                if 'mc_predictions' in unlabeled_info[sid]:
                    mc_predictions.append(unlabeled_info[sid]['mc_predictions'])
                else:
                    # Should not happen if _prepare_unlabeled_info works correctly
                    raise RuntimeError(f"Missing mc_predictions for sample {sid}")
            
            mc_predictions = np.stack(mc_predictions)
            
            ranked = self.sampler.rank_samples(
                unlabeled_info, 
                labeled_features=labeled_features,
                mc_predictions=mc_predictions,
                sample_indices=sample_indices
            )
            return [item["sample_id"] for item in ranked]

        if isinstance(self.sampler, ADKUCSSampler) or self.sampler.__class__.__name__ == 'ADKUCSSampler':
            unlabeled_info, labeled_features = self._prepare_unlabeled_info(model)
            lambda_override = self.exp_config.get('lambda_override')
            if lambda_override is None and self.use_agent and hasattr(self, 'toolbox'):
                lambda_override = self.toolbox.control_state.get('lambda_override_round')
            if lambda_override is None and hasattr(self, 'toolbox') and isinstance(getattr(self, "exp_config", None), dict) and isinstance(self.exp_config.get("lambda_policy"), dict):
                lambda_override = self.toolbox.apply_round_lambda_policy()

            # Explicitly log lambda usage for debugging
            logger.info(f"ADKUCSSampler: Preparing rank. lambda_override={lambda_override}")
            current_iteration = len(self.labeled_indices)
            total_iterations = self.config.TOTAL_BUDGET
            lambda_used = float(self.sampler._get_adaptive_weight(current_iteration, total_iterations, override=lambda_override))

            if not unlabeled_info:
                raise RuntimeError("ADKUCSSampler: unlabeled_info is empty")

            ranked = self.sampler.rank_samples(
                unlabeled_info,
                labeled_features,
                current_iteration=current_iteration,
                total_iterations=total_iterations,
                lambda_override=lambda_override
            )
            if ranked:
                top_item = ranked[0]
                top_k = int(self.config.QUERY_SIZE)
                avg_uncertainty = float(np.mean([r["uncertainty"] for r in ranked[:top_k]]))
                avg_knowledge_gain = float(np.mean([r["knowledge_gain"] for r in ranked[:top_k]]))
                self._last_ranking_metadata = {
                    "lambda_t": top_item.get("lambda_t"),
                    "avg_uncertainty": avg_uncertainty,
                    "avg_knowledge_gain": avg_knowledge_gain,
                    "uncertainty_type": "pixel_mean_entropy_log2",
                    "uncertainty_definition": "U(I)=mean_i H(p_i), H(p_i)=-sum_c p_{i,c} log2(p_{i,c}+1e-10)",
                }
                logger.info(
                    f"AD-KUCS Strategy: lambda_t={top_item.get('lambda_t'):.4f} (Top Sample: {top_item.get('sample_id')}) "
                    f"avg_uncertainty(top{top_k})={avg_uncertainty:.6f} avg_knowledge_gain(top{top_k})={avg_knowledge_gain:.6f} "
                    f"U_def=pixel_mean_entropy_log2"
                )
        else:
            unlabeled_info, labeled_features = self._prepare_unlabeled_info(model)
            ranked = self.sampler.rank_samples(unlabeled_info, labeled_features=labeled_features)
        return [item["sample_id"] for item in ranked]

    def update(self, new_indices):
        expected = int(getattr(self.config, "QUERY_SIZE", 0) or 0)
        if expected <= 0:
            raise ValueError(f"Invalid QUERY_SIZE: {expected}")
        if not getattr(self, "unlabeled_indices", None):
            raise RuntimeError("unlabeled_indices is empty")
        if expected > int(len(self.unlabeled_indices)):
            raise RuntimeError(f"QUERY_SIZE {expected} exceeds remaining unlabeled {len(self.unlabeled_indices)}")
        if not new_indices:
            raise ValueError("new_indices is empty")

        normalized = []
        seen = set()
        for item in new_indices:
            idx = int(item)
            if idx in seen:
                raise ValueError(f"Duplicate selected id: {idx}")
            seen.add(idx)
            normalized.append(idx)

        valid = [idx for idx in normalized if idx in self.unlabeled_indices]
        if not valid:
            raise RuntimeError("No valid selected ids in unlabeled_indices")
        if len(valid) < expected:
            raise RuntimeError(f"Only {len(valid)} valid selections, but {expected} required")

        limit = expected if expected > 0 else len(valid)
        selected = valid[: min(limit, len(valid))]
        for idx in selected:
            self.unlabeled_indices.remove(idx)
            self.labeled_indices.append(idx)

        self._save_pool_states()
        logger.info(f"Updated pools. Added {len(selected)} samples. New Labeled: {len(self.labeled_indices)}")

        ctx = None
        if isinstance(getattr(self, "_selection_context", None), dict):
            ctx = dict(self._selection_context)
        self._selection_context = None
        self._write_status({
            "progress": {
                "round": int(self.current_round) if self.current_round is not None else None,
                "selection": {
                    "expected": int(expected),
                    "selected": int(len(selected)),
                    "selected_ids": list(selected),
                    "context": ctx
                }
            }
        })
        self._append_trace({
            "type": "selection",
            "round": int(self.current_round) if self.current_round is not None else None,
            **self._sampler_audit(),
            "expected": int(expected),
            "selected": int(len(selected)),
            "selected_ids": list(selected),
            "context": ctx
        })
        return {
            "status": "success",
            "expected_count": expected,
            "selected_count": len(selected),
            "selected_ids": selected,
            "exhausted": len(selected) < expected or not self.unlabeled_indices
        }

    def _load_pool_states(self):
        import pandas as pd
        pools_dir = self.pools_dir
        
        labeled_path = os.path.join(pools_dir, 'labeled_pool.csv')
        unlabeled_path = os.path.join(pools_dir, 'unlabeled_pool.csv')
        test_path = os.path.join(pools_dir, 'test_pool.csv')
        
        if not os.path.exists(labeled_path) or not os.path.exists(unlabeled_path):
            raise FileNotFoundError(f"Pool state files not found in {pools_dir}")
        
        self.labeled_df = pd.read_csv(labeled_path)
        self.unlabeled_df = pd.read_csv(unlabeled_path)
        
        if os.path.exists(test_path):
            self.test_df = pd.read_csv(test_path)
        
        self.labeled_indices = self._map_filenames_to_indices(self.full_dataset, self.labeled_df['sample_id'].tolist())
        self.unlabeled_indices = self._map_filenames_to_indices(self.full_dataset, self.unlabeled_df['sample_id'].tolist())
        
        if hasattr(self, 'test_df'):
            self.test_indices = self._map_filenames_to_indices(self.full_dataset, self.test_df['sample_id'].tolist())
        
        logger.info(f"Loaded pool states: Labeled={len(self.labeled_indices)}, Unlabeled={len(self.unlabeled_indices)}, Test={len(self.test_indices)}")
        self._assert_pool_integrity()
        return True

    def _get_rng_states(self):
        """Capture RNG states for reproducibility."""
        # numpy.random.get_state() returns (str, ndarray, int, int, float)
        # ndarray is not JSON serializable, so we convert it to list
        np_state = np.random.get_state()
        np_state_list = list(np_state)
        np_state_list[1] = np_state[1].tolist()

        states = {
            "python": random.getstate(),
            "numpy": np_state_list,
            "torch": torch.get_rng_state().tolist(), # Convert to list for JSON serialization
        }
        if torch.cuda.is_available():
            # torch.cuda.get_rng_state_all() returns a list of ByteTensors
            states["torch_cuda"] = [t.tolist() for t in torch.cuda.get_rng_state_all()]
        return states

    def _set_rng_states(self, states):
        """Restore RNG states."""
        if not states:
            return
        
        try:
            if "python" in states:
                # python random state is a tuple, but JSON loads as list
                # random.setstate expects tuple
                py_state = states["python"]
                if isinstance(py_state, list):
                     py_state = tuple(py_state)
                     # The second element is the state, which is also a tuple
                     if len(py_state) > 1 and isinstance(py_state[1], list):
                         py_state_list = list(py_state)
                         py_state_list[1] = tuple(py_state[1])
                         py_state = tuple(py_state_list)
                random.setstate(py_state)
                
            if "numpy" in states:
                # numpy state is tuple(str, ndarray, int, int, float)
                # JSON loads ndarray as list
                np_state = states["numpy"]
                if isinstance(np_state, list):
                     # Need to convert back to tuple and ensure ndarray
                     state_str = np_state[0]
                     state_arr = np.array(np_state[1], dtype=np.uint32)
                     pos = np_state[2]
                     has_gauss = np_state[3]
                     cached_gauss = np_state[4]
                     np.random.set_state((state_str, state_arr, pos, has_gauss, cached_gauss))
            
            if "torch" in states:
                torch.set_rng_state(torch.tensor(states["torch"], dtype=torch.uint8))
            
            if "torch_cuda" in states and torch.cuda.is_available():
                cuda_states = states["torch_cuda"]
                # Convert list of lists back to list of ByteTensors
                if isinstance(cuda_states, list):
                     tensor_states = [torch.tensor(s, dtype=torch.uint8) for s in cuda_states]
                     torch.cuda.set_rng_state_all(tensor_states)
                
        except Exception as e:
            logger.warning(f"Failed to restore RNG states: {e}")

    def _rollback_pools(self, target_labeled_size):
        """
        Rollback pools to match the checkpoint state.
        This handles the case where Pool CSVs were updated but Checkpoint JSON was not.
        """
        if not os.path.exists(os.path.join(self.pools_dir, 'labeled_pool.csv')):
             return False

        import pandas as pd
        labeled_df = pd.read_csv(os.path.join(self.pools_dir, 'labeled_pool.csv'))
        current_size = len(labeled_df)
        
        if current_size == target_labeled_size:
            return True
            
        if current_size < target_labeled_size:
            logger.error(f"Pool corruption: Labeled pool size ({current_size}) < Checkpoint size ({target_labeled_size})")
            return False
            
        logger.warning(f"Rolling back pools: Truncating labeled pool from {current_size} to {target_labeled_size}")
        
        # 1. Truncate Labeled Pool
        # Keep first N rows
        valid_labeled_df = labeled_df.iloc[:target_labeled_size]
        valid_labeled_df.to_csv(os.path.join(self.pools_dir, 'labeled_pool.csv'), index=False)
        self.labeled_df = valid_labeled_df
        
        # 2. Reconstruct Unlabeled Pool
        # Unlabeled = Full Dataset - Labeled - Test
        # We rely on indices logic for this.
        # But here we need to write the CSV.
        
        # Get all sample IDs from full dataset
        all_samples = [os.path.splitext(os.path.basename(x))[0] for x in getattr(self.full_dataset, 'images', [])]
        labeled_ids = set(valid_labeled_df['sample_id'].tolist())
        test_ids = set(self.test_df['sample_id'].tolist())
        
        unlabeled_ids = [s for s in all_samples if s not in labeled_ids and s not in test_ids]
        
        # Create unlabeled DataFrame
        # Assuming original unlabeled pool has 'sample_id' column.
        # If it had other columns (like scores), they are lost for the rolled-back samples, 
        # but that's fine as they need to be re-scored anyway.
        unlabeled_df = pd.DataFrame({'sample_id': unlabeled_ids})
        unlabeled_df.to_csv(os.path.join(self.pools_dir, 'unlabeled_pool.csv'), index=False)
        self.unlabeled_df = unlabeled_df
        
        # Update indices in memory
        self.labeled_indices = self._map_filenames_to_indices(self.full_dataset, self.labeled_df['sample_id'].tolist())
        self.unlabeled_indices = self._map_filenames_to_indices(self.full_dataset, self.unlabeled_df['sample_id'].tolist())
        
        logger.info(f"Pool rollback complete. Labeled: {len(self.labeled_indices)}, Unlabeled: {len(self.unlabeled_indices)}")
        return True

    def _truncate_trace(self, target_round):
        """
        Remove trace entries that belong to rounds > target_round.
        Also remove duplicate 'epoch_end' for target_round if any (though usually we keep completed round).
        
        If we are resuming from Round N (completed), we expect next to be Round N+1.
        So we keep everything up to Round N.
        """
        if not os.path.exists(self.trace_path):
            return

        import json
        valid_lines = []
        with open(self.trace_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            
        for line in lines:
            try:
                entry = json.loads(line)
                r = entry.get('round')
                if r is None:
                    valid_lines.append(line) # Keep initialization/metadata lines
                    continue
                    
                if r <= target_round:
                    valid_lines.append(line)
            except Exception:
                continue
        
        # Add resume marker
        resume_marker = json.dumps({
            "type": "resume", 
            "round": target_round, 
            "ts": datetime.now().isoformat()
        })
        valid_lines.append(resume_marker + "\n")
        
        with open(self.trace_path, 'w', encoding='utf-8') as f:
            f.writelines(valid_lines)
            
    def _save_pool_states(self):
        import pandas as pd
        labeled_rows = []
        unlabeled_rows = []
        
        for idx in self.labeled_indices:
            img_file = self.full_dataset.images[idx]
            sample_id = os.path.splitext(img_file)[0]
            img_path = os.path.join(self.full_dataset.img_dir, img_file)
            mask_path = os.path.join(self.full_dataset.mask_dir, img_file)
            labeled_rows.append({
                'sample_id': sample_id,
                'image_path': img_path,
                'mask_path': mask_path
            })
        
        for idx in self.unlabeled_indices:
            img_file = self.full_dataset.images[idx]
            sample_id = os.path.splitext(img_file)[0]
            img_path = os.path.join(self.full_dataset.img_dir, img_file)
            mask_path = os.path.join(self.full_dataset.mask_dir, img_file)
            unlabeled_rows.append({
                'sample_id': sample_id,
                'image_path': img_path,
                'mask_path': mask_path
            })
        
        labeled_df = pd.DataFrame(labeled_rows)
        unlabeled_df = pd.DataFrame(unlabeled_rows)
        pools_dir = self.pools_dir
        os.makedirs(pools_dir, exist_ok=True)
        labeled_path = os.path.join(pools_dir, 'labeled_pool.csv')
        unlabeled_path = os.path.join(pools_dir, 'unlabeled_pool.csv')
        labeled_tmp = labeled_path + ".tmp"
        unlabeled_tmp = unlabeled_path + ".tmp"
        labeled_df.to_csv(labeled_tmp, index=False)
        unlabeled_df.to_csv(unlabeled_tmp, index=False)
        os.replace(labeled_tmp, labeled_path)
        os.replace(unlabeled_tmp, unlabeled_path)

    def _prepare_unlabeled_info(self, model, mc_dropout=False, n_mc_samples=10):
        helper = ADKUCSSampler(self.config.DEVICE, alpha=self.config.ALPHA)
        subset_u = Subset(self.full_dataset, self.unlabeled_indices)
        loader_u = DataLoader(subset_u, batch_size=self.config.BATCH_SIZE, shuffle=False, num_workers=self.config.NUM_WORKERS)
        
        probs, features = helper.get_predictions_and_features(model, loader_u, mc_dropout=mc_dropout, n_mc_samples=n_mc_samples)
        
        unlabeled_info = {}
        if probs is None or features is None:
            reason = []
            if probs is None:
                reason.append("probs=None")
            if features is None:
                reason.append("features=None")
            raise RuntimeError(f"_prepare_unlabeled_info failed: {', '.join(reason)}")
            
        for i, idx in enumerate(self.unlabeled_indices):
            info = {
                'feature': features[i].numpy()
            }
            if mc_dropout:
                # probs is a dict {idx: mc_preds} from helper
                # helper uses 0-based index relative to loader
                if i in probs:
                    info['mc_predictions'] = probs[i] # already numpy
            else:
                # probs is a tensor
                info['prob_map'] = probs[i].numpy()
                
            unlabeled_info[idx] = info

        labeled_features = None
        if self.labeled_indices:
            subset_l = Subset(self.full_dataset, self.labeled_indices)
            loader_l = DataLoader(subset_l, batch_size=self.config.BATCH_SIZE, shuffle=False, num_workers=self.config.NUM_WORKERS)
            _, l_feats = helper.get_predictions_and_features(model, loader_l)
            if l_feats is None:
                raise RuntimeError("_prepare_unlabeled_info failed: labeled feature extraction returned None")
            labeled_features = l_feats.numpy()
        return unlabeled_info, labeled_features

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--experiment_name', type=str, default='full_model', help='Name of the experiment to run')
    parser.add_argument('--run_id', type=str, required=True, help='Run id for research isolation')
    parser.add_argument('--start', type=str, default='resume', choices=['resume', 'fresh'], help='Start mode: resume or fresh')
    parser.add_argument('--n_rounds', type=int, default=None, help='Number of active learning rounds to run (default: use config value)')
    args = parser.parse_args()
    
    config = Config()
    config.START_MODE = args.start
    if args.n_rounds is not None and args.n_rounds > 0:
        config.N_ROUNDS = int(args.n_rounds)
    pipeline = ActiveLearningPipeline(config, args.experiment_name, run_id=args.run_id)
    pipeline.run()

if __name__ == '__main__':
    main()
